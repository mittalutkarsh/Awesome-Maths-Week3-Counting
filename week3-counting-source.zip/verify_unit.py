from itertools import permutations, combinations, product
from math import factorial as f, comb
R=[]
def chk(n,b,a): R.append(b==a); print(('OK ' if b==a else 'XX '), f"{n:40s} brute={b:<8} arg={a}")
chk("4 two-digit with a 7", sum('7' in str(n) for n in range(10,100)), 10+9-1)
chk("4 via complement", sum('7' in str(n) for n in range(10,100)), 90-8*9)
chk("5 3-digit palindromes", sum(str(n)==str(n)[::-1] for n in range(100,1000)), 9*10)
chk("15 0-4 five-digit", sum(1 for p in permutations('01234') if p[0]!='0'), 4*f(4))
chk("16 shortest first tallest last", sum(1 for p in permutations(range(6)) if p[0]==0 and p[-1]==5), f(4))
chk("17 atlas adjacent", sum(1 for p in permutations('ABCDE') if abs(p.index('A')-p.index('B'))==1), f(4)*2)
chk("20 9!/7!", f(9)//f(7), 9*8)
chk("23 handshakes 12", len(list(combinations(range(12),2))), 12*11//2)
V=range(12); sides={frozenset((i,(i+1)%12)) for i in V}
chk("24 dodecagon diagonals", sum(1 for e in combinations(V,2) if frozenset(e) not in sides), 12*9//2)
S='LGAWRF'; splits={frozenset([frozenset(c),frozenset(set(S)-set(c))]) for c in combinations(S,2)}
chk("25 split 2+4", len(splits), 6*5//2)
chk("26 trio from 10", len(list(combinations(range(10),3))), 10*9*8//6)
deck=[(r,s) for r in range(13) for s in 'CDHS']   # r 9,10,11 = J,Q,K
face=lambda c: c[0] in (9,10,11); red=lambda c: c[1] in 'DH'
chk("27 three clubs", sum(1 for h in combinations(deck,3) if all(c[1]=='C' for c in h)), comb(13,3))
chk("28 one red one black", sum(1 for h in combinations(deck,2) if red(h[0])!=red(h[1])), 26*26)
def spf(a,b): return (a[1]=='S' and face(b)) or (b[1]=='S' and face(a))
chk("29 spade + face", sum(1 for h in combinations(deck,2) if spf(*h)), 13*12-3-3)
chk("29 case split", sum(1 for h in combinations(deck,2) if spf(*h)), 10*9+3*19+3)
chk("30 not red not face", sum(1 for c in deck if not red(c) and not face(c)), 20)
chk("Bonus a committee of 4", len(list(combinations(range(8),4))), 8*7*6*5//24)
chk("Bonus b four offices", len(list(permutations(range(8),4))), 1680)
# grid-concept numbers: 4 people grid, 5 kids captain/vice & co-captains, 8-team games grid
chk("grid 4 people: ordered pairs", len(list(permutations(range(4),2))), 16-4)
chk("grid 4 people: pairs", len(list(combinations(range(4),2))), 6)
chk("5 kids captain+vice", len(list(permutations(range(5),2))), 20)
chk("5 kids co-captains", len(list(combinations(range(5),2))), 10)
chk("8x8 games grid off-diagonal", len(list(permutations(range(8),2))), 64-8)
print("ALL AGREE:", all(R), f"({len(R)} checks)")
