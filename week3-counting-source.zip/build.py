"""Build the four-page site. Run: python3 build.py  ->  out/"""
import json, pathlib, html
from data.practice import P as PRACTICE, S1, S2, S3, S4, S5, S6
from data.lesson import L as LESSON, C as CONCEPTS, ORDER as CONCEPT_ORDER
from data import notes as N

ROOT = pathlib.Path(__file__).parent
SRC, OUT = ROOT / "src", ROOT / "out"
SLUG = "counting"
PAGES = {"index": "index.html", "notes": f"{SLUG}-notes.html", "lesson": f"{SLUG}-lesson.html", "practice": f"{SLUG}-practice.html"}
FONTS = ('<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
         '<link href="https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600&family=IBM+Plex+Mono:wght@400;500&'
         'family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">')
read = lambda n: (SRC / n).read_text()

PEN_ICON = '<svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true"><path d="M2 14l1-4 8-8 3 3-8 8z" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>'
COLORS = [("#1b3358", "navy"), ("#b8322a", "red"), ("#2e7d5b", "green"), ("#c98a12", "amber")]
def pen_markup():
    tools = "".join(f'<button type="button" data-tool="{t}" aria-pressed="{str(t=="pen").lower()}" aria-label="{lab}">{lab}</button>'
                    for t, lab in [("pen", "Pen"), ("marker", "Marker"), ("line", "Line"), ("box", "Box"), ("eraser", "Eraser")])
    cols = "".join(f'<button type="button" class="sw" data-color="{c}" aria-pressed="{str(i==0).lower()}" aria-label="{n} ink"><i style="background:{c}"></i></button>'
                   for i, (c, n) in enumerate(COLORS))
    nibs = "".join(f'<button type="button" class="nib" data-width="{w}" aria-pressed="{str(w=="medium").lower()}" aria-label="{w} nib"><i style="height:{h}px"></i></button>'
                   for w, h in [("fine", 2), ("medium", 4), ("bold", 8)])
    acts = "".join(f'<button type="button" data-act="{a}" aria-label="{lab}"{" aria-pressed=\"false\"" if a=="stylus" else ""}>{txt}</button>'
                   for a, lab, txt in [("undo", "Undo (Ctrl+Z)", "Undo"), ("redo", "Redo (Ctrl+Shift+Z)", "Redo"), ("clear", "Clear all ink", "Clear"),
                                       ("export", "Export ink as PNG", "PNG"), ("stylus", "Stylus only: ignore touch", "Stylus only"), ("close", "Turn pen off (Esc)", "Done")])
    return (f'<div class="pen-ui"><button id="pen-toggle" type="button" aria-pressed="false" aria-label="Pen: draw on the page (P)" title="Pen (P)">{PEN_ICON}Pen</button>'
            f'<div id="pen-bar" role="toolbar" aria-label="Pen tools" hidden><div class="row">{tools}</div><div class="row">{cols}{nibs}</div>'
            f'<div class="row">{acts}</div></div><div id="pen-toast" role="status" aria-live="polite"></div></div>'
            '<canvas id="ink-base" class="ink" aria-hidden="true"></canvas><canvas id="ink-live" class="ink" aria-hidden="true"></canvas>')

def page(title, body, css, js, mode, extra_head=""):
    return (f'<!doctype html><html lang="en" data-pen-mode="{mode}"><head><meta charset="utf-8">'
            f'<meta name="viewport" content="width=device-width,initial-scale=1"><title>{html.escape(title)}</title>{FONTS}'
            f'<style>{css}</style>{extra_head}</head><body>{body}{pen_markup()}<script>{js}</script></body></html>')

def nav(current):
    items = [("index", "Home"), ("notes", "Notes"), ("lesson", "Lesson"), ("practice", "Practice")]
    return "".join(f'<a href="{PAGES[k]}"{" aria-current=\"page\"" if k==current else ""}>{lab}</a>' for k, lab in items)

def js_data(obj):
    return json.dumps(obj, ensure_ascii=False).replace("</", "<\\/")

from data.worked_stories import WS as _WS_OLD
from data.plan_worked import PW as WS
from data.stories import PLAN
def clean(p):
    q = {k: v for k, v in p.items()}
    q["solstory"] = WS.get(p["id"], "")
    q["steps"] = [{k: v for k, v in s.items() if k not in ("forms", "leak_ok")} for s in p["steps"]]
    return q

RULES = """<div class="rules"><h2 class="ctitle">Rules to remember</h2><dl>
<dt>Rule of product</dt><dd>Same number of options at each step → multiply.</dd>
<dt>Numbers</dt><dd>No leading zero. Zero is even.</dd>
<dt>Restricted first</dt><dd>Settle the awkward rule before the rest.</dd>
<dt>n different things</dt><dd>n! arrangements. 0! = 1.</dd>
<dt>No repeats</dt><dd>Options shrink by one each step.</dd>
<dt>Repeated letters</dt><dd>n! ÷ (each repeat count)!, multiplied together.</dd>
<dt>Identical groups</dt><dd>÷ (number of groups)!</dd>
<dt>Sets</dt><dd>Built in order? ÷ k! for k items.</dd>
<dt>Double counting</dt><dd>Counted from both sides? ÷ 2.</dd>
<dt>The plan</dt><dd>Make it in slots → same count each time? → multiply → any twins? → divide → check a tiny case.</dd>
</dl></div>"""

def workbench(kind):
    lesson = kind == "lesson"
    probs = LESSON if lesson else PRACTICE
    if lesson:
        sections = [{"name": "Concepts", "items": [p["id"] for p in LESSON]}]
    else:
        sections = []
        for name in (S1, S2, S3, S4, S5, S6):
            sections.append({"name": name, "items": [p["id"] for p in PRACTICE if p["section"] == name]})
    data = {"page": kind, "sections": sections, "problems": [clean(p) for p in probs]}
    if lesson: data["concepts"] = CONCEPTS
    tabs = ('<button role="tab" id="t-problem" data-tab="problem" aria-controls="tab-problem">Problem</button>'
            + ('<button role="tab" id="t-concept" data-tab="concept" aria-controls="tab-concept">Concept</button>' if lesson else
               '<button role="tab" id="t-rules" data-tab="rules" aria-controls="tab-rules">Rules</button>')
            + '<button role="tab" id="t-steps" data-tab="steps" aria-controls="tab-steps">My steps</button>')
    extra_panel = ('<section role="tabpanel" class="tabpanel" id="tab-concept" aria-labelledby="t-concept" hidden><div id="concept-body"></div></section>' if lesson else
                   f'<section role="tabpanel" class="tabpanel" id="tab-rules" aria-labelledby="t-rules" hidden>{RULES}</section>')
    title = "Week 3 · Lesson" if lesson else "Week 3 · Practice"
    body = f"""<div class="app">
<header class="top">
  <button id="rail-toggle" class="iconbtn" type="button" aria-label="Show problem list" aria-expanded="false" aria-controls="rail">☰</button>
  <h1>{"Rule of Product: lesson" if lesson else "Rule of Product: practice"}</h1>
  <label class="sr" for="prob-select" style="position:absolute;left:-9999px">Problem</label>
  <select id="prob-select" aria-label="Choose a problem"></select>
  <button id="prev-btn" class="iconbtn" type="button" aria-label="Previous problem">‹</button>
  <button id="next-btn" class="iconbtn" type="button" aria-label="Next problem">›</button>
  <span id="done-count" class="meta" aria-live="polite"></span>
  <span class="meta" aria-label="Time on this problem">⏱ <span id="timer">0:00</span></span>
  <nav aria-label="Pages">{nav(kind)}</nav>
</header>
<div class="panes">
  <nav id="rail" class="pane" aria-label="Problems"></nav>
  <main class="mid pane">
    <div id="tabs" role="tablist" aria-label="Problem views">{tabs}</div>
    <section role="tabpanel" class="tabpanel" id="tab-problem" aria-labelledby="t-problem"><div id="problem-body"></div>
      <div id="verified" class="solution" hidden aria-live="polite"></div><div id="worked" class="solution" hidden></div></section>
    {extra_panel}
    <section role="tabpanel" class="tabpanel" id="tab-steps" aria-labelledby="t-steps" hidden><ol id="steps-list"></ol></section>
  </main>
  <section class="right pane" aria-label="Work area">
    <div id="step-pills" role="group" aria-label="Steps"></div>
    <p id="step-q" aria-live="polite"></p>
    <div class="edwrap"><pre id="gutter" aria-hidden="true"></pre>
      <textarea id="editor" spellcheck="false" aria-label="Your working for this step"
        placeholder="Write your method here: what you're choosing and how many options each step has."></textarea></div>
    <div class="ansrow"><label for="answer">Answer</label><input id="answer" autocomplete="off" inputmode="text">
      <button id="check-btn" class="btn primary" type="button">Check step</button></div>
    <div class="btnrow"><button id="hint-btn" class="btn" type="button">Hint for this step</button>
      <button id="submit-btn" class="btn" type="button">Submit question</button>
      <button id="worked-btn" class="btn" type="button">Show worked answer</button>
      <span id="tries" aria-live="polite"></span></div>
    <div id="console" role="log" aria-label="Feedback console" aria-live="polite"></div>
  </section>
</div></div>
<div id="hint-dialog" role="dialog" aria-modal="true" aria-labelledby="hint-title" hidden><div class="dlg">
  <h2 id="hint-title">Hint</h2><p id="hint-text"></p><button id="hint-close" class="btn primary" type="button">Got it</button></div></div>"""
    js = read("checker.js") + f"\nwindow.WB_DATA={js_data(data)};\n" + read("workbench.js") + "\n" + read("pen.js") + "\n" + read("grid.js") + "\n" + read("story.js")
    return page(title, body, read("base.css") + read("workbench.css"), js, "viewport")

BYID = {p['id']: p for p in PRACTICE}
def notes_page():
    uses = {c: [p for p in PRACTICE if c in p["concepts"]] for c in CONCEPT_ORDER}
    lesson_for = {p["concept_id"]: p["id"] for p in LESSON}
    toc, secs = [], []
    toc.append('<a href="#plan"><b>The counting plan</b></a>')
    secs.append('<h2 id="plan">The counting plan</h2>' + N.eq("count = (product of slot counts) ÷ (copies of each answer)") +
                '<p>Every problem this week uses the same few questions. Step through them once with him, then use them as the script for every problem.</p>' + PLAN)
    toc.append('<a href="#concepts"><b>Concepts</b></a>')
    secs.append('<h2 id="concepts">Concepts</h2>' + N.eq("n! = n × (n − 1)!") +
                '<p>Ten ideas, each shown step by step: the objects first, then a picture, then the numbers, then the general rule. Press Next step and talk through each picture with him.</p>')
    for cid in CONCEPT_ORDER:
        title, body = CONCEPTS[cid]
        chips = "".join(f'<a href="{PAGES["practice"]}#{p["id"]}">Problem {p["num"]}</a>' for p in uses[cid])
        chips += f'<a href="{PAGES["lesson"]}#{lesson_for[cid]}">Lesson guided problem</a>'
        toc.append(f'<a class="sub" href="#c-{cid}">{title}</a>')
        secs.append(f'<section id="c-{cid}"><h3>{title}</h3>{body}<h3>{"From class" if cid != "pairs" else "From the unit test"}</h3>{N.CLASS[cid]}{N.EXTRA[cid]}<div class="chips"><span>Used in:</span>{chips}</div></section>')
    toc.append('<a href="#grid"><b>The pick grid</b></a>')
    secs.append(f'<h2 id="grid">The pick grid</h2>{N.GRID_SECTION}<div class="chips"><span>Used in:</span>' +
                "".join(f'<a href="{PAGES["practice"]}#{i}">Problem {BYID[i]["num"]}</a>' for i in ("q12", "u23", "u24", "u25", "u28", "u29")) + '</div>')
    toc.append('<a href="#traps"><b>Tricky bits</b></a>')
    traps = "".join(f'<div class="trap" id="trap-{i+1}"><h3>{i+1}. {t}</h3><p><span class="wrong">Wrong answer: {w}</span> · '
                    f'<a href="{PAGES["practice"]}#{pid}">Problem {pid[1:]}</a></p><p>{why}</p></div>'
                    for i, (t, pid, w, why) in enumerate(N.TRAPS))
    secs.append(f'<h2 id="traps">Tricky bits</h2>{N.EQ_SECTION["traps"]}<p>Each trap comes from a specific problem in Problem Set 3, with the wrong answer it produces.</p>{traps}')
    toc.append('<a href="#worked"><b>Worked problems</b></a>')
    wk = "".join(f'<div class="worked-ex" id="w-{pid}"><h3>Problem {pid[1:]}: {t}</h3>{WS[pid].replace(chr(34) + "pw-" + pid + chr(34), chr(34) + "npw-" + pid + chr(34))}<div class="chips"><a href="{PAGES["practice"]}#{pid}">Try it in practice</a></div></div>'
                 for pid, t, b in N.WORKED)
    secs.append(f'<h2 id="worked">Worked problems</h2>{N.EQ_SECTION["worked"]}<p>Step through these after he has tried the problem. Each step has one picture and one question to ask him.</p>{wk}')
    toc.append('<a href="#cheat"><b>Cheat sheet</b></a>')
    rows = "".join(f"<tr><td>{a}</td><td>{b}</td></tr>" for a, b in N.CHEAT)
    secs.append(f'<h2 id="cheat">Cheat sheet</h2>{N.EQ_SECTION["cheat"]}<table class="cheat"><thead><tr><th>Situation</th><th>Move</th></tr></thead><tbody>{rows}</tbody></table>')
    toc.append('<a href="#gloss"><b>Glossary</b></a>')
    gl = "".join(f"<dt>{a}</dt><dd>{b}</dd>" for a, b in N.GLOSS)
    secs.append(f'<h2 id="gloss">Glossary</h2>{N.EQ_SECTION["gloss"]}<dl class="gloss">{gl}</dl>')
    toc.append('<a href="#habits"><b>Write-up habits</b></a>')
    secs.append(f'<h2 id="habits">Write-up habits</h2>{N.EQ_SECTION["habits"]}<p>Drawn from how the teacher worked the problems in class.</p>{N.HABITS}')
    body = (f'<div class="notes"><nav class="toc" aria-label="Contents"><p class="back"><a href="{PAGES["index"]}">← Home</a></p>{"".join(toc)}</nav>'
            f'<article class="sheet"><h1>Rule of Product</h1><p class="lede">AwesomeMath Level 1, Week 3. Read this before or after the practice; nothing here is graded.</p>'
            f'{"".join(secs)}</article></div>')
    return page("Week 3 · Notes", body, read("base.css") + read("notes.css"), read("pen.js") + "\n" + read("grid.js") + "\n" + read("story.js"), "page")

def index_page():
    body = f"""<main class="home">
<h1>Rule of Product</h1><p class="kicker">AwesomeMath Level 1, Week 3</p>
<div class="doors">
<a href="{PAGES["notes"]}"><b>Notes</b><span>The whole topic written out: concepts, fifteen traps, worked solutions, a cheat sheet and a glossary.</span></a>
<a href="{PAGES["lesson"]}"><b>Lesson</b><span>Ten concepts, each with one guided problem, ending with pick grids.</span></a>
<a href="{PAGES["practice"]}"><b>Practice</b><span>All 18 problems from Problem Set 3, Problem 2.4 from the lecture note, and 13 challenge problems from the unit test.</span></a>
</div>
<h2>How to think about any counting problem</h2>{PLAN}
<h2>How grading works</h2>
<p>Each problem is split into a few steps. Write your method in the work area, put the result in the answer box and press <b>Check step</b>.</p>
<ul><li>A wrong answer gets a nudge, a question to ask yourself. Nudges get more specific with each try.</li>
<li>You get three tries and then one final attempt. If that misses too, the step's answer is shown and you carry on with the next step yourself.</li>
<li><b>Hint for this step</b> opens a hint only when you press it. It doesn't use a try, but it is recorded.</li>
<li><b>Submit question</b> prints how each step went and unlocks the checked answer once every step is closed.</li></ul>
<h2>The pen</h2>
<p>Press <b>Pen</b> (or the P key) to draw on any page while explaining. On the notes page the ink sticks to the text as you scroll, and a finger scrolls while a stylus or mouse draws. On the lesson and practice pages the ink is kept separately for each problem. Nothing is saved when the tab closes.</p>
</main>"""
    return page("Week 3 · Rule of Product", body, read("base.css") + read("notes.css"), read("pen.js") + "\n" + read("story.js"), "page")

if __name__ == "__main__":
    OUT.mkdir(exist_ok=True)
    for k, fn in [("index", index_page), ("notes", notes_page), ("lesson", lambda: workbench("lesson")), ("practice", lambda: workbench("practice"))]:
        (OUT / PAGES[k]).write_text(fn()); print("wrote", PAGES[k], len((OUT / PAGES[k]).read_text()) // 1024, "KB")
