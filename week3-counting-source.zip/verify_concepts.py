from itertools import product, permutations, combinations
from math import factorial as f
R=[]
def chk(n,b,a): R.append(b==a); print(('OK ' if b==a else 'XX '), f"{n:36s} brute={b:<8} arg={a}")
chk("lunches 5x2x3", len(list(product(range(5),range(2),range(3)))), 30)
chk("2-digit using 0-3", sum(1 for n in range(10,100) if set(str(n))<=set('0123')), 3*4)
chk("4 beads exactly one red", sum(1 for g in product('RWB',repeat=4) if g.count('R')==1), 4*2**3)
chk("5 friends in a line", len(set(permutations(range(5)))), f(5))
chk("4-letter codes A-F no repeat", len(list(permutations('ABCDEF',4))), 6*5*4*3)
chk("2-digit different digits", sum(1 for n in range(10,100) if len(set(str(n)))==2), 81)
chk("TOO", len(set(permutations('TOO'))), f(3)//f(2))
chk("BEEE", len(set(permutations('BEEE'))), f(4)//f(3))
chk("AABB", len(set(permutations('AABB'))), f(4)//(f(2)*f(2)))
chk("6!/4!", f(6)//f(4), 30)
lab=set();unl=set()
for p in permutations(range(8)):
    st=(p[:4],p[4:]); lab.add(st); unl.add(frozenset(st))
chk("8 books 2 stacks labeled", len(lab), f(8)); chk("8 books identical boxes", len(unl), f(8)//2)
chk("RGB length 4 no immediate repeat", sum(1 for w in product('RGB',repeat=4) if all(w[i]!=w[i+1] for i in range(3))), 3*2**3)
chk("teams of 3 from 5", len(list(combinations(range(5),3))), 5*4*3//6)
print("ALL AGREE:", all(R), f"({len(R)} checks)")
