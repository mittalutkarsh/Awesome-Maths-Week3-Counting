import asyncio, sys
from playwright.async_api import async_playwright
from PIL import Image
async def main(page_url, sid, out, width=760):
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell')
        pg = await b.new_page(viewport={'width':1300,'height':1000})
        await pg.goto(page_url); await pg.wait_for_timeout(200)
        el = pg.locator(f'[id="{sid}"]')
        n = int(await el.get_attribute('data-n')); shots=[]
        for i in range(n):
            await pg.evaluate(f"STORY.show(document.getElementById('{sid}'), {i})")
            f = f'/tmp/{sid}_{i}.png'; await el.screenshot(path=f); shots.append(Image.open(f))
        await b.close()
    cols = 2; w = max(s.width for s in shots); rows = (len(shots)+1)//2
    hs = [max(s.height for s in shots[r*2:r*2+2]) for r in range(rows)]
    sheet = Image.new('RGB', (w*cols, sum(hs)), 'white'); y=0
    for r in range(rows):
        for c in range(2):
            k=r*2+c
            if k < len(shots): sheet.paste(shots[k], (c*w, y))
        y += hs[r]
    sheet.thumbnail((1800, 4000)); sheet.save(out)
asyncio.run(main(*sys.argv[1:4]))
