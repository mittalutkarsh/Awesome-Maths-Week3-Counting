import re, pathlib, json, sys
sys.path.insert(0, '/home/claude/w3')
OUT = pathlib.Path('/home/claude/w3/out'); SRC = pathlib.Path('/home/claude/w3/src')
from data.practice import P; from data.lesson import L
def ids_in(js):
    req = set(re.findall(r"\$id\('([^']+)'\)", js)); opt = set(re.findall(r"\$opt\('([^']+)'\)", js))
    lit = set(re.findall(r"getElementById\('([^']+)'\)", js))
    return req, opt, lit
wb_req, wb_opt, wb_lit = ids_in((SRC/'workbench.js').read_text())
pen_req, _, pen_lit = ids_in((SRC/'pen.js').read_text())
dyn = {'lesson': {'tab-problem', 'tab-concept', 'tab-steps'}, 'practice': {'tab-problem', 'tab-rules', 'tab-steps'}}
bad = 0
for f, kind in [('index.html', None), ('counting-notes.html', None), ('counting-lesson.html', 'lesson'), ('counting-practice.html', 'practice')]:
    h = (OUT/f).read_text(); ids = set(re.findall(r'\bid="([^"]+)"', h))
    need = set(pen_req) | set(pen_lit)
    if kind: need |= wb_req | dyn[kind] | (wb_lit - {'rail-'})
    if kind == 'lesson': need |= wb_opt
    missing = sorted(need - ids); bad += len(missing)
    print(f"{f:26s} ids touched by JS: {len(need):2d}  missing: {missing or 'none'}")
print("JS ids (workbench):", sorted(wb_req | wb_opt)); print("JS ids (pen):", sorted(pen_req))
print("dynamic: rail-<problem id> (built by JS from data), tab-<name> per page:", dyn)
# links and anchors
pids = {'counting-practice.html': {p['id'] for p in P}, 'counting-lesson.html': {p['id'] for p in L}}
nlinks = 0
for f in OUT.glob('*.html'):
    h = f.read_text(); ids = set(re.findall(r'\bid="([^"]+)"', h))
    for href in re.findall(r'href="([^"]+)"', h):
        if href.startswith('https://fonts.') or "' +" in href: continue
        nlinks += 1
        path, _, frag = href.partition('#')
        if path.startswith(('http:', 'https:', '/')): print("NOT RELATIVE", f.name, href); bad += 1; continue
        target = f.name if not path else path
        if not (OUT/target).exists(): print("MISSING FILE", f.name, href); bad += 1; continue
        if frag:
            if target in pids and frag in pids[target]: continue
            tids = set(re.findall(r'\bid="([^"]+)"', (OUT/target).read_text()))
            if frag not in tids and target not in pids: print("MISSING ANCHOR", f.name, href); bad += 1
            elif target in pids and frag not in pids[target] and frag not in tids: print("MISSING PROBLEM", f.name, href); bad += 1
print(f"links checked: {nlinks}, problems: {bad}")
