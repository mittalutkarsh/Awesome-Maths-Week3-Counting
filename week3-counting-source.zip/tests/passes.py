"""Scripted passes against the generated pages in headless Chromium."""
import asyncio, json, html, sys
from playwright.async_api import async_playwright
OUT = "file:///home/claude/w3/out/"
EXE = "/opt/pw-browsers/chromium_headless_shell-1194/chrome-linux/headless_shell"
R = {}

CANON = """(s)=> s.type==='nums' ? s.ans.join(', ') : s.type==='choice' ? s.ans : String(s.ans)"""

HELPERS = """
window.__T = {
  canon: %s,
  answer(v){ const a=document.getElementById('answer'); a.value=v; document.getElementById('check-btn').click(); },
  log(){ return document.getElementById('console').innerText; },
  visibleText(){ return document.body.innerText; },
};""" % CANON

async def errors_of(page):
    return await page.evaluate("window.__errs || []")

async def fresh(ctx, url, hostile=False):
    pg = await ctx.new_page()
    pg.__errs = []
    pg.on("pageerror", lambda e: pg.__errs.append(str(e)))
    if hostile:
        await pg.add_init_script("""
          window.confirm = () => { throw new Error('confirm blocked'); };
          window.alert = () => { throw new Error('alert blocked'); };
          window.prompt = () => { throw new Error('prompt blocked'); };
          history.replaceState = () => { throw new Error('replaceState blocked'); };
          Object.defineProperty(window, 'localStorage', { get(){ throw new Error('localStorage blocked'); } });
          Object.defineProperty(window, 'sessionStorage', { get(){ throw new Error('sessionStorage blocked'); } });""")
    await pg.goto(url)
    await pg.evaluate(HELPERS)
    return pg

# ---------- pass 1: every step right, first try ----------
PASS1 = """() => {
  const D = WB.data, res = {steps:0, first:0, closed:0, verified:0, problems:D.problems.length, leaks:[]};
  for (const p of D.problems) {
    WB.go(p.id);
    p.steps.forEach((s, i) => {
      // nothing hint-like visible before the hint button: hint, reveal and worked text absent from rendered text
      const vis = __T.visibleText();
      for (const [k, t] of [['hint', s.hint], ['reveal', s.reveal], ['worked', p.worked]])
        if (vis.includes(t)) res.leaks.push(p.id + ' s' + (i+1) + ' ' + k);
      if (p.solfig) { const f = document.querySelector('#problem-body .pfig, #tab-problem .pfig:not([hidden])');
        if (f && f.offsetParent) res.leaks.push(p.id + ' grid visible early'); }
      __T.answer(__T.canon(s));
      res.steps++;
      if (WB.state[p.id].steps[i].status === 'first') res.first++;
    });
    if (p.steps.every((s,i) => WB.state[p.id].steps[i].status !== 'open')) res.closed++;
    document.getElementById('submit-btn').click();
    if (!document.getElementById('verified').hidden && document.getElementById('verified').innerText.includes(p.answer)) res.verified++;
    if (p.solfig && !document.querySelector('#verified .pfig')) res.leaks.push(p.id + ' grid missing after verify');
  }
  res.doneText = document.getElementById('done-count').textContent;
  return res; }"""

# alternate forms accepted
FORMS = """() => {
  const tries = [['q9',1,'11!/(4!4!2!)'],['q9',1,'11!/(4!·4!·2!)'],['q13',2,'3×2⁹'],['q13',2,'2^9*3'],['q15',3,'5·26²·10⁴'],
    ['q15',3,'33,800,000'],['q15',3,'2^6*5^5*13^2'],['q18',2,'2^12+2^13'],['q8',0,'1,1,2,3'],['q8',0,'3 and 2 and 1 and 1'],
    ['q17',0,'no'],['q17',0,'b'],['q19',1,'N']];
  const out = [];
  for (const [id, k, v] of tries) {
    const s = WB.data.problems.find(p => p.id === id).steps[k];
    const r = Check.grade(s, v, {}); out.push([id, k, v, !!r.ok]);
  }
  return out; }"""

# ---------- pass 2: miss one step four times ----------
PASS2 = """() => {
  WB.go('q2'); const p = WB.data.problems.find(x => x.id === 'q2'), s = p.steps[0], out = [];
  const wrong = ['5', '9', '3', '7'];
  wrong.forEach((w, n) => { __T.answer(w); const st = WB.state.q2.steps[0];
    out.push({ try: n+1, tries: st.tries, status: st.status, final: st.final, readout: document.getElementById('tries').textContent,
      lastLog: [...document.querySelectorAll('#console .log')].pop().innerText }); });
  return { out, nudges: s.nudges, reveal: s.reveal, nowOn: WB.state.q2.step, step2: WB.state.q2.steps[1] }; }"""

# ---------- pass 3: hint mid-attempt ----------
PASS3 = """() => {
  WB.go('q8'); WB.state.q8.step = 1; WB.go('q8');
  const before = { dialogHidden: document.getElementById('hint-dialog').hidden };
  __T.answer('840');
  const t1 = WB.state.q8.steps[1].tries;
  document.getElementById('hint-btn').click();
  const open = { hidden: document.getElementById('hint-dialog').hidden, text: document.getElementById('hint-text').textContent,
    tries: WB.state.q8.steps[1].tries, hints: WB.state.q8.steps[1].hints, bodyClass: document.body.classList.contains('dialog-open') };
  return { before, t1, open, hint: WB.data.problems.find(x=>x.id==='q8').steps[1].hint }; }"""

async def run_workbench(ctx, page_name, hostile=False):
    url = OUT + page_name
    pg = await fresh(ctx, url, hostile)
    r = {}
    r["pass1"] = await pg.evaluate(PASS1)
    pg2 = await fresh(ctx, url, hostile)
    if page_name.endswith("practice.html"):
        r["forms"] = await pg2.evaluate(FORMS)
        r["pass2"] = await pg2.evaluate(PASS2)
        r["pass3"] = await pg2.evaluate(PASS3)
        await pg2.keyboard.press("Escape")
        r["pass3"]["afterEscape"] = await pg2.evaluate("({hidden: document.getElementById('hint-dialog').hidden, readout: document.getElementById('tries').textContent, penOn: INK.isOn()})")
        await pg2.evaluate("__T.answer('420')")
        r["pass3"]["afterRight"] = await pg2.evaluate("({status: WB.state.q8.steps[1].status, tries: WB.state.q8.steps[1].tries, hints: WB.state.q8.steps[1].hints})")
        # pass 4: reveal + navigation
        p4 = {}
        await pg2.evaluate("WB.go('q5')")
        await pg2.click("#worked-btn")
        p4["afterOneClick"] = await pg2.evaluate("({workedHidden: document.getElementById('worked').hidden, btn: document.getElementById('worked-btn').textContent})")
        await pg2.click("#worked-btn")
        p4["afterTwoClicks"] = await pg2.evaluate("({workedHidden: document.getElementById('worked').hidden})")
        await pg2.evaluate("WB.go('q6')"); await pg2.click("#submit-btn")
        p4["submitOpen"] = await pg2.evaluate("({verifiedHidden: document.getElementById('verified').hidden, log: [...document.querySelectorAll('#console .log')].pop().innerText})")
        await pg2.click("#next-btn"); p4["afterNext"] = await pg2.evaluate("[WB.current(), location.hash]")
        await pg2.click("#prev-btn"); p4["afterPrev"] = await pg2.evaluate("[WB.current(), location.hash]")
        await pg2.select_option("#prob-select", "q14"); p4["afterSelect"] = await pg2.evaluate("[WB.current(), location.hash]")
        await pg2.click("#rail-u25"); p4["afterRail"] = await pg2.evaluate("[WB.current(), location.hash]")
        # keyboard: Enter from answer box, Ctrl+Enter from editor
        await pg2.evaluate("WB.go('q1')"); await pg2.fill("#answer", "9"); await pg2.press("#answer", "Enter")
        p4["enterChecks"] = await pg2.evaluate("WB.state.q1.steps[0].status")
        await pg2.fill("#answer", "900"); await pg2.focus("#editor"); await pg2.keyboard.press("Control+Enter")
        p4["ctrlEnterChecks"] = await pg2.evaluate("WB.state.q1.steps[1].status")
        t0 = await pg2.evaluate("WB.state.q4.time"); await pg2.evaluate("WB.go('q4')"); await pg2.wait_for_timeout(2200)
        p4["timerAdvanced"] = (await pg2.evaluate("WB.state.q4.time")) - t0
        deep = await fresh(ctx, url + "#q8", hostile)
        p4["deepLink#q8"] = await deep.evaluate("WB.current()")
        p4["errors"] = pg2.__errs + deep.__errs + pg.__errs
        r["pass4"] = p4
        await deep.close()
    else:
        r["pass4"] = {"errors": pg.__errs}
    await pg.close(); await pg2.close()
    return r

# ---------- pass 5: the pen ----------
async def draw(pg, pts, shift=False):
    await pg.mouse.move(*pts[0])
    if shift: await pg.keyboard.down("Shift")
    await pg.mouse.down()
    for p in pts[1:]: await pg.mouse.move(*p, steps=2)
    await pg.mouse.up()
    if shift: await pg.keyboard.up("Shift")

async def pen_pass(ctx, hostile=False):
    pg = await fresh(ctx, OUT + "counting-practice.html", hostile)
    out = {}
    await pg.focus("#answer"); await pg.keyboard.type("p")
    out["P_in_answer_box"] = await pg.evaluate("({penOn: INK.isOn(), answer: document.getElementById('answer').value})")
    await pg.evaluate("document.getElementById('answer').value=''; document.activeElement.blur()")
    await pg.keyboard.press("p"); out["P_toggles_on"] = await pg.evaluate("INK.isOn()")
    line = [(500, 300), (560, 330), (620, 320), (700, 360)]
    counts = {}
    for tool in ["pen", "marker", "line", "box"]:
        await pg.click(f'#pen-bar [data-tool="{tool}"]')
        await draw(pg, [(x, y + 60 * len(counts)) for x, y in line])
        counts[tool] = await pg.evaluate("INK.get().length")
    await pg.click('#pen-bar [data-tool="pen"]')
    for c in ["#b8322a", "#2e7d5b", "#c98a12"]:
        await pg.click(f'#pen-bar [data-color="{c}"]'); await draw(pg, [(300, 600), (360, 620)])
    for w in ["fine", "bold"]:
        await pg.click(f'#pen-bar [data-width="{w}"]'); await draw(pg, [(300, 650), (380, 660)])
    out["strokes_after_tools"] = await pg.evaluate("INK.get().map(s => s.tool + ':' + s.color + ':' + s.w.toFixed(1))")
    await draw(pg, [(400, 700), (430, 720), (470, 715), (520, 760)], shift=True)
    out["shift_snap"] = await pg.evaluate("(() => { const s = INK.get().at(-1); return {points: s.pts.length, straight: !!s.straight}; })()")
    n = await pg.evaluate("INK.get().length")
    await pg.click('#pen-bar [data-tool="eraser"]'); await draw(pg, [(560, 320), (565, 325)])
    out["eraser"] = {"before": n, "after": await pg.evaluate("INK.get().length")}
    # palm rejection
    await pg.click('#pen-bar [data-act="stylus"]'); await pg.click('#pen-bar [data-tool="pen"]')
    before = await pg.evaluate("INK.get().length")
    synth = """(type) => { const c = document.getElementById('ink-live');
      const ev = (t, x, y) => c.dispatchEvent(new PointerEvent(t, {pointerType: type, pointerId: 7, clientX: x, clientY: y, bubbles: true, button: 0, isPrimary: true}));
      ev('pointerdown', 200, 200); ev('pointermove', 240, 230); ev('pointermove', 280, 250); ev('pointerup', 280, 250); return INK.get().length; }"""
    after_touch = await pg.evaluate(synth, "touch")
    await pg.wait_for_timeout(50)
    after_pen = await pg.evaluate(synth, "pen")
    out["palm_rejection"] = {"before": before, "after_touch": after_touch, "after_stylus": after_pen,
                             "touchIgnored": await pg.evaluate("INK.stats.touchIgnored")}
    # undo / redo / clear
    n = await pg.evaluate("INK.get().length")
    await pg.keyboard.press("Control+z"); u1 = await pg.evaluate("INK.get().length")
    await pg.keyboard.press("Control+Shift+z"); r1 = await pg.evaluate("INK.get().length")
    await pg.click('#pen-bar [data-act="clear"]'); c1 = await pg.evaluate("INK.get().length")
    await pg.click('#pen-bar [data-act="undo"]'); c2 = await pg.evaluate("INK.get().length")
    out["undo_redo_clear"] = {"start": n, "ctrlZ": u1, "ctrlShiftZ": r1, "clear": c1, "undoClear": c2}
    # export
    out["export_bytes"] = await pg.evaluate("new Promise(res => INK.exportPNG(b => res(b ? b.size : 0)))")
    # ink parked per problem
    await pg.evaluate("WB.go('q1')"); a = await pg.evaluate("INK.get().length")
    await pg.evaluate("WB.go('q2')"); b = await pg.evaluate("INK.get().length")
    await draw(pg, [(600, 500), (650, 520)]); await draw(pg, [(600, 540), (650, 560)])
    b2 = await pg.evaluate("INK.get().length")
    await pg.evaluate("WB.go('q1')"); a2 = await pg.evaluate("INK.get().length")
    await pg.evaluate("WB.go('q2')"); b3 = await pg.evaluate("INK.get().length")
    out["ink_per_problem"] = {"q1_before_switch": a, "q2_fresh": b, "q2_drawn": b2, "q1_restored": a2, "q2_restored": b3}
    # viewport mode swallows scrolling
    await pg.set_viewport_size({"width": 1440, "height": 520})
    await pg.evaluate("WB.go('q18')")
    s0 = await pg.evaluate("document.getElementById('rail').scrollTop")
    await pg.mouse.move(100, 400); await pg.mouse.wheel(0, 400); await pg.wait_for_timeout(200)
    s1 = await pg.evaluate("document.getElementById('rail').scrollTop")
    await pg.keyboard.press("Escape"); off = await pg.evaluate("INK.isOn()")
    await pg.mouse.wheel(0, 400); await pg.wait_for_timeout(200)
    s2 = await pg.evaluate("document.getElementById('rail').scrollTop")
    out["viewport_mode"] = {"mode": await pg.evaluate("INK.mode"), "rail_scroll_pen_on": s1 - s0, "escape_turns_off": not off, "rail_scroll_pen_off": s2 - s1}
    out["errors"] = pg.__errs
    await pg.close()
    # page mode on notes: ink glued to content, page scrolls with pen on
    npg = await fresh(ctx, OUT + "counting-notes.html", hostile)
    await npg.keyboard.press("p"); await draw(npg, [(700, 300), (760, 320), (820, 310)])
    p0 = await npg.evaluate("INK.get()[0].pts[0]")
    await npg.mouse.move(700, 500); await npg.mouse.wheel(0, 900); await npg.wait_for_timeout(300)
    sy = await npg.evaluate("scrollY"); p1 = await npg.evaluate("INK.get()[0].pts[0]")
    out["page_mode"] = {"mode": await npg.evaluate("INK.mode"), "scrolled_with_pen_on": sy, "stroke_doc_coords_unchanged": p0 == p1,
                        "first_point_y": p0["y"]}
    out["errors"] += npg.__errs
    await npg.close()
    return out

# ---------- pen performance ----------
async def pen_perf(ctx):
    pg = await fresh(ctx, OUT + "counting-practice.html")
    await pg.evaluate("""() => { const strokes = [];
      for (let s = 0; s < 40; s++) { const pts = [];
        for (let k = 0; k < 50; k++) pts.push({x: 250 + k * 14, y: 60 + s * 20 + Math.sin(k / 3) * 6, w: 3.2});
        strokes.push({tool: 'pen', color: '#1b3358', w: 3.2, pts}); }
      INK.set(strokes); INK.on(); INK.resetStats(); }""")
    pts = [(300 + i * 6, 400 + (i % 10) * 3) for i in range(120)]
    t0 = await pg.evaluate("performance.now()")
    await draw(pg, pts)
    t1 = await pg.evaluate("performance.now()")
    st = await pg.evaluate("INK.stats")
    res = {"existing_strokes": 40, "existing_points": 2000, "old_strokes_redrawn_while_drawing": st["oldStrokesRedrawnWhileDrawing"],
           "frames_while_drawing": st["framesWhileDrawing"], "segments_drawn": st["segmentsDrawn"], "commits": st["commits"],
           "canvas_megapixels_total": round(await pg.evaluate("INK.megapixels()"), 2), "dpr": await pg.evaluate("devicePixelRatio"),
           "stroke_ms": round(t1 - t0)}
    await pg.close()
    # retina: DPR 2 context, same 1440x900 viewport
    return res

# ---------- the real sandbox: about:srcdoc iframe with allow-scripts only ----------
async def sandbox_iframe(ctx, name):
    src = open("/home/claude/w3/out/" + name).read()
    src = src.replace("<head>", "<head><script>window.__errs=[];addEventListener('error',e=>__errs.push(String(e.message)));</script>", 1)
    host = await ctx.new_page()
    await host.set_content(f'<iframe id="f" sandbox="allow-scripts" style="width:1400px;height:880px" srcdoc="{html.escape(src, quote=True)}"></iframe>')
    await host.wait_for_timeout(600)
    fr = host.frames[1]
    await fr.evaluate(HELPERS)
    info = await fr.evaluate("({protocol: location.protocol, current: WB.current(), rendered: document.getElementById('problem-body').innerText.length > 20})")
    p1 = await fr.evaluate(PASS1)
    await fr.evaluate("WB.go(WB.order[3])")
    await fr.click("#worked-btn"); await fr.click("#worked-btn")
    worked = await fr.evaluate("!document.getElementById('worked').hidden")
    await fr.evaluate("INK.on(); INK.set([{tool:'pen',color:'#1b3358',w:3,pts:[{x:10,y:10,w:3},{x:40,y:40,w:3}]}]); INK.clear(); INK.undo()")
    ink = await fr.evaluate("INK.get().length")
    errs = await fr.evaluate("window.__errs")
    await host.close()
    return {"frame": info, "steps": p1["steps"], "first": p1["first"], "closed": p1["closed"], "verified": p1["verified"],
            "worked_two_click": worked, "pen_undo_in_frame": ink, "errors": errs}

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path=EXE)
        ctx = await b.new_context(viewport={"width": 1440, "height": 900}, accept_downloads=True)
        R["practice"] = await run_workbench(ctx, "counting-practice.html")
        R["lesson"] = await run_workbench(ctx, "counting-lesson.html")
        R["pen"] = await pen_pass(ctx)
        R["perf_dpr1"] = await pen_perf(ctx)
        ctx2 = await b.new_context(viewport={"width": 1440, "height": 900}, device_scale_factor=3)
        R["perf_dpr3_capped"] = await pen_perf(ctx2)
        R["hostile_practice"] = await run_workbench(ctx, "counting-practice.html", hostile=True)
        R["hostile_lesson"] = await run_workbench(ctx, "counting-lesson.html", hostile=True)
        R["hostile_pen"] = await pen_pass(ctx, hostile=True)
        R["srcdoc_practice"] = await sandbox_iframe(ctx, "counting-practice.html")
        R["srcdoc_lesson"] = await sandbox_iframe(ctx, "counting-lesson.html")
        mob = await b.new_context(viewport={"width": 390, "height": 844}, device_scale_factor=2, has_touch=True)
        mp = await fresh(mob, OUT + "counting-practice.html")
        await mp.click("#rail-toggle")
        R["mobile"] = await mp.evaluate("({railShown: getComputedStyle(document.getElementById('rail')).display !== 'none', "
                                        "cols: getComputedStyle(document.querySelector('.panes')).gridTemplateColumns})")
        await mp.screenshot(path="/home/claude/w3/tests/mobile.png", full_page=False)
        await b.close()
    json.dump(R, open("/home/claude/w3/tests/passes.json", "w"), indent=1, ensure_ascii=False)

asyncio.run(main())
print("done")
