const C = require('../src/checker.js');
let pass=0, fail=0;
function t(step, raw, ok, msgPart){ const r=C.grade(step, raw, {prev:[9]}); const good = ok==='parse'? !!r.parseError : (!!r.ok===ok && (!msgPart || (r.msg||'').includes(msgPart)));
  if(good) pass++; else {fail++; console.log('FAIL', raw, JSON.stringify(r));} }
const n = a=>({type:'num',ans:a,errors:{}}), e=a=>({type:'expr',ans:a,errors:{}});
t(n(440),'2^3*5*11',true); t(n(440),'2*2*2*5*11',true); t(n(440),'2³·5·11',true); t(n(440),'2 x 2 x 2 x 5 x 11',true);
t(n(33800000),'33,800,000',true); t(n(33800000),'5×26²×10⁴',true); t(n(33800000),'2^6·5^5·13^2',true);
t(e(34650),'11!/(4!4!2!)',true); t(e(34650),'11!/4!4!2!',true); t(e(34650),'11! / (4! · 4! · 2!)',true); t(e(34650),'34650',true);
t(e(217945728000),'15!/3!',true); t(e(217945728000),'15!/6',true); t(e(12288),'2^12+2^13',true); t(e(12288),'3*2^12',true);
t(n(100),'101',false,'Very close'); t(n(100),'150',false,'Too big'); t(n(100),'20',false,'Too small'); t(n(100),'9',false,'step 1');
t(n(100),'1,2','parse'); t(n(100),'abc','parse'); t(n(100),'','parse');
t({type:'nums',ans:[2,2017]},'2, 2017',true); t({type:'nums',ans:[2,2017]},'2 and 2017',true); t({type:'nums',ans:[3,2,1,1]},'1,1,2,3',true);
t({type:'nums',ans:[3,2,1,1]},'3,2,1,2',false,'one is off'); t({type:'nums',ans:[3,2,1,1]},'3,2,2',false,'3 values');
t({type:'choice',ans:'B',options:['Yes','No']},'b',true); t({type:'choice',ans:'B',options:['Yes','No']},'No',true); t({type:'choice',ans:'B',options:['Yes','No']},'(B)',true);
t({type:'choice',ans:'B',options:['Yes','No']},'n',true); t({type:'choice',ans:'B',options:['Yes','No']},'yes',false); t({type:'choice',ans:'B',options:['Yes','No']},'maybe','parse');
t({type:'factor',ans:440,errors:{}},'2^3*5*11',true); t({type:'factor',ans:440,errors:{}},'4*2*5*11',false,'composite'); t({type:'factor',ans:440,errors:{}},'2^3*55',false,'composite');
t({type:'text',ans:null,accept:['\\bno\\b','never'],reject:['\\byes\\b']},'no it cannot',true); t({type:'text',ans:null,accept:['\\bno\\b'],reject:['\\byes\\b']},'yes',false,'opposite');
t({type:'num',ans:80,errors:{'81':'Your count lets yellow'}},'3^4',false,'Your count lets yellow');
console.log(`checker unit tests: ${pass} passed, ${fail} failed`); process.exit(fail?1:0);
