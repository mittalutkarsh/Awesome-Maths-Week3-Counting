from itertools import product, permutations
from math import factorial as f
R={}
def chk(name, brute, arg):
    ok = brute==arg; R[name]=(brute,arg,ok); print(f"{'OK ' if ok else 'XX '} {name:34s} brute={brute:<14} argument={arg}")

chk("Ex1.1 outfits", len(list(product(range(4),range(3),range(2)))), 4*3*2)
chk("Ex1.2 5-digit numbers", sum(1 for n in range(10**4,10**5)), 9*10**4)
chk("Ex1.3 5-digit all odd", sum(1 for n in range(10**4,10**5) if all(int(c)%2 for c in str(n))), 5**5)
chk("P1.1 3-digit numbers", sum(1 for n in range(100,1000)), 9*10*10)
chk("P1.2 3-digit all even", sum(1 for n in range(100,1000) if all(int(c)%2==0 for c in str(n))), 4*5*5)
chk("P1.3 exactly one yellow", sum(1 for g in product("YGB",repeat=5) if g.count("Y")==1), 5*2**4)
chk("Ex1.4 arrange ABC", len(set(permutations("ABC"))), f(3))
chk("0! empty arrangement", len(list(permutations([]))), f(0))
chk("Ex1.5 5-digit distinct", sum(1 for n in range(10**4,10**5) if len(set(str(n)))==5), 9*9*8*7*6)
chk("P2.1 arrange AMC", len(set(permutations("AMC"))), f(3))
chk("P2.2 arrange MATH", len(set(permutations("MATH"))), f(4))
chk("P2.3 3-digit distinct", sum(1 for n in range(100,1000) if len(set(str(n)))==3), 9*9*8)
chk("Ex1.6 AABC", len(set(permutations("AABC"))), f(4)//f(2))
chk("Ex1.7 AAABC", len(set(permutations("AAABC"))), f(5)//f(3))
chk("P3.1 HELLO", len(set(permutations("HELLO"))), f(5)//f(2))
chk("P3.2 GREENER", len(set(permutations("GREENER"))), f(7)//(f(3)*f(2)))
# MISSISSIPPI: 11!/... too many perms to set(); count distinct by placing letters
from itertools import combinations
cnt=0
for I in combinations(range(11),4):
    rest=[i for i in range(11) if i not in I]
    for S in combinations(rest,4):
        rest2=[i for i in rest if i not in S]
        for P in combinations(rest2,2): cnt+=1
chk("P3.3 MISSISSIPPI", cnt, f(11)//(f(4)*f(4)*f(2)))
# Coins: scaled brute (6 coins, 3 stacks of 2) to confirm the structure, then full value by argument
def stacks(n,k):
    coins=range(n*k); lab=set(); unl=set()
    for p in permutations(coins):
        st=tuple(tuple(p[i*k:(i+1)*k]) for i in range(n)); lab.add(st); unl.add(frozenset(st))
    return len(lab),len(unl)
lab,unl=stacks(3,2)
chk("Coins scaled 3x2 distinct tubes", lab, f(6))
chk("Coins scaled 3x2 identical tubes", unl, f(6)//f(3))
lab,unl=stacks(3,3)
chk("Coins scaled 3x3 identical tubes", unl, f(9)//f(3))
print("   Coins full: 15! =", f(15), " 15!/3! =", f(15)//6)
# Lopez: people 0,1 adults; seat 0 driver
chk("2.1 Lopez seating", sum(1 for p in permutations(range(4)) if p[0] in (0,1)), 2*3*2*1)
bad={("A","B"),("B","C"),("C","A")}
chk("2.2 good words len 7", sum(1 for w in product("ABC",repeat=7) if not any((w[i],w[i+1]) in bad for i in range(6))), 3*2**6)
deck=list(product(range(3),repeat=3))
ok=lambda a,b,c: all(len({a[i],b[i],c[i]}) in (1,3) for i in range(3))
chk("2.3 complementary sets", sum(1 for s in combinations(deck,3) if ok(*s)), 27*26//6)
# extra checks used in the traps
print("   Trap: 'first square yellow' count =", 2**4, "; '3 each then ×1' =", 3**4)
print("   Trap: AAABC ÷3 would give", f(5)/3, "(not an integer is not the point; 40 ≠ 20)")
print("   Trap: coins ÷(5!)^3 would give", f(15)/(f(5)**3*6))
print("   Trap: cards unordered-not-divided =", 27*26)
print("   Check 5-digit distinct: 27216 ; 3-digit distinct via complement 900-(#with repeat) =", 900-sum(1 for n in range(100,1000) if len(set(str(n)))<3))
print("\nALL AGREE:", all(v[2] for v in R.values()), f"({len(R)} checks)")
