from itertools import product, permutations, combinations
from math import factorial as f
R=[]
def chk(n,b,a): R.append(b==a); print(('OK ' if b==a else 'XX '), f"{n:44s} brute={b:<6} arg={a}")
chk("plan: ordered helper picks from 4", len(list(permutations('ABCD',2))), 12)
chk("plan: helper pairs from 4", len(list(combinations('ABCD',2))), 6)
chk("q2 even-digit numbers starting with 2", sum(1 for n in range(200,300) if all(int(c)%2==0 for c in str(n))), 25)
chk("q3 1x2 exactly one yellow", sum(g.count('Y')==1 for g in product('YGB',repeat=2)), 4)
chk("q6 two-digit different digits", sum(len(set(str(n)))==2 for n in range(10,100)), 81)
chk("q7 LOL", len(set(permutations('LOL'))), 3); chk("q8 EER", len(set(permutations('EER'))), 3); chk("q9 SIS", len(set(permutations('SIS'))), 3)
chk("q10 Al left: girl orders", len(list(permutations('GHI'))), 6)
chk("q13 two kids", sum(1 for a,b in product((1,2,3),repeat=2) if a+b!=4), 6)
pl=set()
for s in product('AB01',repeat=3):
    L=[i for i,c in enumerate(s) if c in 'AB']
    if len(L)==2 and L[1]-L[0]==1: pl.add(s)
chk("q15 tiny plates", len(pl), 16)
def nocarry(a,b):
    while a or b:
        if a%10+b%10>9: return False
        a//=10;b//=10
    return True
chk("q17 simple pairs summing to 12", sum(nocarry(a,12-a) for a in range(13)), 6)
chk("q18 1x2 grid", sum(1 for a,b in product((0,1,2),repeat=2) if abs(a-b)==1), 4)
chk("q19 increasing from digits 1-3", sum(1 for k in range(1,4) for c in combinations('123',k)), 7)
chk("q14 row starting with 1", sum(1 for n in range(100,200) if 2*(n//10%10)==1+n%10), 5)
chk("u5 palindromes starting with 1", sum(1 for n in range(100,200) if str(n)==str(n)[::-1]), 10)
chk("u16 four kids short first tall last", sum(1 for p in permutations(range(4)) if p[0]==0 and p[-1]==3), 2)
chk("u17 three books, volumes together", sum(1 for p in permutations(['V1','V2','P']) if abs(p.index('V1')-p.index('V2'))==1), 4)
chk("u23 4 people handshakes", len(list(combinations(range(4),2))), 6)
sq={frozenset((i,(i+1)%4)) for i in range(4)}; pe={frozenset((i,(i+1)%5)) for i in range(5)}
chk("u24 square diagonals", sum(frozenset(e) not in sq for e in combinations(range(4),2)), 2)
chk("u24 pentagon diagonals", sum(frozenset(e) not in pe for e in combinations(range(5),2)), 5)
chk("u26 trios from 4", len(list(combinations('ABCD',3))), 4)
chk("u28 2 red x 2 black", len(list(product('12','12'))), 4)
chk("c2 two-digit odd digits", sum(all(int(c)%2 for c in str(n)) for n in range(10,100)), 25)
chk("c3 Mr drives: others", len(list(permutations('MKL'))), 6)
chk("c6 AABC list", len(set(permutations('AABC'))), 12)
print(sorted(''.join(p) for p in set(permutations('AABC'))))
lab=set(); unl=set()
for p in permutations('1234'): st=(p[:2],p[2:]); lab.add(st); unl.add(frozenset(st))
chk("c7 small coins labeled", len(lab), 24); chk("c7 small coins identical", len(unl), 12)
bad={('A','B'),('B','C'),('C','A')}
chk("c8 two-letter good words", sum(1 for w in product('ABC',repeat=2) if w not in bad), 6)
w='AACBBAC'; print("c8 example good word valid:", all((w[i],w[i+1]) not in bad for i in range(6)))
from collections import Counter
for ex,word in [("LOHEL","HELLO"),("ENGREER","GREENER"),("SIMPISSIPIS","MISSISSIPPI"),("CABA","AABC"),("MCA","AMC"),("HTAM","MATH"),("CAB","ABC")]:
    print(f"example {ex} uses letters of {word}:", Counter(ex)==Counter(word))
print("ALL AGREE:", all(R), f"({len(R)} checks)")
