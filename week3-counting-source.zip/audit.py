"""Leakage audit: search every step question, nudge, hint and placeholder (plus text visible by default on
the same screen: the lesson Concept tab and the practice Rules tab) for that step's own answer as a numeral,
in comma form, as a number word, or as any arithmetic/factorial/prime-power expression that evaluates to it."""
import re, sys, math
from data.practice import P
from data.lesson import L, C
import build

WORDS = "zero one two three four five six seven eight nine ten eleven twelve thirteen fourteen fifteen sixteen seventeen eighteen nineteen twenty".split()
SUP = str.maketrans("⁰¹²³⁴⁵⁶⁷⁸⁹", "0123456789")

def py_eval(expr):
    s = expr.strip()
    s = re.sub(r"[⁰¹²³⁴⁵⁶⁷⁸⁹]+", lambda m: "^" + m.group().translate(SUP), s)
    s = s.replace("×", "*").replace("·", "*").replace("÷", "/").replace("−", "-").replace("–", "-")
    s = re.sub(r"(\d),(\d{3})(?!\d)", r"\1\2", s)
    if not re.search(r"\d", s) or re.search(r"[^0-9+\-*/^!(). ]", s): return None
    s = re.sub(r"(\d+)!", r"math.factorial(\1)", s).replace("^", "**")
    s = re.sub(r"(\))\s*(math|\d)", r"\1*\2", s)
    try:
        v = eval(s, {"math": math, "__builtins__": {}})
        return v if isinstance(v, (int, float)) else None
    except Exception: return None

def candidates(text):
    """expression-like runs, split at '=' and at list commas, plus every lone number"""
    t = re.sub(r"<[^>]+>", " ", text)
    t = re.sub(r"(\d),(\d{3})(?!\d)", r"\1\2", t)
    out = []
    for run in re.findall(r"[0-9⁰¹²³⁴⁵⁶⁷⁸⁹!()×·*÷/^+−\-. ]*\d[0-9⁰¹²³⁴⁵⁶⁷⁸⁹!()×·*÷/^+−\-. ]*", t):
        for piece in re.split(r",|\s-\s|;", run):
            piece = piece.strip(" .")
            if piece: out.append(piece)
    return out

def audit_text(ans, text):
    hits = []
    if isinstance(ans, (int, float)):
        for c in candidates(text):
            v = py_eval(c)
            if v is not None and abs(v - ans) < 1e-9 * max(1, abs(ans)): hits.append(c)
        if 0 <= ans <= 20 and re.search(r"\b" + WORDS[int(ans)] + r"\b", re.sub("<[^>]+>", " ", text), re.I):
            hits.append(WORDS[int(ans)])
    elif isinstance(ans, list):
        nums = [int(x) for x in re.findall(r"\d+", re.sub("<[^>]+>", " ", text))]
        for i in range(len(nums) - len(ans) + 1):
            if sorted(nums[i:i + len(ans)]) == sorted(ans): hits.append(", ".join(map(str, nums[i:i + len(ans)])))
    return hits

def run(verbose=True):
    real, fps, choice_steps, total = [], [], [], 0
    for page, probs in (("practice", P), ("lesson", L)):
        for p in probs:
            for i, s in enumerate(p["steps"]):
                total += 1
                if s["type"] == "choice": choice_steps.append(f'{page} {p["id"]} s{i+1}'); continue
                fields = [("q", s["q"]), ("ph", s["ph"]), ("hint", s["hint"])] + [("nudges", n) for n in s["nudges"]]
                if page == "lesson": fields.append(("concept", C[p["concept_id"]][1]))
                else: fields.append(("rules", build.RULES))
                for fname, text in fields:
                    for h in audit_text(s["ans"], text):
                        ok = [r for (f, tok, r) in s["leak_ok"] if f == fname and (tok == h or tok in h)]
                        rec = (page, p["id"], i + 1, fname, h, ok[0] if ok else "")
                        (fps if ok else real).append(rec)
    if verbose:
        print(f"steps audited: {total} ({len(choice_steps)} choice steps reviewed by hand: {', '.join(choice_steps)})")
        print(f"hits: {len(real) + len(fps)}  real: {len(real)}  false positives: {len(fps)}")
        for r in real: print("  REAL ", r[:5])
        for r in fps: print("  FP   ", r[:5], "--", r[5])
    return real, fps

if __name__ == "__main__":
    real, _ = run(); sys.exit(1 if real else 0)
