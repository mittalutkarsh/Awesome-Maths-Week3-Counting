"""Step-by-step visual concept stories. Examples deliberately differ from each lesson guided problem
(the leakage audit checks this). Every number here is verified in verify_stories.py."""
from .visuals import (story, chip, chips, slots, letters, bundle, table, big, row, stack, strike, tree, full_tree,
                      dots, plan_flow, pgrid)

S = {}

# ---------------- the counting plan (overview) ----------------
KIDS = ["Ana", "Ben", "Cy", "Dot"]
def _pf(active, ex_vis, ex_say):
    return (f'<div class="pf plan"><div class="pf-flow">{plan_flow(active)}</div><div class="pf-main"><div class="pf-tag">Example: choose 2 helpers from Ana, Ben, Cy, Dot</div>'
            f'{ex_vis}<div class="ex-say">{ex_say}</div></div></div>')
PLAN = story("The counting plan: the same questions for every problem", [
 (_pf("make", stack(chips(KIDS), big("one answer: Ana and Cy")), "A finished answer is a <b>pair of helpers</b>."),
  "<p>Every counting problem asks you to <b>make</b> something: an outfit, a number, a line of people, a hand of cards. Say out loud what one finished thing looks like.</p>",
  "Show me one example of the thing we're counting."),
 (_pf("steps", slots([("1st helper", "", "", ""), ("2nd helper", "", "", "")]), "Two decisions: pick one helper, then pick another."),
  "<p>Break making it into <b>decisions</b>, one after another: first the shirt, then the pants; first digit, then second digit. Draw one box (a <b>slot</b>) for each decision.</p>",
  "What's the first decision? What's the next one?"),
 (_pf("same", stack(slots([("1st", chips(KIDS, pick=["Ana"]), 4, "on"), ("2nd", chips(KIDS, used=["Ana"]), 3, "on")]),
                    slots([("1st", chips(KIDS, pick=["Cy"]), 4, "on"), ("2nd", chips(KIDS, used=["Cy"]), 3, "on")])),
       "If Ana goes first, Ben, Cy or Dot can be second. If Cy goes first, Ana, Ben or Dot. <b>Different kids, always 3.</b>"),
  "<p>Count the options for each slot. Then check the key question: <b>does every earlier choice leave the same number of options?</b> The options can be different. Only the <i>number</i> has to stay the same. If it doesn't, change the order of your decisions, or split into cases.</p>",
  "If you picked something else first, would this slot still have the same number of options?"),
 (_pf("mult", stack(slots([("1st", "", 4, "done"), ("2nd", "", 3, "done")], result="12"), pgrid(["A", "B", "C", "D"], 2)),
       "4 × 3 = 12. The grid shows all 12 picks: first helper down the side, second across the top, with the diagonal crossed out."),
  "<p>If yes, <b>multiply</b> the slot counts. That's the rule of product: every choice in one slot starts its own equal-sized group of choices in the next.</p>",
  "Why multiply and not add?"),
 (_pf("twice", stack(pgrid(["A", "B", "C", "D"], 3, twin_hl=(0, 1)), big("AB and BA: the same two helpers!", "sm")),
       "Picking Ana then Ben gives the same pair as Ben then Ana. Every pair was built <b>twice</b>. (A captain and a vice-captain would have no twins: those are different jobs.)"),
  "<p>Now look for <b>twins</b>: did your process build the same final thing in more than one way? That happens when things are identical (two L's), when order doesn't matter (a handshake, a team, a hand of cards), or when whole groups are interchangeable.</p>",
  "Could I get this exact same answer by making my choices in a different order?"),
 (_pf("divide", slots([("ordered picks", "", 12, "done"), ("copies of each pair", "", 2, "on")], op="÷", result="6"),
       "Each pair appeared exactly 2 times, so 12 ÷ 2 = 6 pairs."),
  "<p>If every final thing was built the same number of times, <b>divide</b> by that number. Two orders for a pair: divide by 2. Three identical letters: divide by 3! = 6. "
  "(If only <i>some</i> things were counted twice, take those extras away instead.)</p>",
  "How many times did we build each one?"),
 (_pf("check", stack(chips(["Ana + Ben", "Ana + Cy", "Ana + Dot", "Ben + Cy", "Ben + Dot", "Cy + Dot"]), big("6 pairs ✓", "sm")),
       "List every pair by hand, holding the first name fixed: exactly 6. The method was right."),
  "<p>Finally <b>check on a small case</b> you can list by hand. If the method gives the right count for the small case, trust it for the big one.</p>",
  "Can you make a tiny version of this problem and list every answer?"),
], sid="plan-story", kind="plan")

# ---------------- 1. rule of product ----------------
SAND = ["Ham", "Egg", "Tuna"]; DRINK = ["Milk", "Juice"]; FRUIT = ["Apple", "Pear", "Plum"]
lunch_list = [bundle([f"{s} + {d}" for d in DRINK], label=f"{s} group") for s in SAND]
S["product"] = story("Rule of product: equal groups mean multiply", [
 (stack(row(stack(big("Sandwiches", "sm"), chips(SAND)), stack(big("Drinks", "sm"), chips(DRINK)))),
  "<p>A lunch is <b>one sandwich and one drink</b>. How many different lunches are there?</p>", "Show me one lunch."),
 (stack(big(strike("3 + 2 = 5 lunches?")), chips(SAND + DRINK)),
  "<p>A very common first answer is 3 + 2 = 5. But 5 is the number of <b>foods</b>, not the number of <b>lunches</b>. Ham + Milk and Ham + Juice are already two lunches that both use Ham.</p>",
  "What does the 5 count?"),
 (table(["sandwich ↓  drink →"] + DRINK, [[x] + [f"{x} + {d}" for d in DRINK] for x in SAND]),
  "<p>List them in an organised way: <b>hold one sandwich fixed and go through every drink</b>, then move to the next sandwich. Each sandwich makes a group of lunches.</p>",
  "How many lunches are in the Ham group? The Egg group?"),
 (tree(full_tree([SAND, DRINK]), label_root="lunch", width_per_leaf=58),
  "<p>The same thing as a <b>tree</b>. Every sandwich branch splits into the <b>same number</b> of drink branches. 3 groups of 2 is 3 × 2 = 6 lunches.</p>",
  "Why is it 3 × 2 and not 3 + 2?"),
 (tree([(s, [(d, [(f[:2], []) for f in FRUIT]) for d in DRINK]) for s in SAND], label_root="lunch", width_per_leaf=30),
  "<p>Add a fruit: Apple, Pear or Plum. <b>Every</b> one of the 6 lunches splits into 3. So the count is 6 × 3 = 18.</p>",
  "If we added a 4th fruit, what would change?"),
 (slots([("sandwich", chips(SAND), 3, "on"), ("drink", chips(DRINK), 2, "on"), ("fruit", chips(FRUIT), 3, "on")], result="18"),
  "<p>You don't need to draw the tree every time. Draw one <b>slot</b> per decision, write how many options it has, and multiply. "
  "<b>The rule of product:</b> if every choice leaves the same number of options for the next decision, multiply the counts.</p>",
  "Make up your own lunch problem with 4 sandwiches. How many lunches?"),
], sid="s-product")

# ---------------- 2. restrictions ----------------
D10 = [str(d) for d in range(10)]
S["restrict"] = story("Restrictions: change what goes in each slot", [
 (slots([("tens digit", chips(D10), "", ""), ("ones digit", chips(D10), "", "")]),
  "<p>A two-digit number is <b>two digit slots</b>. Each slot could hold any digit 0 to 9… almost.</p>",
  "Is 07 a two-digit number?"),
 (slots([("tens digit", chips(D10, banned=["0"]), 9, "on"), ("ones digit", chips(D10), 10, "on")], result="90"),
  "<p>The first slot can't be 0, because 07 is just 7 in disguise. So 9 options first, 10 options second: 9 × 10 = 90. "
  "Check another way: the two-digit numbers run from 10 to 99, and 99 − 10 + 1 = 90.</p>",
  "Why is the first slot different from the second?"),
 (slots([("tens digit", chips(["0", "1", "2", "3"], banned=["0"]), 3, "on"), ("ones digit", chips(["0", "1", "2", "3"]), 4, "on")], result="12"),
  "<p>Now add a rule: <b>use only the digits 0, 1, 2, 3</b>. Write the allowed list in each slot and cross out what's banned. 3 × 4 = 12.</p>", ""),
 (table(["tens ↓  ones →", "0", "1", "2", "3"], [[t] + [t + o for o in "0123"] for t in "123"]),
  "<p>Check by listing: hold the tens digit fixed and run through the ones digits. 3 rows of 4 numbers each. Twelve numbers, and the table shows why it's 3 × 4.</p>",
  "Which row would 03 be in? Why isn't it there?"),
 (slots([("1st", chips(D10, banned=["0"]), 9, "on"), ("2nd", "", 10, "on"), ("3rd", "", 10, "on"), ("4th", "", 10, "on"), ("5th", "", 10, "on")], result="90,000"),
  "<p><b>General move:</b> for each slot, list what's allowed, cross out what the rule bans, and count. "
  "For five-digit numbers that's 9 × 10 × 10 × 10 × 10 = 90,000, and the range check agrees: 99,999 − 10,000 + 1.</p>",
  "How many three-digit numbers use only the digits 1, 2, 3?"),
], sid="s-restrict")

# ---------------- 3. most restricted first ----------------
BEAD3 = ["R", "W", "B"]
uneq = [("R", [("W", []), ("B", [])]), ("W", [("R", []), ("W", []), ("B", [])]), ("B", [("R", []), ("W", []), ("B", [])])]
red_rows = "".join(f'<div class="beads">' + "".join(f'<span class="bead {"r" if i == k else "q"}"></span>' for i in range(4)) + "</div>" for k in range(4))
S["first"] = story("Decide the most restricted thing first", [
 ('<div class="beads">' + '<span class="bead q"></span>' * 4 + "</div>" + chips(["Red", "White", "Black"]),
  "<p>Four beads in a row, each Red, White or Black, with <b>exactly one red</b> bead. How many rows?</p>", "Show me one row that works and one that doesn't."),
 (stack(tree(uneq, label_root="bead 1 → bead 2", width_per_leaf=44), big("after R: 2 options   ·   after W: 3   ·   after B: 3", "sm")),
  "<p>Try going left to right. Bead 1 has 3 options. But bead 2 has <b>2 options after Red</b> (red is used up) and <b>3 options after White</b>. "
  "The branches are <b>not equal</b>, so there's no single number to multiply by. This order is a trap.</p>",
  "After a white first bead, can bead 2 be red?"),
 ('<div class="beads"><span class="bead r"></span><span class="bead q"></span><span class="bead q"></span><span class="bead q"></span></div>' + big(strike("1 × 2 × 2 × 2 = 8")),
  "<p>Another trap: <b>make bead 1 red</b> and color the rest. That only counts rows where red is first. It misses every row with red somewhere else.</p>",
  "Find a row that works but isn't in this count."),
 (red_rows, "<p>So <b>decide the hard rule first</b>: <i>which</i> bead is red? There are 4 places it could be.</p>", ""),
 (slots([("where is red?", red_rows, 4, "on"), ("other bead", chips(["W", "B"]), 2, "on"), ("other bead", chips(["W", "B"]), 2, "on"), ("other bead", chips(["W", "B"]), 2, "on")], result="32"),
  "<p>After that, each of the other 3 beads is White or Black: always 2 options, whatever happened before. Now every branch is equal: 4 × 2 × 2 × 2 = 32.</p>",
  "Why does choosing the red bead first make every branch equal?"),
 (big("Hard rule first → equal branches → multiply"),
  "<p><b>General move:</b> when one rule makes the branches uneven, change the order of your decisions so that rule is settled first. "
  "You're allowed to build a thing in any order you like; pick the order that makes the counting easy.</p>",
  "In 'a boy at each end', which decision goes first?"),
], sid="s-first")

# ---------------- 4. permutations ----------------
FR = ["A", "B", "C", "D", "E"]
def chairs(k):
    used = FR[:k]
    seats = "".join(f'<div class="chair {"full" if i < k else ("next" if i == k else "")}">{FR[i] if i < k else ""}</div>' for i in range(5))
    return f'<div class="chairs">{seats}</div>' + chips(FR, used=used, pick=[] if k >= 5 else [x for x in FR if x not in used])
S["perm"] = story("Arranging different things: the shrinking choices", [
 (chairs(0), "<p>Five friends, A to E, sit in five chairs in a row. How many different orders?</p>", "Show me two different orders."),
 (chairs(0) + slots([("chair 1", "", 5, "on")]), "<p>Chair 1: any of the <b>5</b> friends.</p>", ""),
 (chairs(1) + slots([("chair 1", "", 5, "on"), ("chair 2", "", 4, "on")]),
  "<p>Chair 2: one friend is already sitting, so <b>4</b> are left. <i>Which</i> 4 depends on who sat first, but it's always 4.</p>",
  "If C sat first, who's left for chair 2?"),
 (chairs(4) + slots([("chair 1", "", 5, "on"), ("chair 2", "", 4, "on"), ("chair 3", "", 3, "on"), ("chair 4", "", 2, "on"), ("chair 5", "", 1, "on")], result="120"),
  "<p>Keep going: 3, then 2, then 1. Multiply: 5 × 4 × 3 × 2 × 1 = 120.</p>", "Why does the number go down by one each time?"),
 (table(["n", "n! means", "value"], [["4", "4 × 3 × 2 × 1", "24"], ["5", "5 × 4 × 3 × 2 × 1", "120"], ["6", "6 × 5 × 4 × 3 × 2 × 1", "720"], ["7", "7 × 6 × ⋯ × 1", "5040"]]),
  "<p>This product comes up so often it has a name: <b>n factorial</b>, written n!. <b>n different things in a row can be arranged in n! ways.</b> "
  "And 0! = 1: there is exactly one way to arrange nothing (an empty shelf).</p>",
  "How would you use 5! to get 6! quickly?"),
], sid="s-perm")

# ---------------- 5. shrinking sets ----------------
L6 = list("ABCDEF")
S["shrink"] = story("No repeats: each slot loses what's been used", [
 (slots([("1st", chips(L6), 6, "on"), ("2nd", "", "", ""), ("3rd", "", "", ""), ("4th", "", "", "")]),
  "<p>A secret code is 4 letters from A to F, <b>no letter used twice</b>. The first letter: 6 options.</p>", ""),
 (slots([("1st", chips(L6, pick=["C"]), 6, "on"), ("2nd", chips(L6, used=["C"]), 5, "on"), ("3rd", "", "", ""), ("4th", "", "", "")]),
  "<p>Say the first letter was C. Now C is used, so the second slot has <b>5</b> options.</p>", ""),
 (slots([("1st", "", 6, "on"), ("2nd", "", 5, "on"), ("3rd", "", 4, "on"), ("4th", "", 3, "on")], result="360"),
  "<p>Each slot loses one more: 6 × 5 × 4 × 3 = 360. It's like a factorial that stops early, because we only fill 4 slots.</p>",
  "Why don't we keep going down to 1?"),
 (slots([("tens", chips(D10, banned=["0"]), 9, "on"), ("ones", chips(D10, used=["4"]), 9, "on")], result="81", note="if the tens digit was 4: 0 comes back, 4 is used up"),
  "<p>Digits have a twist. Two-digit numbers with <b>different</b> digits: the first slot can't be 0 (9 options). The second slot <b>can</b> be 0 but can't repeat the first digit: 10 − 1 = 9. So 9 × 9 = 81.</p>",
  "Why do both slots have 9 options, for different reasons?"),
 (big("options left = all options − banned − already used"),
  "<p><b>General move:</b> for each slot, start from everything, cross out what the rule bans and what earlier slots used up, then count what's left.</p>", ""),
], sid="s-shrink")

# ---------------- 6. overcounting / repeated letters ----------------
B, R_ = "blue", "red"
too_lab = [("TOO", {1: B, 2: R_}, {1: "1", 2: "2"}), ("TOO", {1: R_, 2: B}, {1: "2", 2: "1"}),
           ("OTO", {0: B, 2: R_}, {0: "1", 2: "2"}), ("OTO", {0: R_, 2: B}, {0: "2", 2: "1"}),
           ("OOT", {0: B, 1: R_}, {0: "1", 1: "2"}), ("OOT", {0: R_, 1: B}, {0: "2", 1: "1"})]
def lw(w, c, s): return letters(w, c, s)
S["overcount"] = story("Identical letters: pretend they're different, then undo it", [
 (stack(letters("TOO"), big(strike("3 letters, so 3! = 6 words?"))),
  "<p>How many ways can you arrange the letters T, O, O? It's tempting to say 3! = 6, like three different letters. Let's test that.</p>", "Can you list 6 different words?"),
 (row(*[lw(*x) for x in too_lab], gap=".5rem"),
  "<p>Pretend the O's are different: paint one <b>blue O₁</b> and one <b>red O₂</b>. Now there really are 6 arrangements.</p>", ""),
 (stack(bundle([lw(*too_lab[0]), lw(*too_lab[1])], letters("TOO")), bundle([lw(*too_lab[2]), lw(*too_lab[3])], letters("OTO")),
        bundle([lw(*too_lab[4]), lw(*too_lab[5])], letters("OOT"))),
  "<p>Now wash the paint off. The arrangements fall into <b>bundles of 2</b> that look identical. Every real word appeared exactly twice, so there are 6 ÷ 2 = 3 words.</p>",
  "Why exactly twice? Where does the 2 come from?"),
 (stack(bundle([letters("EBEE", {0: a, 2: b, 3: c}, {0: x, 2: y, 3: z}) for (a, b, c), (x, y, z) in
        zip([("blue", "red", "green"), ("blue", "green", "red"), ("red", "blue", "green"), ("red", "green", "blue"), ("green", "blue", "red"), ("green", "red", "blue")],
            [("1", "2", "3"), ("1", "3", "2"), ("2", "1", "3"), ("2", "3", "1"), ("3", "1", "2"), ("3", "2", "1")])], letters("EBEE"), "6 painted copies, one real word")),
  "<p>Three identical letters: B, E, E, E. Paint the E's three colors. One real word, like EBEE, now shows up once for <b>every order of the three painted E's</b>: 3 × 2 × 1 = 3! = 6 times, not 3 times.</p>",
  "List the orders of E₁, E₂, E₃. How many are there?"),
 (slots([("all different", "4 letters", "4!", "on"), ("painted E's", "orders", "3!", "on")], op="÷", result="4"),
  "<p>So the count is 4! ÷ 3! = 24 ÷ 6 = 4: BEEE, EBEE, EEBE, EEEB.</p>", ""),
 (stack(bundle([letters("ABAB", {0: "blue", 2: "red", 1: "green", 3: "blue"}, {0: "1", 2: "2", 1: "1", 3: "2"}),
                 letters("ABAB", {0: "red", 2: "blue", 1: "green", 3: "blue"}, {0: "2", 2: "1", 1: "1", 3: "2"}),
                 letters("ABAB", {0: "blue", 2: "red", 1: "blue", 3: "green"}, {0: "1", 2: "2", 1: "2", 3: "1"}),
                 letters("ABAB", {0: "red", 2: "blue", 1: "blue", 3: "green"}, {0: "2", 2: "1", 1: "2", 3: "1"})], letters("ABAB")),
        big("A's: 2 orders × B's: 2 orders = 4 painted copies", "sm")),
  "<p>Two repeated groups, A, A, B, B: each real word has 2 orders for the A's <b>times</b> 2 orders for the B's, so 2 × 2 = 4 painted copies. "
  "(Multiply, not add: every A-order goes with every B-order.) 4! ÷ 4 = 6 words.</p>", "Why 2 × 2 and not 2 + 2?"),
 (big("arrangements = n! ÷ (repeats₁! × repeats₂! × ⋯)"),
  "<p><b>General move:</b> count as if every letter were different (n!), then divide by the number of painted copies of each real word: the factorial of each repeat count, multiplied together.</p>",
  "How many words can you make from N, O, O, N?"),
], sid="s-overcount")

# ---------------- 7. identical groups ----------------
def stackpic(a, b, lab=("shelf L", "shelf R")):
    return (f'<div class="shelves"><div class="shelf"><span>{lab[0]}</span><div class="bk">{a[1]}</div><div class="bk">{a[0]}</div></div>'
            f'<div class="shelf"><span>{lab[1]}</span><div class="bk">{b[1]}</div><div class="bk">{b[0]}</div></div></div>')
S["groups"] = story("Identical groups: divide by the ways to swap whole groups", [
 (stackpic("12", "34"), "<p>Four different books, 1 to 4, go into two stacks of two. Book order inside a stack matters (bottom and top). "
  "First, the stacks go on two <b>labeled</b> shelves, L and R.</p>", ""),
 (slots([("L bottom", "", 4, "on"), ("L top", "", 3, "on"), ("R bottom", "", 2, "on"), ("R top", "", 1, "on")], result="24"),
  "<p>Fill the four spots one at a time: 4 × 3 × 2 × 1 = 4! = 24.</p>", ""),
 (row(stackpic("12", "34", ("box", "box")), big("same as"), stackpic("34", "12", ("box", "box"))),
  "<p>Now put the stacks into two <b>identical</b> boxes instead. Swapping the two whole stacks no longer changes anything: these two pictures are the same. "
  "Every arrangement has exactly one twin, so 24 ÷ 2 = 12.</p>", "What exactly got swapped?"),
 (row(stackpic("12", "34", ("box", "box")), big("≠"), stackpic("21", "34", ("box", "box"))),
  "<p>But <b>don't</b> divide for the order inside a stack: book 1 under book 2 is a different stack from book 2 under book 1.</p>",
  "Which swaps make a new picture, and which don't?"),
 (big("k identical groups → divide by k!"),
  "<p><b>General move:</b> count with the groups labeled, then divide by the number of ways to shuffle the whole groups: k! for k identical groups.</p>", ""),
], sid="s-groups")

# ---------------- 8. same count, different choices ----------------
def rgb_tree(depth):
    def ch(prev, d):
        if d == 0: return []
        return [(c, ch(c, d - 1)) for c in "RGB" if c != prev]
    return [(c, ch(c, depth - 1)) for c in "RGB"]
S["samecount"] = story("Different choices, same number of choices", [
 (chips(["R", "G", "B"]), "<p>Make a 3-letter sequence of R, G, B where <b>no letter is next to itself</b> (RR is banned).</p>", "Is RGR allowed? Is RGG?"),
 (tree(rgb_tree(2), label_root="1st → 2nd", width_per_leaf=40),
  "<p>After R the next letter is G or B. After G it's R or B. <b>The options change, but there are always 2.</b></p>", ""),
 (tree(rgb_tree(3), label_root="1st → 2nd → 3rd", width_per_leaf=30),
  "<p>That's all the rule of product needs. Every node has 2 branches below it: 3 × 2 × 2 = 12 sequences.</p>",
  "Point at any node. How many branches come out of it?"),
 (slots([("1st", chips(["R", "G", "B"]), 3, "on"), ("2nd", "not the 1st", 2, "on"), ("3rd", "not the 2nd", 2, "on"), ("4th", "not the 3rd", 2, "on")], result="24"),
  "<p><b>General move:</b> you can multiply even when the options depend on earlier choices, as long as the <b>number</b> of options doesn't. Four letters: 3 × 2 × 2 × 2 = 24.</p>", ""),
], sid="s-samecount")

# ---------------- 9. removing order (sets) ----------------
ABC_orders = ["ABC", "ACB", "BAC", "BCA", "CAB", "CBA"]
S["order"] = story("Groups with no order: build in order, then divide", [
 (chips(FR), "<p>Pick a <b>team of 3</b> from five kids, A to E. A team is just a group: ABC is the same team as CBA.</p>", "Is 'A, then B, then C' a different team from 'C, then B, then A'?"),
 (slots([("1st pick", "", 5, "on"), ("2nd pick", "", 4, "on"), ("3rd pick", "", 3, "on")], result="60"),
  "<p>Pick one kid at a time: 5 × 4 × 3 = 60 <b>ordered</b> picks.</p>", ""),
 (bundle([letters(w) for w in ABC_orders], "team {A, B, C}", "one team, picked in 6 different orders"),
  "<p>But the team {A, B, C} showed up 6 times in those 60, once for each order of its 3 members: 3! = 6.</p>", "List the orders of A, B, C."),
 (slots([("ordered picks", "", 60, "on"), ("orders per team", "", "3!", "on")], op="÷", result="10"),
  "<p>Every team was counted 6 times, so 60 ÷ 6 = 10 teams.</p>", ""),
 (big("choose k with no order = (ordered picks) ÷ k!"),
  "<p><b>General move:</b> pretend the picks are in order, multiply, then divide by k! because each group of k was built in k! orders.</p>",
  "How many ways to choose 2 kids out of 5? Use the same move."),
], sid="s-order")

# ---------------- 10. pick grids ----------------
P4 = ["A", "B", "C", "D"]
E_all = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
S["pairs"] = story("Pairs: dots, lists and the pick grid", [
 (dots(P4), "<p>Four people, A, B, C, D. Everyone shakes hands with everyone else once. How many handshakes? "
  "Draw people as dots and handshakes as lines.</p>", "How many people does one handshake need?"),
 (dots(P4, E_all[:3], E_all[:3]), "<p>A shakes with B, C and D: <b>3</b> lines.</p>", ""),
 (dots(P4, E_all[:5], E_all[3:5]), "<p>B has already shaken A's hand, so B adds only C and D: <b>2</b> new lines.</p>", "Why doesn't B shake A's hand again?"),
 (dots(P4, E_all, E_all[5:]), "<p>C adds just D: <b>1</b> new line. D has nobody new. Total: 3 + 2 + 1 = 6 handshakes.</p>", ""),
 (pgrid(P4, 1), "<p>Now the same problem as a <b>pick grid</b>. First person down the side, second across the top. Every box is 'first this person, then that one': 4 × 4 = 16 boxes.</p>",
  "How many boxes are there?"),
 (pgrid(P4, 2), "<p>The diagonal boxes pick the same person twice (A and A). Nobody shakes their own hand: cross out 4, leaving 12.</p>", "Why are the × boxes not allowed?"),
 (pgrid(P4, 3, twin_hl=(0, 1)), "<p><b>The moment that matters:</b> point at AB, then at BA. Are they different handshakes? No! Every teal box has a grey <b>twin</b> across the diagonal. "
  "So 12 boxes are really 6 handshakes: 12 ÷ 2 = 6. Same answer as the dots.</p>", "Is AB the same thing as BA here?"),
 (pgrid(["1", "2", "3", "4"], 2, rowh="home", colh="away", plain=True, sep="v"),
  "<p>Compare: four teams each play every other team <b>at home and away</b>. Team 1 at home to team 2 is a different game from team 2 at home to team 1. "
  "<b>No twins</b>, so nothing to divide: 12 games.</p>", "When does a box have a twin, and when doesn't it?"),
 (table(["people", "pick grid", "handshakes"], [["2", "2 × 1 ÷ 2", "1"], ["3", "3 × 2 ÷ 2", "3"], ["4", "4 × 3 ÷ 2", "6"], ["5", "?", "?"], ["6", "6 × 5 ÷ 2", "15"], ["12", "12 × 11 ÷ 2", "66"]], hl_row=3),
  "<p><b>Generalize:</b> with n people the grid has n × n boxes, n of them on the diagonal, and the rest come in twin pairs. So pairs = n × (n − 1) ÷ 2.</p>",
  "Fill in the row for 5 people, then check it with dots."),
], sid="s-pairs")
