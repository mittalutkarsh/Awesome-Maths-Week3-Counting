"""Lesson page: one concept per lecture idea, each with one guided problem from the Lecture Note.
Answers verified in verify.py."""
from .common import step, problem
from . import grids as G

def eq(html):
    return f'<div class="eq" role="math">{html}</div>'

def frac(top, bot):
    return f'<span class="frac"><span>{top}</span><span>{bot}</span></span>'

C = {}  # concept id -> (title, html)

C["product"] = ("The rule of product", eq("N = c<sub>1</sub> × c<sub>2</sub> × ⋯ × c<sub>k</sub>") + """
<p>Build the thing you are counting as a sequence of decisions, so that every possible thing gets made exactly once.
If decision 1 has c<sub>1</sub> options, decision 2 has c<sub>2</sub> options <em>whatever you chose in decision 1</em>, and so on,
then the total is the product.</p>
<p>A lunch is one of five sandwiches, one of two drinks and one of three fruits. Each sandwich starts a group of 2 drink choices,
so 5 × 2 = 10 sandwich-and-drink pairs; each pair starts a group of 3 fruits, so 10 × 3 = 30 lunches. A tree shows the branching,
but once you know the branch counts you don't need to draw every leaf.</p>
<p>The options at a step may change depending on earlier choices. Only their <em>number</em> has to stay the same.</p>""")

C["restrict"] = ("Restrictions change the options", eq("9 × 10 × 10 × 10 × 10 = 90,000") + """
<p>A number is a list of digits, so build it digit by digit. The only rule for an ordinary five-digit number is that the first digit
can't be zero: 04372 is really the four-digit number 4372. So the first place has 9 options and each other place has 10.</p>
<p>Check it a second way: five-digit numbers run from 10,000 to 99,999, and 99,999 − 10,000 + 1 = 90,000.</p>
<p>A restriction like "only digits below 4" changes the list at every place. Two-digit numbers using only 0, 1, 2, 3: the first
place is 1, 2 or 3 (3 options), the second is 0, 1, 2 or 3 (4 options), so 3 × 4 = 12. Write the allowed list for each place,
then count it.</p>""")

C["first"] = ("Decide the most restricted thing first", eq("4 × 2<sup>3</sup> = 32") + """
<p>You choose the order of your decisions. If one rule is hard to track, settle it before anything else.</p>
<p>Four beads in a row, each red, white or black, with exactly one red bead. Going left to right fails: a later bead has 3 options or 2
depending on whether red was already used, so there's no single number to multiply by. Making the first bead red fails too; it misses
every row with red somewhere else. Instead decide <em>which</em> bead is red first (4 options), then color the rest white or black
(2 each): 4 × 2 × 2 × 2 = 32.</p>
<p>You can even build a three-digit number right to left: 10 × 10 × 9 gives the same 900.</p>""")

C["perm"] = ("Permutations and factorials", eq("n! = n × (n − 1) × ⋯ × 2 × 1, &nbsp; 0! = 1") + """
<p>A <strong>permutation</strong> is an arrangement, an ordering, of a group of things. For <em>different</em> objects the choices shrink
by one at every position. Five friends in a line: 5 choices for the front, then 4, 3, 2, 1, so 5! = 120 lines.</p>
<p>The friend in second place depends on who went first, but there are always four candidates. Different options, same number of
them, so the rule of product works. Try a couple of sample paths to make sure nothing behaves differently.</p>
<p>Zero objects can be arranged in exactly one way: the empty arrangement, like an empty desk. That is why 0! = 1, which also keeps
n! = n × (n − 1)! true at n = 1.</p>""")

C["shrink"] = ("Shrinking sets", eq("6 × 5 × 4 × 3 = 360") + """
<p>Four-letter codes from the letters A to F with no letter used twice: 6 options for the first letter, 5 for the second, 4, then 3.
That's 360 codes.</p>
<p>Digits work the same way with one twist: the first digit can't be zero, but the second can. Two-digit numbers with different digits:
9 options first, then 10 − 1 = 9, so 9 × 9 = 81. It looks like a factorial but isn't one: the first place is special, and we stop early.</p>""")

C["overcount"] = ("Overcounting and repeated letters", eq("arrangements = " + frac("n!", "m<sub>1</sub>! · m<sub>2</sub>! ⋯ m<sub>r</sub>!")) + """
<p><strong>Overcounting</strong> is counting some or all things more than once. For T, O, O a letter-by-letter tree fails: after T there
is one kind of letter left, after O there are two, so there's no single multiplier.</p>
<p>Instead pretend the O's are different, a blue O and a red O. Three different letters: 3! = 6 arrangements. Every real word (TOO,
OTO, OOT) appears exactly twice, blue first or red first, so there are 6 ÷ 2 = 3. Divide only when <em>everything</em> is counted the
same number of times.</p>
<p>With three identical letters the overcount factor is the number of ways to order three colored copies, 3! = 6, not 3. For B, E, E, E:
4! ÷ 3! = 24 ÷ 6 = 4 (BEEE, EBEE, EEBE, EEEB). With two repeated groups the orderings combine by the rule of product: A, A, B, B gives
4! ÷ (2! × 2!) = 6.</p>
<p>Cancel before multiplying: 6!/4! = 6 × 5 = 30.</p>""")

C["groups"] = ("Identical groups", eq(frac("8!", "2!")) + """
<p>Eight different books go into two stacks of four, one stack on each of two labeled shelves. Order inside a stack matters, so filling
the shelves one slot at a time is just arranging all eight books: 8!.</p>
<p>Now put the stacks into two identical boxes instead. Any finished pair of stacks can be put on labeled shelves in 2! ways, and those
now look the same. Divide by 2!. Don't divide by 4! for each stack: swapping books inside a stack still changes the stack.</p>""")

C["samecount"] = ("Same number of choices, different choices", eq("3 × 2<sup>3</sup> = 24") + """
<p>A four-letter sequence of R, G, B where no letter appears twice in a row. After R the next letter is G or B; after G it's R or B.
The next letters depend on the last one, but there are always two of them. So 3 × 2 × 2 × 2 = 24. That's all the rule of product
needs.</p>""")

C["order"] = ("Removing order to count sets", eq(frac("5 × 4 × 3", "3!") + " = 10") + """
<p>A <em>set</em> has no first, second or third member. Picking a team of three from five kids one at a time gives 5 × 4 × 3 = 60
ordered picks, but each team was picked once for every order of its three members: 3! = 6 times. So there are 60 ÷ 6 = 10 teams.</p>
<p>Build with order, then divide by the number of orders.</p>""")

C["pairs"] = ("Pick grids: when does order matter?", eq("pairs = " + frac("n × (n − 1)", "2")) + """
<p>To count pairs from a group, build a grid. Put the first pick down the side and the second pick across the top. Four people,
A, B, C, D, make a 4 × 4 grid: 16 boxes, and every box is one way to say "first I pick this person, then that one."</p>
<p>Ask three questions, in order.</p>
<ol><li><b>How many boxes?</b> 4 × 4 = 16.</li>
<li><b>Which boxes aren't allowed?</b> The diagonal picks the same person twice (A then A). Cross out those 4: 12 left.</li>
<li><b>Are any two boxes the same thing?</b> Point at AB, then at BA. If the order doesn't matter, they're the same pair, and every
teal box has a grey twin across the diagonal. So 12 boxes are really 6 pairs: 12 ÷ 2 = 6.</li></ol>
""" + G.G_FOUR + """
<p>Question 3 is the whole idea. If the answer is no (a home game and an away game, a red card and a black card, a captain and a
vice-captain) there are no twins and nothing to divide. If the answer is yes (handshakes, teams, hands of cards) divide by 2.</p>
<p>Point at any grey box to light up its twin.</p>""")

L = [
problem("c1", "1.1", "The rule of product", "Outfits",
 "If you have four shirts, three pairs of pants, and two pairs of shoes in your closet, how many different outfits are possible?",
 [step("How many shirt-and-pants combinations are there?", "num", 12,
   ["Pick one shirt. How many pants could go with it?",
    "Is that the same for every shirt?",
    "Multiply the shirts by the pants each one can go with."],
   "Each shirt starts its own group of pants choices, and every group is the same size. Count the groups and their size.",
   "12 = 4 × 3.", "Groups of equal size, so multiply.",
   errors={7: "Adding counts the clothes, not the combinations."}),
  step("How many different outfits are possible?", "num", 24,
   ["Each shirt-and-pants pair can be finished with which shoes?",
    "Is that the same for every pair?",
    "Multiply."],
   "Every shirt-and-pants pair gets the same shoe choices. Multiply your step 1 count by those choices.",
   "24 = 4 × 3 × 2. Check: listing every (shirt, pants, shoes) triple gives 24.", "That's the rule of product.",
   errors={9: "Adding counts the clothes, not the outfits.", 12: "The shoes are a decision too."},
   leak_ok=[("hint", "1", "refers to 'step 1'")])],
 "24", "Listing all triples gives 24.", "4 shirts × 3 pants × 2 shoes = 24.", concepts=["product"]),

problem("c2", "1.3", "Restrictions change the options", "Only odd digits",
 "How many 5-digit numbers are there with only odd digits?",
 [step("How many digits can go in the first place?", "num", 5,
   ["List the odd digits.", "Is any odd digit a leading zero?", "Count the list."],
   "Write down the odd digits. Check whether any of them is a problem in the first place.",
   "5: 1, 3, 5, 7, 9.", "None of them is zero, so the first place isn't special this time.",
   errors={4: "No odd digit is zero, so nothing gets crossed out.", 9: "Only odd digits are allowed."},
   leak_ok=[("concept", "five", "'five-digit number' in the concept text"), ("concept", "5", "the digit chips 0–9 in the restriction story")]),
  step("How many 5-digit numbers have only odd digits?", "expr", 3125,
   ["How many options does each of the other places have?", "Every place has the same list.", "Multiply across the five places."],
   "Every place uses the same list of odd digits. Multiply the counts for all five places.",
   "3125 = 5⁵. Check: a brute-force scan of 10,000–99,999 finds 3125.", "5⁵.",
   errors={2500: "No odd digit is zero, so the first place isn't special here.", 90000: "Only odd digits are allowed.",
           25: "There are five places, not two.", 15625: "There are five places, not six."})],
 "3125", "Brute force over 10,000–99,999 finds 3125.", "Five odd digits at each of five places: 5⁵ = 3125.",
 concepts=["restrict"]),

problem("c3", "2.1", "Decide the most restricted thing first", "Family seating",
 "(2006 AMC) Mr. and Mrs. Lopez have two children. When they get into their family car, two people sit in the front, and the other two sit in the back. "
 "Either Mr. Lopez or Mrs. Lopez must sit in the driver's seat. How many seating arrangements are possible?",
 [step("How many people could sit in the driver's seat?", "num", 2,
   ["Who is allowed to drive?", "Can a child drive?", "Count the parents."],
   "Only a parent may drive. Count the people allowed in that seat.",
   "2: Mr. or Mrs. Lopez.", "Restricted seat done first.",
   errors={4: "The children can't drive.", 1: "Either parent may drive."},
   leak_ok=[("concept", "2", "bead example: 'white or black (2 each)'")]),
  step("How many seating arrangements are possible?", "num", 12,
   ["After the driver sits, how many people are left for the next seat?", "And the seat after that?", "Multiply the choices seat by seat."],
   "Once the driver is seated, the other three people fill the other seats in any order. Multiply the driver choices by those.",
   "12 = 2 × 3 × 2 × 1. Check: brute force over all 24 seatings finds 12 with a parent driving.", "Restricted first, then the rest.",
   errors={24: "Not everyone can drive.", 6: "Either parent could be driving.", 8: "Add or multiply?"})],
 "12", "Brute force over 24 seatings finds 12.", "2 drivers × 3! for the rest = 12.", concepts=["first"]),

problem("c4", "1.4", "Permutations and factorials", "Arrange A, B, C",
 "How many ways are there to arrange the letters A, B, C in some order?",
 [step("How many ways are there to arrange A, B, C?", "num", 6,
   ["How many letters could go first?", "Then how many are left for the second place?", "Multiply the shrinking choices."],
   "Place the letters one position at a time; each placement leaves one fewer letter.",
   "6 = 3!. Check: ABC, ACB, BAC, BCA, CAB, CBA.", "3!.",
   errors={3: "Each arrangement uses all the letters; count orders, not letters.", 9: "A letter can't be used twice.", 27: "A letter can't be used twice."})],
 "6", "Listing gives ABC, ACB, BAC, BCA, CAB, CBA.", "3 × 2 × 1 = 3! = 6.",
 concepts=["perm"]),

problem("c5", "1.5", "Shrinking sets", "Five different digits",
 "How many 5-digit numbers are there with all distinct (different) digits?",
 [step("Once the first two digits are chosen, how many choices are there for the third digit?", "num", 8,
   ["Could the third digit be zero?", "How many digits are already used?", "Start from all the digits and remove the used ones."],
   "The third digit may be zero but must differ from both digits already used.",
   "8: ten digits minus the two used. Check: after 4, 0 the third can be 1, 2, 3, 5, 6, 7, 8 or 9.", "Two used, eight left.",
   errors={7: "Zero is allowed in the third place.", 9: "It must differ from both of the first two digits.", 10: "It must differ from the digits already used."}),
  step("How many 5-digit numbers have all different digits?", "num", 27216,
   ["How many options for the third digit?", "Each place loses one more option.", "Multiply the five counts."],
   "Each later place has one fewer option than the place before it. Multiply the five counts.",
   "27,216 = 9 × 9 × 8 × 7 × 6. Check: brute force over 10,000–99,999 finds 27,216.", "Shrinking set, special first place.",
   errors={30240: "That lets zero lead.", 15120: "Zero can go after the first place.", 90000: "That allows repeats."})],
 "27,216", "Brute force agrees.", "9 × 9 × 8 × 7 × 6 = 27,216.", concepts=["shrink"]),

problem("c6", "1.6–1.7", "Overcounting and repeated letters", "Repeated A's",
 "How many ways are there to arrange the letters A, A, B, C in some order? And A, A, A, B, C?",
 [step("How many ways are there to arrange A, A, B, C?", "num", 12,
   ["If you swap the two A's, is it a new arrangement?", "How many times does a count that treats the A's as different list each real arrangement?", "Divide by that."],
   "Color the A's blue and red, count arrangements of four different letters, then divide by the number of ways to order the two colored A's.",
   "12 = 4!/2!. Check: brute force lists 12.", "Divide out the pretend.",
   errors={24: "Swapping the A's gives the same arrangement.", 6: "That divides by too much."}),
  step("How many ways are there to arrange A, A, A, B, C?", "num", 20,
   ["How many arrangements if the A's were three different colors?", "In how many ways can three colored A's be ordered among themselves?", "Divide."],
   "Color the three A's. Every real arrangement shows up once for each ordering of the three colored A's. That ordering count is what you divide by.",
   "20 = 5!/3! = 5 × 4. Check: brute force lists 20.", "5!/3!, or cancel first: 5 × 4.",
   errors={40: "Divide by the number of orderings of the A's, not the number of A's.", 120: "The A's are identical.", 60: "There are three A's now."})],
 "12 and 20", "Brute force lists 12 and 20.", "4!/2! = 12; 5!/3! = 20.", concepts=["overcount"]),

problem("c7", "Board", "Identical groups", "Coins in tubes",
 "You want to make three stacks of five coins from fifteen distinct coins, and you put the stacks in three tubes. Order within a stack matters. "
 "How many ways are there if the tubes are distinct? If the tubes are identical?",
 [step("How many ways are there with three distinct tubes? A factorial is fine.", "expr", 1307674368000,
   ["Imagine filling the tubes one slot at a time. How many coins could go in the first slot?", "And the next slot?", "Is this just an arrangement of all the coins?"],
   "Fill tube A bottom to top, then B, then C. Each slot takes one of the coins not yet used.",
   "15! = 1,307,674,368,000.", "An arrangement of fifteen coins.",
   errors={3628800: "Every coin gets placed, not just ten."}, forms=["15!"]),
  step("How many ways are there with three identical tubes?", "expr", 217945728000,
   ["What can you now swap without changing anything?", "In how many ways can three finished stacks be put into labeled tubes?", "Divide by that."],
   "With identical tubes, swapping whole stacks between tubes changes nothing. Divide your step 1 count by the number of ways to order the three stacks.",
   "15!/3! = 217,945,728,000. Check: the same count on a smaller case (6 coins, 3 stacks of 2) brute-forces to 6!/3! = 120.", "Remove the distinction from the groups, not the coins.",
   errors={126126: "Swapping coins inside a stack changes the stack.", 756756: "Swapping coins inside a stack changes the stack.",
           1307674368000: "With identical tubes, some of those look the same."},
   forms=["15!/3!", "15!/6"], leak_ok=[("hint", "1", "refers to 'step 1'")])],
 "15! and 15!/3!", "Scaled brute force (6 coins) gives 720 and 120.", "Distinct tubes: 15!. Identical tubes: each collection counted 3! times, so 15!/3!.",
 concepts=["groups"]),

problem("c8", "2.2", "Same number of choices, different choices", "Good words",
 "Define a good word as a sequence of letters that consists only of the letters A, B, and C (some of these letters may not appear in the sequence) and in which A is never immediately followed by B, "
 "B is never immediately followed by C, and C is never immediately followed by A. How many seven-letter good words are there?",
 [step("How many two-letter good words are there?", "num", 6,
   ["List all two-letter words using A, B, C.", "Cross out AB, BC and CA.", "Count what's left."],
   "Write every pair of letters (repeats allowed), then cross out the banned ones.",
   "6: AA, AC, BA, BB, CB, CC.", "Notice: each first letter kept the same number of partners.",
   leak_ok=[("concept", "3   ×   2", "slot labels '3' then '2nd'; the story counts a different rule (no letter next to itself)"), ("concept", "2   ×   3", "slot text in the R, G, B story")],
   errors={9: "Some pairs are banned: AB, BC and CA.", 3: "Repeated letters like AA are allowed."}),
  step("How many seven-letter good words are there?", "expr", 192,
   ["How many choices for the first letter?", "Is it the same number after B and after C?", "How many letters come after the first?"],
   "The first letter is free. Every later letter always has the same number of choices, whatever came before. Multiply.",
   "192 = 3 × 2⁶. Check: brute force over all 3⁷ = 2187 words finds 192.", "Same count, different options: product rule holds.",
   errors={2187: "That ignores the banned pairs.", 128: "The first letter has three choices.", 384: "There are six letters after the first.",
           96: "There are six letters after the first."})],
 "192", "Brute force over 2187 words finds 192.", "3 × 2⁶ = 192.", concepts=["samecount"]),

problem("c9", "2.3", "Removing order to count sets", "Complementary cards",
 "Every card in a deck shows one shape (circle, square, or triangle) in one of three colors (red, blue, or green), and each color comes in one of three shades (light, medium, or dark). "
 "The deck has 27 cards, one for every shape-color-shade combination. A set of three cards is complementary if, for shape, color and shade separately, the three cards are either all the same or all different. "
 "How many different complementary three-card sets are there?",
 [step("Once two different cards are chosen, how many cards complete a complementary set with them?", "num", 1,
   ["Take a dark blue square and a dark green triangle. What shape must the third card be?", "What color? What shade?", "How many cards fit all three?"],
   "Look at one feature at a time. If the two cards match on it, the third must match too; if they differ, the third must be the value that's left.",
   "1: each feature is forced. The dark blue square and dark green triangle force the dark red circle.", "The first two cards decide the third.",
   leak_ok=[("hint", "one", "'one feature at a time'"), ("concept", "one", "'one at a time' in the team example"), ("concept", "1", "'1st pick' slot label")],
   errors={0: "Any two different cards can be completed.", 2: "Each feature is forced to one value.", 3: "Each feature is forced to one value."}),
  step("How many complementary three-card sets are there?", "num", 117,
   ["How many ways to draw a first card, then a second, then the forced third?", "Does the problem care which card was drawn first?", "How many orders can three cards be drawn in?"],
   "Count ordered draws first: any first card, any different second card, then the forced third. A set has no order, so every set was counted once per ordering of its three cards. Divide by that number of orderings.",
   "117 = 27 × 26 ÷ 3! = 702 ÷ 6. Check: brute force over all 2925 three-card sets finds 117.", "Built with order, divided back out.",
   errors={702: "That counts each set once for every order you could draw it in.", 351: "Three cards can be ordered in more than two ways.",
           234: "Divide by the number of orders of three cards, not by 3.", 2925: "That's every three-card set, complementary or not."})],
 "117", "Brute force over 2925 sets finds 117.", "27 × 26 × 1 ordered draws, ÷ 3! = 117.", concepts=["order"]),
]

L.append(problem("c10", "Grid", "Pick grids: when does order matter?", "Captains",
 "Five friends, Ada, Ben, Cy, Dot and Eli, need leaders for their team. How many ways are there to choose a captain and a vice-captain? "
 "How many ways are there to choose two co-captains, who share the same job?",
 [step("How many ways are there to choose a captain and a different vice-captain?", "num", 20,
   ["How many friends could be captain?", "Once the captain is chosen, how many could be vice-captain?", "Is Ada-captain, Ben-vice the same as Ben-captain, Ada-vice?"],
   "Build the grid with the captain down the side and the vice-captain across the top. Cross out the boxes where one friend holds both jobs. Different jobs means every remaining box is different.",
   "20 = 5 × 4. Check: listing every (captain, vice) pair gives 20.", "Different jobs: no twins.",
   errors={25: "One friend can't hold both jobs.", 10: "Captain and vice are different jobs, so swapping gives a new choice.", 9: "Multiply, don't add."}),
  step("How many ways are there to choose two co-captains?", "num", 10,
   ["Is Ada-and-Ben the same pair as Ben-and-Ada?", "In your grid, does each box have a twin?", "Remove the double count."],
   "Co-captains share one job, so a box and the box across the diagonal from it name the same pair. Divide out that double count.",
   "10 = 5 × 4 ÷ 2. Check: listing every pair of five friends gives 10.", "Same job: twins, so divide by 2.",
   errors={20: "Ada-and-Ben is the same pair as Ben-and-Ada.", 25: "One friend can't be picked twice.", 5: "Count the pairs, not the friends."})],
 "20 and 10", "Listing gives 20 ordered choices and 10 pairs.",
 "Captain and vice: 5 × 4 = 20, and no two boxes are the same choice. Co-captains: the same 20 boxes, but each pair appears twice, so 20 ÷ 2 = 10.",
 concepts=["pairs"]))

ORDER = ["product", "restrict", "first", "perm", "shrink", "overcount", "groups", "samecount", "order", "pairs"]
for p, cid in zip(L, ORDER):
    p["concept_id"] = cid

# ---- concept tabs are now visual step-by-step stories: governing equation, one-line idea, then the story ----
from .stories import S as _STORIES
IDEA = {
 "product": "If every choice leaves the same number of options for the next decision, multiply the counts.",
 "restrict": "A rule changes what's allowed in a slot: list what's allowed, cross out what's banned, count.",
 "first": "If one rule makes the branches uneven, decide that thing first.",
 "perm": "n different things in a row can be arranged in n × (n − 1) × ⋯ × 1 = n! ways.",
 "shrink": "With no repeats, each slot loses the options already used.",
 "overcount": "Pretend identical things are different, count, then divide by how many copies each real answer has.",
 "groups": "Count with the groups labeled, then divide by the ways to shuffle the whole groups.",
 "samecount": "The options may change from branch to branch. Only their number has to stay the same.",
 "order": "If order doesn't matter, count in order, then divide by the number of orders.",
 "pairs": "Pick grid: count the boxes, cross out the diagonal, then look for twins.",
}
for _cid in list(C):
    _t, _h = C[_cid]
    _eq = _h[:_h.index("</div>") + 6]
    C[_cid] = (_t, _eq + f'<p class="idea"><b>The idea:</b> {IDEA[_cid]}</p>' + _STORIES[_cid])
