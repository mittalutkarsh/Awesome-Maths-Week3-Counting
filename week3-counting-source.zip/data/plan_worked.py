"""Worked answers that walk the counting plan, one picture per plan step, applied to the actual problem.
Small-case checks are verified in verify_plan.py."""
from .visuals import (plan_story, chip, chips, slots, letters, bundle, table, big, row, stack, strike, tree, full_tree, dots, pgrid)
from .worked_stories import squares, plate, cboard, colsplit, par
from . import grids as G

D10 = [str(d) for d in range(10)]
EV = ["0", "2", "4", "6", "8"]; ODD = ["1", "3", "5", "7", "9"]
YES = '<span class="yes">Yes</span>'; NO = '<span class="no">No</span>'

def empty(labels):
    return slots([(l, "", "", "") for l in labels])
def filled(spec, result=None, op="×"):
    return slots([(l, inner, c, "done") for (l, inner, c) in spec], result=result, op=op)
def nums(*xs):
    return '<span class="chips">' + "".join(chip(x) for x in xs) + "</span>"
def T(pid, parts):
    return plan_story("Worked answer: the counting plan, step by step", parts, sid=f"pw-{pid}")
NO_TWINS = lambda why: (big(NO), f"<p>{why} Every answer was built exactly once, so there's nothing to divide.</p>", "Could the same answer have been built two different ways?")

PW = {}

# ---------------- Rule of Product ----------------
PW["q1"] = T("q1", {
 "make": (stack(nums("507", "120", "999"), big(strike("024"), "sm")), "<p>We're making a <b>three-digit number</b>, like 507. Not 024: that's just 24.</p>", "Make up a three-digit number."),
 "steps": (empty(["hundreds", "tens", "ones"]), "<p>A number is a row of digits, so there's one decision per place: hundreds, tens, ones.</p>", ""),
 "same": (slots([("hundreds", chips(D10, banned=["0"]), 9, "on"), ("tens", chips(D10), 10, "on"), ("ones", chips(D10), 10, "on")]),
  "<p>Hundreds: 1 to 9 (zero can't lead), so 9. Tens and ones: any digit, 10 each, <b>whatever the hundreds digit was</b>.</p>", "Does picking 5 first change how many tens digits you can pick?"),
 "mult": (filled([("hundreds", "", 9), ("tens", "", 10), ("ones", "", 10)], "900"), "<p>9 × 10 × 10 = <b>900</b>.</p>", ""),
 "twice": NO_TWINS("There's only one way to build 507: a 5, then a 0, then a 7."),
 "check": (big("100, 101, …, 999  →  999 − 100 + 1 = 900"), "<p>Count the range instead: the same 900.</p>", "Why do we add 1?"),
})
PW["q2"] = T("q2", {
 "make": (stack(nums("248", "806", "460"), big(strike("024"), "sm")), "<p>A three-digit number using only even digits, like 248 or 806.</p>", "Make one up."),
 "steps": (empty(["hundreds", "tens", "ones"]), "<p>One decision per place.</p>", ""),
 "same": (slots([("hundreds", chips(EV, banned=["0"]), 4, "on"), ("tens", chips(EV), 5, "on"), ("ones", chips(EV), 5, "on")]),
  "<p>Hundreds: 2, 4, 6, 8 (zero is even, but it can't lead), so 4. Tens and ones: 0, 2, 4, 6, 8, so 5 each, no matter what came first.</p>", "Is zero even?"),
 "mult": (filled([("hundreds", "", 4), ("tens", "", 5), ("ones", "", 5)], "100"), "<p>4 × 5 × 5 = <b>100</b>.</p>", ""),
 "twice": NO_TWINS("Each number has one digit in each place."),
 "check": (table(["starts with 2"], [["200 202 204 206 208"], ["220 222 … 228"], ["240 … 248"], ["260 … 268"], ["280 … 288"]]),
  "<p>List the ones starting with 2: 5 rows of 5 is 25. There are 4 possible first digits, and 4 × 25 = 100.</p>", ""),
})
PW["q3"] = T("q3", {
 "make": (squares("GYBGG"), "<p>A coloring of the 5 squares with <b>exactly one yellow</b>, like green, yellow, blue, green, green.</p>", "Make one that breaks the rule."),
 "steps": (squares("?????"), "<p>The obvious way: color square 1, then square 2, and so on.</p>", ""),
 "same": (stack(squares("Y????") + big("→ square 2 has 2 colors", "sm"), squares("G????") + big("→ square 2 has 3 colors", "sm"),
          big("Uneven! So decide <u>where the yellow goes</u> first:", "sm"), "".join(squares("".join("Y" if i == k else "?" for i in range(5))) for k in range(5))),
  "<p><b>No</b>, left to right gives uneven branches: after yellow there are 2 colors left, after green there are 3. So change the order: first choose <b>which square is yellow</b> (5 places), then color the others.</p>",
  "Why does choosing the yellow square first fix it?"),
 "mult": (filled([("which is yellow", "", 5), ("other", chips(["G", "B"]), 2), ("other", chips(["G", "B"]), 2), ("other", chips(["G", "B"]), 2), ("other", chips(["G", "B"]), 2)], "80"),
  "<p>After the yellow square is chosen, every other square is green or blue: 5 × 2 × 2 × 2 × 2 = <b>80</b>.</p>", ""),
 "twice": NO_TWINS("Each coloring has exactly one yellow square, so it's built exactly once."),
 "check": (stack(big("1 × 2 grid: 2 places × 2 colors = 4"), row(squares("YG"), squares("YB"), squares("GY"), squares("BY"), gap=".8rem")),
  "<p>Tiny version: 2 squares, exactly one yellow. The method says 2 × 2 = 4, and listing finds exactly 4.</p>", "Try 3 squares. What does the method say?"),
})

# ---------------- Permutations ----------------
def perm_story(pid, word, ex, check_vis, check_say):
    n = len(word)
    counts = list(range(n, 0, -1))
    return T(pid, {
     "make": (letters(ex), f"<p>An arrangement uses every letter of {', '.join(word)} once, like {ex}.</p>", "Make another one."),
     "steps": (empty([f"{i+1}{['st','nd','rd'][i] if i < 3 else 'th'}" for i in range(n)]), f"<p>One decision per position: which letter goes 1st, 2nd, …</p>", ""),
     "same": (stack(slots([("1st", chips(list(word), pick=[word[0]]), n, "on"), ("2nd", chips(list(word), used=[word[0]]), n - 1, "on")]),
                   slots([("1st", chips(list(word), pick=[word[1]]), n, "on"), ("2nd", chips(list(word), used=[word[1]]), n - 1, "on")])),
      f"<p>The 2nd position always has {n - 1} letters left. <i>Which</i> letters depends on the 1st pick, but the number doesn't.</p>", "If the first letter changes, does the count for the 2nd change?"),
     "mult": (filled([(f"{i+1}", "", c) for i, c in enumerate(counts)], str(eval("*".join(map(str, counts))))),
      f"<p>{' × '.join(map(str, counts))} = {n}! = <b>{eval('*'.join(map(str, counts)))}</b>.</p>", ""),
     "twice": NO_TWINS("All the letters are different, so every arrangement is a different word."),
     "check": (check_vis, check_say, ""),
    })
PW["q4"] = perm_story("q4", "AMC", "MCA", row(*[letters(w) for w in ["AMC", "ACM", "MAC", "MCA", "CAM", "CMA"]], gap=".4rem"),
                      "<p>List them, two starting with each letter: 6. ✓</p>")
PW["q5"] = perm_story("q5", "MATH", "HTAM", row(*[letters(w) for w in ["MATH", "MAHT", "MTAH", "MTHA", "MHAT", "MHTA"]], gap=".4rem"),
                      "<p>The ones starting with M: 6, one for each order of A, T, H. Same for each of the 4 first letters: 4 × 6 = 24. ✓</p>")
PW["q6"] = T("q6", {
 "make": (stack(nums("507", "193"), big(strike("550"), "sm")), "<p>A three-digit number with all different digits, like 507. Not 550.</p>", ""),
 "steps": (empty(["hundreds", "tens", "ones"]), "<p>One decision per place.</p>", ""),
 "same": (slots([("hundreds", chips(D10, banned=["0"]), 9, "on"), ("tens", chips(D10, used=["5"]), 9, "on"), ("ones", chips(D10, used=["5", "0"]), 8, "on")]),
  "<p>Hundreds: not zero, 9. Tens: zero is back, but the first digit (say 5) is used: 9. Ones: two digits used: 8. The used digits change, the counts don't.</p>", "Why do the first two places both have 9, for different reasons?"),
 "mult": (filled([("hundreds", "", 9), ("tens", "", 9), ("ones", "", 8)], "648"), "<p>9 × 9 × 8 = <b>648</b>.</p>", ""),
 "twice": NO_TWINS("A number is built one digit per place."),
 "check": (big("two-digit, different digits: 9 × 9 = 81 = 90 − 9 (11, 22, …, 99)"), "<p>Same method on two-digit numbers gives 81. Check: 90 two-digit numbers minus the 9 with a repeat. ✓</p>", ""),
})

# ---------------- Overcounting ----------------
def over_story(pid, word, ex, tally, paint_vis, copies_vis, copies_say, n, div_label, result, small_vis, small_say):
    return T(pid, {
     "make": (letters(ex), f"<p>An arrangement of the letters of {word}, like {ex}.</p>", "Make another one."),
     "steps": (stack(tally, paint_vis), "<p>Repeated letters make the slots uneven. So <b>paint the repeats</b> different colors first. Now every letter is different and we can fill the positions one at a time.</p>", "Why paint them?"),
     "same": (empty([str(i + 1) for i in range(n)]) if n <= 7 else big(f"{n} positions"), f"<p>With painted letters, position 1 has {n} options, position 2 has {n - 1}, and so on: always the same counts.</p>", ""),
     "mult": (big(f"{n}! painted arrangements"), f"<p>{n}! arrangements of the painted letters.</p>", ""),
     "twice": (stack(big(YES), copies_vis), f"<p><b>Yes.</b> {copies_say}</p>", "How many painted copies does one real word have?"),
     "divide": (big(f"{n}! ÷ {div_label} = {result}"), f"<p>Every real word has the same number of painted copies, so divide: <b>{result}</b>.</p>", ""),
     "check": (small_vis, small_say, "Make a tiny word with a repeat and test the method."),
    })
PW["q7"] = over_story("q7", "HELLO", "LOHEL", table(["H", "E", "L", "O"], [["1", "1", "2", "1"]]),
  letters("HELLO", {2: "blue", 3: "red"}, {2: "1", 3: "2"}),
  bundle([letters("HELLO", {2: "blue", 3: "red"}, {2: "1", 3: "2"}), letters("HELLO", {2: "red", 3: "blue"}, {2: "2", 3: "1"})], letters("HELLO")),
  "Wash off the paint: HEL₁L₂O and HEL₂L₁O are the same word. Every word appears 2! = 2 times.", 5, "2!", "60",
  stack(big("LOL: 3! ÷ 2! = 3"), row(letters("LOL"), letters("LLO"), letters("OLL"), gap=".5rem")), "<p>Tiny word LOL: the method says 6 ÷ 2 = 3, and there are exactly 3. ✓</p>")
PW["q8"] = over_story("q8", "GREENER", "ENGREER", table(["G", "R", "E", "N"], [["1", "2", "3", "1"]]),
  letters("GREENER", {1: "blue", 6: "red", 2: "blue", 3: "red", 5: "green"}, {1: "1", 6: "2", 2: "1", 3: "2", 5: "3"}),
  big("orders of E₁E₂E₃: 3! = 6   ×   orders of R₁R₂: 2! = 2   =   12 copies", "sm"),
  "Each real word appears once for every order of the painted E's (3! = 6) times every order of the painted R's (2! = 2): 12 copies. Multiply, because every E-order goes with every R-order.",
  7, "(3! × 2!)", "420", stack(big("EER: 3! ÷ 2! = 3"), row(letters("EER"), letters("ERE"), letters("REE"), gap=".5rem")), "<p>Tiny word EER: 6 ÷ 2 = 3 and listing finds 3. ✓</p>")
PW["q9"] = over_story("q9", "MISSISSIPPI", "SIMPISSIPIS", table(["M", "I", "S", "P"], [["1", "4", "4", "2"]]),
  big("paint every I, S and P", "sm"), big("copies of each word = 4! × 4! × 2!", "sm"),
  "Each real word appears once for every order of the I's, times every order of the S's, times every order of the P's.",
  11, "(4! × 4! × 2!)", "34,650", stack(big("SIS: 3! ÷ 2! = 3"), row(letters("SIS"), letters("SSI"), letters("ISS"), gap=".5rem")),
  "<p>Tiny word SIS: 3 ✓. The problem wants factorial form: 11!/(4!·4!·2!).</p>")

# ---------------- Problem solving ----------------
def chairs_pic(labels, cls):
    return '<div class="chairs">' + "".join(f'<div class="chair {c}">{l}</div>' for l, c in zip(labels, cls)) + "</div>"
PW["q10"] = T("q10", {
 "make": (chairs_pic(["Al", "Gi", "Ha", "Ivy", "Bo"], ["full"] * 5), "<p>One photo: Al, Gi, Ha, Ivy, Bo (boys Al and Bo at the ends).</p>", ""),
 "steps": (chairs_pic(["boy", "", "", "", "boy"], ["next", "", "", "", "next"]), "<p>Five seats. The ends are restricted, so <b>do the ends first</b>, then the middle.</p>", "Which seats are the hardest to fill?"),
 "same": (slots([("left end", chips(["Al", "Bo"]), 2, "on"), ("right end", "the other boy", 1, "on"), ("middle", chips(["girls"]), 3, "on"), ("middle", "", 2, "on"), ("middle", "", 1, "on")]),
  "<p>Left end: either boy (2). Right end: the other boy (1). Middle: 3, 2, 1 girls. Always the same counts.</p>", ""),
 "mult": (filled([("left", "", 2), ("right", "", 1), ("mid", "", 3), ("mid", "", 2), ("mid", "", 1)], "12"), "<p>2 × 1 × 3 × 2 × 1 = <b>12</b>.</p>", ""),
 "twice": NO_TWINS("Everyone is a different person, so different seatings are different photos."),
 "check": (stack(big("Al _ _ _ Bo: 6 orders of the girls"), big("Bo _ _ _ Al: 6 orders of the girls")), "<p>List by which boy is on the left: 6 + 6 = 12. ✓</p>", ""),
})
PW["q11"] = T("q11", {
 "make": (stack(nums("2071", "9384"), big(strike("1123"), "sm")), "<p>A four-digit number with four different digits, like 2071.</p>", ""),
 "steps": (empty(["1st", "2nd", "3rd", "4th"]), "<p>One decision per place.</p>", ""),
 "same": (slots([("1st", chips(D10, banned=["0"]), 9, "on"), ("2nd", "zero back, 1 used", 9, "on"), ("3rd", "2 used", 8, "on"), ("4th", "3 used", 7, "on")]), "<p>9, then 9, 8, 7 as digits get used up.</p>", ""),
 "mult": (filled([("1st", "", 9), ("2nd", "", 9), ("3rd", "", 8), ("4th", "", 7)], "4536"), "<p>9 × 9 × 8 × 7 = <b>4536</b>.</p>", ""),
 "twice": NO_TWINS("One digit per place."),
 "check": (big("three-digit version: 9 × 9 × 8 = 648 (Problem 6)  →  × 7 = 4536"), "<p>It's Problem 6 with one more place, which has 7 options left.</p>", ""),
})
PW["q12"] = T("q12", {
 "make": (big("one game: team 3 at home, team 5 away"), "<p>We're counting <b>games</b>. A conference game has a home team and an away team.</p>", ""),
 "steps": (empty(["home team", "away team"]), "<p>Two decisions: who's at home, who's away.</p>", ""),
 "same": (slots([("home team", chips([str(k) for k in range(1, 9)]), 8, "on"), ("away team", "any other team", 7, "on")]), "<p>Home: 8 teams. Away: any of the other 7.</p>", ""),
 "mult": (stack(filled([("home", "", 8), ("away", "", 7)], "56"), big("+ non-conference: 8 teams × 4 = 32  →  56 + 32 = 88")),
  "<p>56 conference games. Non-conference games have just one conference team each: 8 × 4 = 32. Total <b>88</b>.</p>", ""),
 "twice": (stack(big(NO), pgrid([str(k) for k in range(1, 9)], 2, rowh="home", colh="away", plain=True, sep="v")),
  "<p><b>No twins:</b> 3 at home to 5 and 5 at home to 3 are two different games, both really played.</p>", "Why is this different from a handshake?"),
 "check": (big(strike("8 × 14 = 112") + "  →  each game counted by both teams  →  112 ÷ 2 = 56"), "<p>Team by team: 8 teams × 14 games counts each game twice. Halving gives 56 again. ✓</p>", ""),
})
PW["q13"] = T("q13", {
 "make": (nums("1", "2", "1", "3", "3", "2", "1", "1", "2", "3"), "<p>One way to hand out candy: kid 1 gets 1, kid 2 gets 2, and so on. No two neighbors add to 4.</p>", "Is 1, 3 allowed for two neighbors?"),
 "steps": (empty([f"kid {i}" for i in range(1, 11)]), "<p>One decision per kid, left to right.</p>", ""),
 "same": (table(["this kid", "next kid can't get", "next kid can get"], [["1", "3", "1 or 2"], ["2", "2", "1 or 3"], ["3", "1", "2 or 3"]]),
  "<p>Kid 1: 3 options. After that, exactly one amount is banned each time, so every later kid has <b>2</b> options. Different amounts, same number.</p>", "Check each row. Always 2?"),
 "mult": (big("3 × 2 × 2 × 2 × 2 × 2 × 2 × 2 × 2 × 2 = 3 × 2⁹ = 1536"), "<p>One 3 and nine 2's: <b>1536</b>.</p>", "Why nine 2's?"),
 "twice": NO_TWINS("Each kid's amount is one decision."),
 "check": (stack(big("2 kids: 3 × 2 = 6"), nums("1,1", "1,2", "2,1", "2,3", "3,2", "3,3")), "<p>Tiny version with 2 kids: the method says 6, the list has 6. ✓</p>", ""),
})
PW["q14"] = T("q14", {
 "make": (nums("357", "111", "642"), "<p>A three-digit number whose middle digit is the average of the other two, like 357.</p>", ""),
 "steps": (empty(["first", "last", "middle"]), "<p>Pick the first and last digits. Then the middle is <b>forced</b>: it must be their average.</p>", ""),
 "same": (stack(big("3 _ 7 → (3 + 7) ÷ 2 = 5 → 357"), big("3 _ 8 → 5.5 → no number")),
  "<p><b>No!</b> Some pairs give a whole-number middle and some give nothing. So <b>split into cases</b>: both ends odd, or both ends even (those are the pairs that work).</p>", "When is the average a whole number?"),
 "mult": (stack(table(["first ↓ last →"] + [str(c) for c in range(10)], par), big("odd ends: 5 × 5 = 25   even ends: 4 × 5 = 20   →   25 + 20 = 45")),
  "<p>Both odd: 5 × 5 = 25. Both even, first not zero: 4 × 5 = 20. Add the cases: <b>45</b>.</p>", "Why 4 even first digits, not 5?"),
 "twice": NO_TWINS("A number can't be in both cases."),
 "check": (big("starting with 1: 111, 123, 135, 147, 159 → 5"), "<p>Check row 1 of the table: 5 numbers, matching 5 ticks. ✓</p>", ""),
})
PW["q15"] = T("q15", {
 "make": (plate(2).replace(">L<", ">Q<"), "<p>A plate like 4 8 Q Q 1 9: four digits and two letters, letters side by side.</p>", ""),
 "steps": ("".join(plate(k) for k in range(5)), "<p>Decisions: where the letter pair goes, then each letter, then each digit.</p>", ""),
 "same": (slots([("letter pair place", "", 5, "on"), ("letter", "A–Z", 26, "on"), ("letter", "A–Z", 26, "on"), ("each digit", "0–9", 10, "on")]),
  "<p>The pair starts at character 1 to 5 (not 6: no room), so 5. Each letter: 26. Each digit: 10. Repeats allowed.</p>", "Can a plate start with 0?"),
 "mult": (big("5 × 26 × 26 × 10 × 10 × 10 × 10 = 33,800,000"), "<p><b>33,800,000</b> = 2⁶ · 5⁵ · 13².</p>", ""),
 "twice": NO_TWINS("Each plate has its letters in one place."),
 "check": (stack(big("tiny: 1 digit, 2 letters from {A, B}, digits {0, 1}: 2 places × 2 × 2 × 2 = 16"),
                 nums("AA0", "AA1", "AB0", "AB1", "BA0", "BA1", "BB0", "BB1", "0AA", "1AA", "0AB", "1AB", "0BA", "1BA", "0BB", "1BB")),
  "<p>A tiny version: the method says 16, and the list has 16. ✓</p>", ""),
})
PW["q16"] = T("q16", {
 "make": (big("appetizer #3 + main #2 + dessert #1"), "<p>We're making a <b>dinner</b>: one appetizer, one main, one dessert.</p>", ""),
 "steps": (empty(["appetizer", "main", "dessert"]), "<p>Three decisions.</p>", ""),
 "same": (slots([("appetizer", "2 × mains", "2m", "on"), ("main", "", "m", "on"), ("dessert", "", 3, "on")]), "<p>If there are m mains, there are 2m appetizers and 3 desserts.</p>", ""),
 "mult": (table(["mains m", "dinners 2m × m × 3", "≥ 365?"], [["6", "216", "no"], ["7", "294", "no"], ["8", "384", "yes"]], hl_row=2),
  "<p>Try values of m. 2003 isn't a leap year, so we need 365 dinners. The first that works is <b>8</b>.</p>", ""),
 "twice": NO_TWINS("A dinner is one of each course."),
 "check": (big("7 mains → 294 < 365, so 7 is too few"), "<p>'Least' means checking the number below: 7 doesn't work, so 8 is the least. ✓</p>", "Why check 7?"),
})
PW["q17"] = T("q17", {
 "make": (stack(big("1000 + 492 = 1492  ✓ simple"), big(strike("999 + 493") + "  9 + 3 = 12 carries", "sm")), "<p>A simple pair adds to 1492 with no carrying, like 1000 + 492.</p>", ""),
 "steps": (empty(["thousands", "hundreds", "tens", "ones"]), "<p>No carrying means each column adds up to exactly that digit of 1492. So decide each column separately.</p>", "Why can't any column reach 10?"),
 "same": (table(["column", "digit", "splits", "count"], [["thousands", "1", colsplit(1), "2"], ["hundreds", "4", colsplit(4), "5"], ["tens", "9", "0+9 … 9+0", "10"], ["ones", "2", colsplit(2), "3"]]),
  "<p>A digit d splits into d + 1 ordered pairs. Each column doesn't care what the others did.</p>", ""),
 "mult": (filled([("thousands", "", 2), ("hundreds", "", 5), ("tens", "", 10), ("ones", "", 3)], "300"), "<p>2 × 5 × 10 × 3 = <b>300</b>.</p>", ""),
 "twice": NO_TWINS("The problem counts 1000 + 492 and 492 + 1000 as different, and our columns build each ordered pair once."),
 "check": (stack(big("sum 12: tens 2 ways × ones 3 ways = 6"), nums("0+12", "1+11", "2+10", "10+2", "11+1", "12+0")), "<p>Tiny version, pairs summing to 12: the method says 6, the list has 6. ✓</p>", ""),
})
PW["q18"] = T("q18", {
 "make": (cboard(1).replace("0/2", "2", 3).replace("0/2", "0", 4).replace("0/2", "2"), "<p>One valid grid: 1s on the dark squares, 0s and 2s on the light squares.</p>", ""),
 "steps": (cboard(0), "<p>25 cells to fill. But the rule ties neighbors together, so they aren't free decisions.</p>", ""),
 "same": (stack(table(["cell", "neighbors must be"], [["0", "1"], ["1", "0 or 2"], ["2", "1"]]), big("→ all the 1s sit on one checkerboard color", "sm")),
  "<p><b>Not as it stands.</b> The 1s and the 0-or-2s must alternate like a checkerboard. So <b>split into two cases</b>: 1s on the dark cells, or 1s on the light cells. In each case the other cells are free.</p>", "Why must the 1s all be on the same color?"),
 "mult": (row(stack(cboard(1), big("12 light cells: 2¹² = 4096", "sm")), stack(cboard(2), big("13 dark cells: 2¹³ = 8192", "sm"))),
  "<p>Case A: 2¹² = 4096. Case B: 2¹³ = 8192. Add the cases: <b>12,288</b>.</p>", "Why add the two cases?"),
 "twice": NO_TWINS("A grid can't be in both cases."),
 "check": (stack(big("1 × 2 grid: 2¹ + 2¹ = 4"), nums("0 1", "2 1", "1 0", "1 2")), "<p>Tiny grid of 2 cells: the method says 4, the list has 4. ✓</p>", ""),
})
PW["q19"] = T("q19", {
 "make": (nums("1368", "47", "5"), "<p>A number with digits increasing left to right, like 1368.</p>", ""),
 "steps": (empty([str(d) for d in range(1, 10)]), "<p>Choose <b>which digits</b> appear: once you know them, the increasing order is forced. One in-or-out decision per digit 1 to 9. (0 can't appear.)</p>", "Why is the order forced?"),
 "same": (slots([(str(d), chips(["in", "out"]), 2, "on") for d in range(1, 10)]), "<p>Every digit: in or out, 2 options.</p>", ""),
 "mult": (big("2⁹ = 512"), "<p>2 × 2 × ⋯ × 2 = 512 ways to choose.</p>", ""),
 "twice": (big("no twins, but one choice is 'all out' → no number"), "<p>Each choice gives a different number, but one choice is empty and makes no number at all.</p>", ""),
 "divide": (big("512 − 1 = 511"), "<p>Take away the empty choice: <b>511</b>.</p>", ""),
 "check": (stack(big("digits 1–3 only: 2³ − 1 = 7"), nums("1", "2", "3", "12", "13", "23", "123")), "<p>Tiny version: 7 by the method, 7 in the list. ✓</p>", ""),
})

# ---------------- Challenge ----------------
PW["u4"] = T("u4", {
 "make": (nums("47", "74", "77"), "<p>A two-digit number with at least one 7.</p>", ""),
 "steps": (big("easier: count the ones with <u>no</u> 7, then take them away from all 90"), "<p>'At least one' is awkward. Count the opposite instead.</p>", ""),
 "same": (slots([("tens", chips(D10, banned=["0", "7"]), 8, "on"), ("ones", chips(D10, banned=["7"]), 9, "on")]), "<p>No 7: tens 1–9 except 7 (8), ones 0–9 except 7 (9).</p>", ""),
 "mult": (big("8 × 9 = 72 with no 7  →  90 − 72 = 18"), "<p><b>18</b> have at least one 7.</p>", ""),
 "twice": (stack(big("lists way: 70–79 (10) and 17, 27, …, 97 (9)"), big("77 is on both lists!", "sm")), "<p>If you count with two lists instead, one number, 77, is counted twice.</p>", ""),
 "divide": (big("10 + 9 − 1 = 18"), "<p>Only one number was doubled (not every number), so take away 1 instead of dividing.</p>", "When do we divide, and when do we just take away?"),
 "check": (big("90 − 72 = 18   and   10 + 9 − 1 = 18 ✓"), "<p>Two different methods give the same answer.</p>", ""),
})
PW["u5"] = T("u5", {
 "make": (nums("484", "101", "959"), "<p>A three-digit palindrome, like 484.</p>", ""),
 "steps": (empty(["first", "middle", "last"]), "<p>One decision per place.</p>", ""),
 "same": (slots([("first", chips(D10, banned=["0"]), 9, "on"), ("middle", chips(D10), 10, "on"), ("last", "must match the first", 1, "on")]), "<p>First: 9. Middle: 10. Last: forced, 1.</p>", ""),
 "mult": (filled([("first", "", 9), ("middle", "", 10), ("last", "", 1)], "90"), "<p><b>90</b>.</p>", ""),
 "twice": NO_TWINS("One digit per place."),
 "check": (big("starting with 1: 101, 111, …, 191 → 10;  9 first digits × 10 = 90"), "<p>✓</p>", ""),
})
PW["u15"] = T("u15", {
 "make": (nums("30412", "10234"), "<p>A 5-digit number using 0, 1, 2, 3, 4 once each, not starting with 0.</p>", ""),
 "steps": (empty(["1st", "2nd", "3rd", "4th", "5th"]), "<p>One decision per place.</p>", ""),
 "same": (slots([("1st", chips(list("01234"), banned=["0"]), 4, "on"), ("2nd", "0 allowed, 1 used", 4, "on"), ("3rd", "", 3, "on"), ("4th", "", 2, "on"), ("5th", "", 1, "on")]), "<p>4, then 4, 3, 2, 1.</p>", ""),
 "mult": (filled([("1st", "", 4), ("2nd", "", 4), ("3rd", "", 3), ("4th", "", 2), ("5th", "", 1)], "96"), "<p><b>96</b>.</p>", ""),
 "twice": NO_TWINS("All digits are different."),
 "check": (big("all orders 5! = 120, minus those starting with 0: 4! = 24 → 96"), "<p>✓</p>", ""),
})
PW["u16"] = T("u16", {
 "make": (chairs_pic(["short", "B", "D", "A", "C", "tall"], ["full"] * 6), "<p>One lineup: shortest first, tallest last.</p>", ""),
 "steps": (chairs_pic(["short", "", "", "", "", "tall"], ["full", "next", "next", "next", "next", "full"]), "<p>The ends are fixed. Only the 4 middle spots are decisions.</p>", ""),
 "same": (slots([("spot 2", "", 4, "on"), ("spot 3", "", 3, "on"), ("spot 4", "", 2, "on"), ("spot 5", "", 1, "on")]), "<p>4, 3, 2, 1.</p>", ""),
 "mult": (big("4! = 24"), "<p><b>24</b>.</p>", ""),
 "twice": NO_TWINS("Every child is different."),
 "check": (big("4 children: middle 2 spots → 2! = 2 (S A B T, S B A T)"), "<p>✓</p>", ""),
})
PW["u17"] = T("u17", {
 "make": ('<div class="books"><span class="bk">Q</span><span class="bk blk">V1 V2</span><span class="bk">P</span><span class="bk">R</span></div>', "<p>One shelf: Q, then the atlas volumes together, then P, R.</p>", ""),
 "steps": (big("glue V1 V2 into one block → arrange 4 things, then order inside the block"), "<p>'Must be together' is the awkward rule, so glue them into a block first.</p>", ""),
 "same": (slots([("1st thing", "", 4, "on"), ("2nd", "", 3, "on"), ("3rd", "", 2, "on"), ("4th", "", 1, "on"), ("inside block", chips(["V1V2", "V2V1"]), 2, "on")]), "<p>4, 3, 2, 1 for the four things, and 2 orders inside the block.</p>", ""),
 "mult": (big("24 × 2 = 48"), "<p><b>48</b>.</p>", "What if you forgot the order inside the block?"),
 "twice": NO_TWINS("Every book is different."),
 "check": (stack(big("3 books, block + P: 2! × 2 = 4"), nums("V1V2 P", "V2V1 P", "P V1V2", "P V2V1")), "<p>Tiny version: 4 = 4. ✓</p>", ""),
})
PW["u20"] = T("u20", {
 "make": (big("9! ÷ 7!"), "<p>Not a 'making' problem, just factorial arithmetic.</p>", ""),
 "steps": (big("9! = 9 × 8 × <u>7 × 6 × 5 × 4 × 3 × 2 × 1</u>"), "<p>Write 9! out. The underlined part is exactly 7!.</p>", ""),
 "mult": (big("9! ÷ 7! = 9 × 8 = 72"), "<p>The 7! cancels: <b>72</b>.</p>", ""),
 "check": (big("362,880 ÷ 5,040 = 72"), "<p>✓</p>", ""),
})
PW["u23"] = T("u23", {
 "make": (dots(["Ana", "Ben", "Cy", "Dot"], [(0, 1)], [(0, 1)], r=60), "<p>One handshake: Ana and Ben.</p>", ""),
 "steps": (empty(["1st person", "2nd person"]), "<p>Pick one person, then the person they shake with.</p>", ""),
 "same": (slots([("1st person", "", 12, "on"), ("2nd person", "anyone else", 11, "on")]), "<p>12, then 11.</p>", ""),
 "mult": (big("12 × 11 = 132"), "<p>132 ordered picks.</p>", ""),
 "twice": (stack(big(YES), G.G_HANDS), "<p><b>Yes.</b> Ana-then-Ben and Ben-then-Ana are the same handshake. Every handshake appears twice in the grid.</p>", "Is Ana–Ben the same as Ben–Ana?"),
 "divide": (big("132 ÷ 2 = 66"), "<p><b>66</b>.</p>", ""),
 "check": (dots(["A", "B", "C", "D"], [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)], r=55), "<p>4 people: 4 × 3 ÷ 2 = 6, and the picture has 6 lines. ✓</p>", ""),
})
PW["u24"] = T("u24", {
 "make": (dots([str(i) for i in range(1, 13)], [(0, 5)], [(0, 5)], r=90), "<p>One diagonal: from corner 1 to corner 6.</p>", ""),
 "steps": (empty(["start corner", "end corner"]), "<p>Pick a start corner, then an end corner.</p>", ""),
 "same": (stack(dots([str(i) for i in range(1, 13)], [(0, k) for k in range(2, 11)], [(0, k) for k in range(2, 11)], r=90),
                slots([("start", "", 12, "on"), ("end", "not itself or a neighbor", 9, "on")])), "<p>12 starts, and from each one 12 − 3 = 9 ends.</p>", ""),
 "mult": (big("12 × 9 = 108"), "<p>108 'start → end' picks.</p>", ""),
 "twice": (big(YES + "  1 → 6 is the same diagonal as 6 → 1"), "<p><b>Yes.</b> Each diagonal has two ends, so it was counted from both.</p>", ""),
 "divide": (big("108 ÷ 2 = 54"), "<p><b>54</b>.</p>", ""),
 "check": (row(dots(list("ABCD"), [(0, 2), (1, 3)], r=45), dots(list("ABCDE"), [(0, 2), (0, 3), (1, 3), (1, 4), (2, 4)], r=45)), "<p>Square: 4 × 1 ÷ 2 = 2 ✓. Pentagon: 5 × 2 ÷ 2 = 5 ✓.</p>", ""),
})
PW["u25"] = T("u25", {
 "make": (big("{L, G}  and  {A, W, R, F}"), "<p>One split: Lizzie and Grogg in the pair, the rest in the four.</p>", ""),
 "steps": (empty(["pair: 1st", "pair: 2nd", "group of 4"]), "<p>Pick the pair one at a time. The group of 4 is then whoever is left.</p>", ""),
 "same": (slots([("pair: 1st", "", 6, "on"), ("pair: 2nd", "", 5, "on"), ("group of 4", "the rest", 1, "on")]), "<p>6, 5, then 1 (no choice left).</p>", ""),
 "mult": (stack(big("6 × 5 × 1 = 30"), pgrid(list("LGAWRF"), 2)), "<p>30 boxes once the diagonal is crossed out.</p>", ""),
 "twice": (stack(big(YES), pgrid(list("LGAWRF"), 3, twin_hl=(0, 1))), "<p><b>Yes.</b> LG and GL are the same pair. Every box has a twin across the diagonal.</p>", "Are LG and GL different groups?"),
 "divide": (big("30 ÷ 2 = 15"), "<p><b>15</b>.</p>", ""),
 "check": (G.G_SPLIT, "<p>Each teal box shows the pair and the four left over: 15 different splits. ✓</p>", ""),
})
PW["u26"] = T("u26", {
 "make": (big("{Ana, Ben, Cal}"), "<p>One trio. All three have the same job, so it's a group with no order.</p>", ""),
 "steps": (empty(["1st pick", "2nd pick", "3rd pick"]), "<p>Pick one player at a time.</p>", ""),
 "same": (slots([("1st", "", 10, "on"), ("2nd", "", 9, "on"), ("3rd", "", 8, "on")]), "<p>10, 9, 8.</p>", ""),
 "mult": (big("10 × 9 × 8 = 720"), "<p>720 ordered picks.</p>", ""),
 "twice": (stack(big(YES), bundle([letters(w) for w in ["ABC", "ACB", "BAC", "BCA", "CAB", "CBA"]], "one trio")), "<p><b>Yes.</b> The trio {A, B, C} was picked in 3! = 6 orders.</p>", ""),
 "divide": (big("720 ÷ 6 = 120"), "<p><b>120</b>.</p>", ""),
 "check": (stack(big("trios from 4 kids: 4 × 3 × 2 ÷ 6 = 4"), nums("ABC", "ABD", "ACD", "BCD")), "<p>✓</p>", ""),
})
PW["u28"] = T("u28", {
 "make": (big("7♥ + Q♠"), "<p>One hand: a red card and a black card.</p>", ""),
 "steps": (empty(["red card", "black card"]), "<p>Pick the red card, then the black card.</p>", ""),
 "same": (slots([("red card", "", 26, "on"), ("black card", "", 26, "on")]), "<p>26 and 26.</p>", ""),
 "mult": (big("26 × 26 = 676"), "<p>676.</p>", ""),
 "twice": (stack(big(NO), G.G_RB), "<p><b>No.</b> The red card can only ever be the 'red card' choice, so a hand can't be built the other way round. Don't divide: <b>676</b>.</p>", "Why is this different from handshakes?"),
 "check": (stack(big("deck of 2 red, 2 black: 2 × 2 = 4"), nums("R1 B1", "R1 B2", "R2 B1", "R2 B2")), "<p>✓</p>", ""),
})
PW["u29"] = T("u29", {
 "make": (big("5♠ + K♦"), "<p>One hand: a spade and a face card.</p>", ""),
 "steps": (empty(["spade", "face card"]), "<p>Pick the spade, then the face card.</p>", ""),
 "same": (slots([("spade", "", 13, "on"), ("face card", "", 12, "on")]), "<p>13 and 12.</p>", ""),
 "mult": (big("13 × 12 = 156"), "<p>156 boxes in the grid.</p>", ""),
 "twice": (stack(big(YES + " but only in one corner"), G.G_SF), "<p>J♠, Q♠ and K♠ are both spades and face cards. Three boxes use one card twice (×), and J♠ + Q♠ shows up twice (twins). Only these boxes are a problem.</p>", "Find the twin of J♠Q♠."),
 "divide": (big("156 − 3 − 3 = 150"), "<p>Not every hand was doubled, so take away the bad boxes instead of dividing: <b>150</b>.</p>", ""),
 "check": (big("10 × 9 + 3 × 19 + 3 = 90 + 57 + 3 = 150"), "<p>Cases: plain spade + plain face; one of J♠Q♠K♠ + any plain card; two of J♠Q♠K♠. Same 150. ✓</p>", ""),
})
PW["ub"] = T("ub", {
 "make": (stack(big("(b) President A, Vice B, Secretary C, Treasurer D"), big("(a) committee {A, B, C, D}")), "<p>Two different things: a slate of officers, and a committee.</p>", ""),
 "steps": (empty(["President", "Vice", "Secretary", "Treasurer"]), "<p>Fill the four jobs one at a time.</p>", ""),
 "same": (slots([("President", "", 8, "on"), ("Vice", "", 7, "on"), ("Secretary", "", 6, "on"), ("Treasurer", "", 5, "on")]), "<p>8, 7, 6, 5.</p>", ""),
 "mult": (big("8 × 7 × 6 × 5 = 1680  →  answer (b)"), "<p>Different jobs: <b>1680</b> slates.</p>", ""),
 "twice": (big(YES + " for the committee: one committee = 4! = 24 slates"), "<p>For (a), the same four people in any of 24 job orders is the same committee.</p>", ""),
 "divide": (big("1680 ÷ 24 = 70  →  answer (a)"), "<p><b>70</b> committees.</p>", ""),
 "check": (big("70 × 24 = 1680 ✓"), "<p>That's why one answer is exactly 24 times the other.</p>", ""),
})

# ---------------- Lesson guided problems ----------------
PW["c1"] = T("c1", {
 "make": (big("shirt #2 + pants #1 + shoes #2"), "<p>One outfit.</p>", ""),
 "steps": (empty(["shirt", "pants", "shoes"]), "<p>Three decisions.</p>", ""),
 "same": (slots([("shirt", "", 4, "on"), ("pants", "", 3, "on"), ("shoes", "", 2, "on")]), "<p>Every shirt goes with all 3 pants, every pair with both shoes.</p>", ""),
 "mult": (big("4 × 3 × 2 = 24"), "<p><b>24</b>. (4 × 3 = 12 shirt-and-pants pairs first.)</p>", ""),
 "twice": NO_TWINS("Each outfit is one shirt, one pants, one shoes."),
 "check": (tree(full_tree([["S1", "S2", "S3", "S4"], ["P1", "P2", "P3"]]), label_root="outfit", width_per_leaf=34), "<p>The shirt-and-pants tree has 12 leaves ✓; each splits into 2 shoes.</p>", ""),
})
PW["c2"] = T("c2", {
 "make": (nums("37591", "11111"), "<p>A five-digit number with only odd digits.</p>", ""),
 "steps": (empty(["1st", "2nd", "3rd", "4th", "5th"]), "<p>One decision per place.</p>", ""),
 "same": (slots([(k, chips(ODD), 5, "on") for k in ["1st", "2nd", "3rd", "4th", "5th"]]), "<p>1, 3, 5, 7, 9 in every place. None is zero, so the first place isn't special.</p>", ""),
 "mult": (big("5⁵ = 3125"), "<p><b>3125</b>.</p>", ""),
 "twice": NO_TWINS("One digit per place."),
 "check": (big("two-digit version: 5 × 5 = 25 (11, 13, …, 99)"), "<p>✓</p>", ""),
})
PW["c3"] = T("c3", {
 "make": (big("Mrs drives, Mr front, kids in back"), "<p>One seating.</p>", ""),
 "steps": (empty(["driver", "front", "back L", "back R"]), "<p>The driver's seat is restricted, so it goes first.</p>", ""),
 "same": (slots([("driver", chips(["Mr", "Mrs"]), 2, "on"), ("front", "", 3, "on"), ("back L", "", 2, "on"), ("back R", "", 1, "on")]), "<p>2, then 3, 2, 1.</p>", ""),
 "mult": (big("2 × 3 × 2 × 1 = 12"), "<p><b>12</b>.</p>", ""),
 "twice": NO_TWINS("Everyone is a different person."),
 "check": (big("Mr drives: 3! = 6 seatings; Mrs drives: 6 → 12"), "<p>✓</p>", ""),
})
PW["c4"] = perm_story("c4", "ABC", "CAB", row(*[letters(w) for w in ["ABC", "ACB", "BAC", "BCA", "CAB", "CBA"]], gap=".4rem"), "<p>List: 6 ✓.</p>")
PW["c5"] = T("c5", {
 "make": (nums("40719"), "<p>A five-digit number with all different digits.</p>", ""),
 "steps": (empty(["1st", "2nd", "3rd", "4th", "5th"]), "<p>One decision per place.</p>", ""),
 "same": (slots([("1st", chips(D10, banned=["0"]), 9, "on"), ("2nd", "zero back, 1 used", 9, "on"), ("3rd", "2 used", 8, "on"), ("4th", "3 used", 7, "on"), ("5th", "4 used", 6, "on")]), "<p>9, 9, 8, 7, 6.</p>", ""),
 "mult": (big("9 × 9 × 8 × 7 × 6 = 27,216"), "<p><b>27,216</b>.</p>", ""),
 "twice": NO_TWINS("One digit per place."),
 "check": (big("two-digit version: 9 × 9 = 81 = 90 − 9"), "<p>✓</p>", ""),
})
AABC12 = ["AABC", "AACB", "ABAC", "ABCA", "ACAB", "ACBA", "BAAC", "BACA", "BCAA", "CAAB", "CABA", "CBAA"]
PW["c6"] = T("c6", {
 "make": (letters("CABA"), "<p>An arrangement of A, A, B, C, like CABA.</p>", ""),
 "steps": (letters("AABC", {0: "blue", 1: "red"}, {0: "1", 1: "2"}), "<p>Paint the A's so all letters are different, then fill 4 positions.</p>", ""),
 "same": (empty(["1", "2", "3", "4"]), "<p>4, 3, 2, 1 for the painted letters.</p>", ""),
 "mult": (big("4! = 24 painted arrangements"), "<p>24.</p>", ""),
 "twice": (stack(big(YES), bundle([letters("CABA", {1: "blue", 3: "red"}, {1: "1", 3: "2"}), letters("CABA", {1: "red", 3: "blue"}, {1: "2", 3: "1"})], letters("CABA"))), "<p><b>Yes.</b> Each word has 2 painted copies.</p>", ""),
 "divide": (stack(big("4! ÷ 2! = 12"), big("A, A, A, B, C: 5! ÷ 3! = 20", "sm")), "<p><b>12</b>. With three A's each word has 3! = 6 copies: 120 ÷ 6 = <b>20</b>.</p>", ""),
 "check": (row(*[letters(w) for w in AABC12], gap=".35rem"), "<p>All 12 words of A, A, B, C. ✓</p>", ""),
})
PW["c7"] = T("c7", {
 "make": (big("tube A: coins 3, 9, 1, 14, 7 (bottom to top) …"), "<p>One way to fill the tubes.</p>", ""),
 "steps": (empty(["tube A: 5 spots", "tube B: 5 spots", "tube C: 5 spots"]), "<p>Fill the 15 spots one coin at a time.</p>", ""),
 "same": (big("15, 14, 13, …, 1"), "<p>Each spot has one fewer coin available.</p>", ""),
 "mult": (big("15! with labeled tubes"), "<p>Distinct tubes: <b>15!</b>.</p>", ""),
 "twice": (big(YES + " if the tubes are identical: swapping whole stacks looks the same"), "<p>With identical tubes, the 3! = 6 ways to shuffle the three stacks all look the same.</p>", "Should we also divide by 5! for each tube?"),
 "divide": (big("15! ÷ 3!"), "<p>Identical tubes: <b>15!/3!</b>. Don't divide for the order inside a tube: that order matters.</p>", ""),
 "check": (big("4 coins, 2 tubes of 2: 4! = 24 labeled, 24 ÷ 2! = 12 identical"), "<p>A small version a computer list confirms. ✓</p>", ""),
})
PW["c8"] = T("c8", {
 "make": (letters("AACBBAC"), "<p>A seven-letter good word: no AB, BC or CA anywhere.</p>", "Check every neighbor pair."),
 "steps": (empty([str(i) for i in range(1, 8)]), "<p>One decision per letter, left to right.</p>", ""),
 "same": (table(["after", "allowed next"], [["A", "A or C"], ["B", "A or B"], ["C", "B or C"]]), "<p>First letter: 3. Every later letter: 2, though which 2 depends on the letter before.</p>", ""),
 "mult": (big("3 × 2⁶ = 192"), "<p><b>192</b>.</p>", ""),
 "twice": NO_TWINS("One letter per position."),
 "check": (stack(big("two-letter good words: 3 × 2 = 6"), row(*[letters(w) for w in ["AA", "AC", "BA", "BB", "CB", "CC"]], gap=".4rem")), "<p>✓</p>", ""),
})
PW["c9"] = T("c9", {
 "make": (big("dark blue square, dark green triangle, dark red circle"), "<p>One complementary set: shades all the same, colors all different, shapes all different.</p>", ""),
 "steps": (empty(["1st card", "2nd card", "3rd card"]), "<p>Draw the cards one at a time.</p>", ""),
 "same": (slots([("1st card", "", 27, "on"), ("2nd card", "any other", 26, "on"), ("3rd card", "forced", 1, "on")]), "<p>Two cards force the third, feature by feature: same + same → same; different + different → the one left.</p>", ""),
 "mult": (big("27 × 26 × 1 = 702"), "<p>702 ordered draws.</p>", ""),
 "twice": (big(YES + " each set can be drawn in 3! = 6 orders"), "<p>A set has no order.</p>", ""),
 "divide": (big("702 ÷ 6 = 117"), "<p><b>117</b>.</p>", ""),
 "check": (big("a computer check of all 2925 three-card sets finds 117"), "<p>✓</p>", ""),
})
PW["c10"] = T("c10", {
 "make": (big("captain Ada, vice Ben"), "<p>One choice of leaders.</p>", ""),
 "steps": (empty(["captain", "vice"]), "<p>Two decisions.</p>", ""),
 "same": (slots([("captain", "", 5, "on"), ("vice", "anyone else", 4, "on")]), "<p>5, then 4.</p>", ""),
 "mult": (stack(big("5 × 4 = 20"), pgrid(list("ABCDE"), 2, rowh="captain", colh="vice", plain=True)), "<p>Captain and vice: <b>20</b>.</p>", ""),
 "twice": (stack(big("captain + vice: " + NO + "   co-captains: " + YES), pgrid(list("ABCDE"), 3, twin_hl=(0, 1))), "<p>Different jobs: no twins. Co-captains: Ada-Ben = Ben-Ada, twins.</p>", ""),
 "divide": (big("co-captains: 20 ÷ 2 = 10"), "<p><b>10</b>.</p>", ""),
 "check": (big("pairs from 4 friends: 4 × 3 ÷ 2 = 6 (AB AC AD BC BD CD)"), "<p>✓</p>", ""),
})
