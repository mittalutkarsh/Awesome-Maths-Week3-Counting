"""Step/problem constructors shared by the practice and lesson data modules."""
PH_NUM = "whole number"
PH_EXPR = "number or expression"
PH_NUMS = "numbers separated by commas"
PH_CHOICE = "letter, or the option's word"

def step(q, type, ans, nudges, hint, reveal, success, *, errors=None, ph=None,
         options=None, forms=None, leak_ok=None, accept=None, reject=None):
    assert len(nudges) == 3, q
    return dict(q=q, type=type, ans=ans, nudges=nudges, hint=hint, reveal=reveal,
                success=success, errors={str(k): v for k, v in (errors or {}).items()},
                ph=ph or {"num": PH_NUM, "expr": PH_EXPR, "nums": PH_NUMS,
                          "choice": PH_CHOICE, "factor": "product of primes",
                          "text": "a short answer"}[type],
                options=options, forms=forms or [], leak_ok=leak_ok or [],
                accept=accept or [], reject=reject or [])

def problem(pid, num, section, title, text, steps, answer, check, worked,
            concepts=(), above=False, source=None, figure="", solfig=""):
    return dict(id=pid, num=num, section=section, title=title, text=text, figure=figure,
                steps=steps, answer=answer, check=check, worked=worked,
                concepts=list(concepts), above=above, source=source, solfig=solfig)

GRID5 = ('<div class="fig strip" aria-label="A row of five empty squares">'
         + '<span></span>' * 5 + '</div>')
