"""The pick grid: rows = first pick, columns = second pick.
Cell kinds: 'x' (same thing twice, not allowed), 'keep' (counted), 'twin' (the same group as a kept cell, written backwards),
'plain' (allowed and distinct: nothing to divide out)."""
from html import escape

def grid(rows, cols, cell, *, row_head="1st pick", col_head="2nd pick", compact=False, caption="", legend=True, gid="", tight=False):
    """cell(i, j) -> (kind, top, bottom, twin_key or None)"""
    cls = "pgrid compact" if compact else ("pgrid tight" if tight else "pgrid")
    n = len(cols)
    h = [f'<figure class="pfig"{f" id={chr(34)}{gid}{chr(34)}" if gid else ""}><div class="pscroll">'
         f'<div class="{cls}" style="--cols:{n}" role="table" aria-label="{escape(row_head)} by {escape(col_head)}">']
    h.append(f'<div class="ph corner" role="columnheader"><span>{escape(row_head)} ↓</span><span>{escape(col_head)} →</span></div>')
    for c in cols: h.append(f'<div class="ph" role="columnheader">{escape(c)}</div>')
    for i, r in enumerate(rows):
        h.append(f'<div class="ph rh" role="rowheader">{escape(r)}</div>')
        for j, _ in enumerate(cols):
            kind, top, bottom, tw = cell(i, j)
            attrs = f' data-k="{gid}{i}-{j}"' + (f' data-tw="{gid}{tw}"' if tw else "")
            label = {"x": "not allowed", "keep": "counted", "twin": "same group as its twin", "plain": "counted"}[kind]
            inner = "" if compact else (f"<b>{escape(top)}</b>" + (f"<i>{escape(bottom)}</i>" if bottom else ""))
            if kind == "x" and not compact: inner = "×"
            h.append(f'<div class="pc {kind}" role="cell"{attrs} aria-label="{escape(top or "")} {label}"'
                     f'{" tabindex=0" if tw else ""}>{inner}</div>')
    h.append("</div></div>")
    if legend:
        h.append('<div class="plegend"><span><i class="k keep"></i>counted</span>'
                 '<span><i class="k twin"></i>twin of a counted box (same group, written backwards)</span>'
                 '<span><i class="k x"></i>same one picked twice</span><span><i class="k plain"></i>counted, and has no twin</span></div>')
    if caption: h.append(f"<figcaption>{caption}</figcaption>")
    h.append("</figure>")
    return "".join(h)

def triangle(names, leftover=None, gid="", **kw):
    """Classic unordered-pair grid: upper triangle kept, lower triangle twins."""
    def cell(i, j):
        if i == j: return ("x", names[i] + names[j], "", None)
        if i < j:
            rest = "".join(x for k, x in enumerate(names) if k not in (i, j)) if leftover else ""
            return ("keep", names[i] + names[j], rest, f"{j}-{i}")
        return ("twin", names[i] + names[j], "", f"{j}-{i}")
    return grid(names, names, cell, gid=gid, **kw)

# Problem 25 (unit test): Lizzie, Grogg, Alex, Winnie, Ralph, Fiona -> one group of 2, one of 4
G_SPLIT = triangle(list("LGAWRF"), leftover=True, gid="g25-",
    caption="36 boxes. The 6 on the diagonal pick the same student twice, leaving 30. Every teal box has a grey twin across the "
            "diagonal (LG and GL are the same group), so 30 ÷ 2 = 15. The bottom line of each teal box is the group of 4 it leaves behind.")

# Lesson concept: 4 people
G_FOUR = triangle(list("ABCD"), gid="g4-",
    caption="16 boxes, 4 crossed out, 12 left. They come in 6 twin pairs, so there are 6 pairs of people.")

# Middle School Eight: home team x away team
G_GAMES = grid([str(k) for k in range(1, 9)], [str(k) for k in range(1, 9)],
    lambda i, j: ("x", "", "", None) if i == j else ("plain", f"{i+1}v{j+1}", "", None),
    row_head="home", col_head="away", gid="g12-",
    caption="64 boxes, 8 crossed out (a team can't play itself): 56. No twins this time: team 1 at home to team 2 and team 2 at "
            "home to team 1 are two different games. Nothing to divide out.")

# 12 handshakes, compact
G_HANDS = triangle([str(k) for k in range(1, 13)], gid="g23-", compact=True,
    caption="12 × 12 = 144 boxes. The diagonal (12) is someone shaking their own hand: 132 left. Each handshake appears twice, "
            "once from each person's side: 132 ÷ 2 = 66.")

# Red card x black card, compact 26 x 26
G_RB = grid([""] * 26, [""] * 26, lambda i, j: ("plain", "", "", None), row_head="red card", col_head="black card",
    compact=True, gid="g28-",
    caption="26 red rows, 26 black columns: 676 boxes. No diagonal (a card can't be red and black) and no twins (the red card can "
            "only ever be in a row). Nothing to divide: 676.")

# Spade x face card, 13 x 12, overlap block of J, Q, K of spades
RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]
SPADES = [r + "♠" for r in RANKS]
FACES = [r + s for s in "♣♦♥♠" for r in ("J", "Q", "K")]
def _sf(i, j):
    a, b = SPADES[i], FACES[j]
    if a == b: return ("x", a, "", None)
    if a in FACES and b in SPADES:           # both cards are spade face cards
        i2, j2 = FACES.index(a), SPADES.index(b)
        return ("keep" if i < SPADES.index(b) else "twin", a + b, "", f"{SPADES.index(b)}-{FACES.index(a)}")
    return ("plain", "", "", None)
G_SF = grid(SPADES, FACES, _sf, row_head="spade", col_head="face card", gid="g29-", tight=True,
    caption="13 spades × 12 face cards = 156 boxes. Three are the same card twice (J♠ with J♠, and so on): 153. The only twins are "
            "inside the J♠, Q♠, K♠ corner: J♠ as the spade with Q♠ as the face card is the same hand as Q♠ as the spade with J♠ "
            "as the face card. Three twin pairs, so remove 3 more: 150.")
