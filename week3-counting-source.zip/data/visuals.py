"""Visual building blocks for step-by-step explanations.
Every story is a list of frames; each frame = (picture HTML, what-to-say HTML, ask-him prompt or '')."""
from html import escape
import itertools

_SID = itertools.count(1)

# ---------------- the stepper ----------------
def story(title, frames, sid=None, kind="concept"):
    sid = sid or f"st{next(_SID)}"
    n = len(frames)
    secs = []
    for i, (vis, say, ask) in enumerate(frames):
        secs.append(
            f'<section class="frame{" on" if i == 0 else ""}" data-i="{i}" aria-label="Step {i+1} of {n}">'
            f'<div class="fstep">Step {i+1} of {n}</div><div class="vis">{vis}</div><div class="say">{say}</div>'
            + (f'<div class="ask"><b>Ask him:</b> {ask}</div>' if ask else "") + "</section>")
    dots = "".join(f'<button type="button" class="sdot{" on" if i == 0 else ""}" data-go="{i}" aria-label="Go to step {i+1}"></button>' for i in range(n))
    return (f'<div class="story {kind}" id="{sid}" data-n="{n}" data-cur="0"><div class="shead">{title}</div>'
            f'<div class="frames">{"".join(secs)}</div>'
            f'<div class="snav"><button type="button" class="sbtn" data-prev disabled aria-label="Previous step">← Back</button>'
            f'<span class="sdots">{dots}</span>'
            f'<button type="button" class="sbtn primary" data-next aria-label="Next step">Next step →</button>'
            f'<button type="button" class="sbtn ghost" data-all aria-pressed="false">Show all steps</button></div></div>')

# ---------------- small pieces ----------------
def chip(t, k=""):
    return f'<span class="chip {k}">{escape(str(t))}</span>'

def chips(items, k="", used=(), banned=(), pick=()):
    out = []
    for x in items:
        kk = k
        if x in banned: kk += " banned"
        elif x in used: kk += " used"
        elif x in pick: kk += " pick"
        out.append(chip(x, kk.strip()))
    return '<span class="chips">' + "".join(out) + "</span>"

def slot(label, inner="", count="", state=""):
    return (f'<div class="slot {state}"><div class="sl">{label}</div><div class="sb">{inner}</div>'
            f'<div class="sc">{count if count != "" else "?"}</div></div>')

def slots(items, op="×", result=None, note=""):
    """items: list of (label, inner_html, count, state)"""
    parts = []
    for i, it in enumerate(items):
        if i: parts.append(f'<div class="op">{op}</div>')
        parts.append(slot(*it))
    if result is not None:
        parts.append('<div class="op">=</div>')
        parts.append(f'<div class="result">{result}</div>')
    return f'<div class="slots">{"".join(parts)}</div>' + (f'<div class="vnote">{note}</div>' if note else "")

def letters(word, colors=None, subs=None):
    """word as tiles; colors/subs per position for labelled copies"""
    out = []
    for i, ch in enumerate(word):
        c = (colors or {}).get(i, "")
        s = (subs or {}).get(i, "")
        out.append(f'<span class="tile {c}">{escape(ch)}{f"<sub>{s}</sub>" if s else ""}</span>')
    return '<span class="word">' + "".join(out) + "</span>"

def bundle(inner_items, arrow_to=None, label=""):
    inner = "".join(f'<div class="bi">{x}</div>' for x in inner_items)
    tail = f'<div class="barrow">→</div><div class="bres">{arrow_to}</div>' if arrow_to else ""
    return f'<div class="bundle-row"><div class="bundle">{inner}</div>{tail}</div>' + (f'<div class="blabel">{label}</div>' if label else "")

def table(head, rows, hl_row=None):
    th = "".join(f"<th>{h}</th>" for h in head)
    tr = "".join("<tr" + (' class="hl"' if i == hl_row else "") + ">" + "".join(f"<td>{c}</td>" for c in r) + "</tr>" for i, r in enumerate(rows))
    return f'<table class="vtable"><thead><tr>{th}</tr></thead><tbody>{tr}</tbody></table>'

def big(t, k=""):
    return f'<div class="bigline {k}">{t}</div>'

def row(*items, gap="1rem"):
    return f'<div class="vrow" style="gap:{gap}">' + "".join(items) + "</div>"

def stack(*items):
    return '<div class="vstack">' + "".join(items) + "</div>"

def strike(t):
    return f'<span class="bogus">{t}</span>'

# ---------------- trees (SVG) ----------------
def tree(levels_tree, depth=99, emph=None, width_per_leaf=40, level_h=62, label_root="start", note_counts=False):
    """levels_tree: list of (label, children) nodes under an invisible root. Leaves get equal width.
    depth: how many levels to draw. emph: set of path tuples to highlight. note_counts: write branch count by each parent."""
    emph = emph or set()
    nodes, edges = [], []
    def leaves(n, d):
        lab, ch = n
        if not ch or d >= depth: return 1
        return sum(leaves(c, d + 1) for c in ch)
    total = sum(leaves(n, 1) for n in levels_tree)
    W = max(260, total * width_per_leaf + 20)
    maxd = 0
    def place(n, d, x0, path, px, py):
        nonlocal maxd
        lab, ch = n
        w = leaves(n, d) * width_per_leaf
        x = x0 + w / 2; y = 30 + d * level_h
        maxd = max(maxd, d)
        on = path in emph
        edges.append((px, py, x, y, on))
        nodes.append((x, y, lab, on, len(ch) if (ch and d < depth) else 0))
        if ch and d < depth:
            cx = x0
            for i, c in enumerate(ch):
                cw = leaves(c, d + 1) * width_per_leaf
                place(c, d + 1, cx, path + (i,), x, y)
                cx += cw
    rx, ry = W / 2, 22
    cx = 10
    for i, n in enumerate(levels_tree):
        w = leaves(n, 1) * width_per_leaf
        place(n, 1, cx, (i,), rx, ry); cx += w
    H = 30 + maxd * level_h + 30
    s = [f'<svg class="tree" viewBox="0 0 {W:.0f} {H:.0f}" width="{W:.0f}" role="img" aria-label="tree diagram">']
    for (x1, y1, x2, y2, on) in edges:
        s.append(f'<line x1="{x1:.1f}" y1="{y1+8:.1f}" x2="{x2:.1f}" y2="{y2-12:.1f}" class="te{" on" if on else ""}"/>')
    s.append(f'<circle cx="{rx:.1f}" cy="{ry:.1f}" r="5" class="troot"/><text x="{rx+10:.1f}" y="{ry+4:.1f}" class="tlab small">{escape(label_root)}</text>')
    for (x, y, lab, on, k) in nodes:
        nw = min(34, width_per_leaf - 4)
        s.append(f'<g class="tn{" on" if on else ""}"><rect x="{x-nw/2:.1f}" y="{y-12:.1f}" width="{nw}" height="22" rx="4"/>'
                 f'<text x="{x:.1f}" y="{y+4:.1f}" text-anchor="middle">{escape(lab)}</text></g>')
    s.append("</svg>")
    return '<div class="treewrap">' + "".join(s) + "</div>"

def full_tree(levels):
    """levels: list of option lists, every node gets the same children"""
    def build(i):
        if i >= len(levels): return []
        return [(o, build(i + 1)) for o in levels[i]]
    return build(0)

# ---------------- dots and lines (handshakes) ----------------
def dots(names, edges=(), new_edges=(), r=78):
    import math
    n = len(names); W = 2 * r + 80; cx = cy = W / 2
    pts = [(cx + r * math.sin(2 * math.pi * i / n), cy - r * math.cos(2 * math.pi * i / n)) for i in range(n)]
    s = [f'<svg class="dots" viewBox="0 0 {W:.0f} {W:.0f}" width="{W:.0f}" role="img" aria-label="people as dots, handshakes as lines">']
    for (a, b) in edges:
        cls = "de new" if (a, b) in new_edges else "de"
        s.append(f'<line x1="{pts[a][0]:.1f}" y1="{pts[a][1]:.1f}" x2="{pts[b][0]:.1f}" y2="{pts[b][1]:.1f}" class="{cls}"/>')
    for i, (x, y) in enumerate(pts):
        s.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="15" class="dn"/><text x="{x:.1f}" y="{y+5:.1f}" text-anchor="middle" class="dt">{escape(names[i])}</text>')
    s.append("</svg>")
    return "".join(s)

# ---------------- flowchart for the counting plan ----------------
PLAN_NODES = [
    ("make", "What am I making?"),
    ("steps", "Build it one decision at a time"),
    ("same", "Same number of options after every earlier choice?"),
    ("mult", "Multiply the option counts"),
    ("twice", "Did I build any thing more than once?"),
    ("divide", "Divide by how many times"),
    ("check", "Check with a small case you can list"),
]
def plan_flow(active):
    out = ['<div class="flow">']
    for i, (k, t) in enumerate(PLAN_NODES):
        cls = "fn on" if k == active else ("fn past" if [x for x, _ in PLAN_NODES].index(active) > i else "fn")
        out.append(f'<div class="{cls}">{t}</div>')
        if i < len(PLAN_NODES) - 1: out.append('<div class="fa">↓</div>')
    out.append("</div>")
    return "".join(out)

# ---------------- pick grid with progressive states ----------------
def pgrid(names, stage, twin_hl=None, rowh="1st pick", colh="2nd pick", gid="", plain=False, sep=""):
    """stage 0: empty labelled grid; 1: every box filled; 2: diagonal crossed; 3: twins marked (lower triangle grey);
    plain=True: no twins (every off-diagonal box counts)"""
    n = len(names)
    h = [f'<div class="pscroll"><div class="pgrid" style="--cols:{n}">',
         f'<div class="ph corner"><span>{escape(rowh)} ↓</span><span>{escape(colh)} →</span></div>']
    h += [f'<div class="ph">{escape(c)}</div>' for c in names]
    for i, r in enumerate(names):
        h.append(f'<div class="ph rh">{escape(r)}</div>')
        for j, c in enumerate(names):
            lab = r + sep + c
            if stage == 0: kind, txt = "empty", ""
            elif stage == 1: kind, txt = "plain", lab
            elif i == j: kind, txt = "x", "×"
            elif stage == 2 or plain: kind, txt = "plain", lab
            else: kind, txt = ("keep" if i < j else "twin"), lab
            hl = " hl" if (twin_hl and stage >= 3 and i != j and (i, j) in (tuple(twin_hl), tuple(twin_hl)[::-1])) else ""
            h.append(f'<div class="pc {kind}{hl}"><b>{escape(txt)}</b></div>')
    h.append("</div></div>")
    return "".join(h)

# ---------------- plan-guided frames: mini flowchart on the left, this step's picture on the right ----------------
PLAN_KEYS = [k for k, _ in PLAN_NODES]
PLAN_SHORT = {"make": "What am I making?", "steps": "One decision at a time", "same": "Same number of options every time?",
              "mult": "Multiply", "twice": "Built anything twice?", "divide": "Divide (or take away) the extras", "check": "Check a small case"}
def plan_mini(active, skip=()):
    out = ['<div class="pmini" aria-label="counting plan">']
    ai = PLAN_KEYS.index(active)
    for i, k in enumerate(PLAN_KEYS):
        cls = "on" if k == active else ("skip" if k in skip else ("past" if i < ai else ""))
        lab = PLAN_SHORT[k] + (' <i>not needed here</i>' if k in skip else "")
        out.append(f'<div class="pm {cls}"><span class="pmn">{i+1}</span>{lab}</div>')
    out.append("</div>")
    return "".join(out)

def pframe(node, vis, say, ask="", skip=(), tag=None):
    tag = tag or PLAN_SHORT[node]
    body = (f'<div class="pf"><div class="pf-flow">{plan_mini(node, skip)}</div>'
            f'<div class="pf-main"><div class="pf-tag">Step {PLAN_KEYS.index(node)+1}: {tag}</div>{vis}</div></div>')
    return (body, say, ask)

def plan_story(title, parts, sid, kind="worked"):
    """parts: dict node -> (vis, say, ask). Nodes left out are shown as 'not needed here'."""
    skip = [k for k in PLAN_KEYS if k not in parts]
    frames = [pframe(k, *parts[k], skip=skip) for k in PLAN_KEYS if k in parts]
    return story(title, frames, sid=sid, kind=kind)
