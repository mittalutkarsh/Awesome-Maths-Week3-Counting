"""Visual worked answers, shown only after a problem is finished or the worked answer is requested."""
from .visuals import (story, chip, chips, slots, letters, bundle, table, big, row, stack, strike, tree, full_tree, dots, pgrid)
from . import grids as G

D10 = [str(d) for d in range(10)]

def walk(spec, result, op="×", lead=None):
    """spec: list of (label, inner_html, count, why). One frame per slot, filled cumulatively, then the product."""
    frames = []
    if lead: frames.append(lead)
    for k in range(len(spec)):
        items = [(l, inner if i <= k else "", c if i <= k else "", "on" if i == k else ("done" if i < k else "")) for i, (l, inner, c, _) in enumerate(spec)]
        frames.append((slots(items), f"<p>{spec[k][3]}</p>", ""))
    items = [(l, inner, c, "done") for (l, inner, c, _) in spec]
    frames.append((slots(items, op=op, result=result), f"<p>Every choice leaves the same number of options for the next slot, so multiply: <b>{result}</b>.</p>", "Why is it fine to multiply here?"))
    return frames

def W(pid, frames):
    return story("Worked answer, step by step", frames, sid=f"w-{pid}", kind="worked")

def squares(colors):
    m = {"Y": "y", "G": "g", "B": "b", "?": "q"}
    return '<div class="beads sq">' + "".join(f'<span class="bead {m[c]}"></span>' for c in colors) + "</div>"

WS = {}

WS["q1"] = W("q1", walk([
 ("hundreds", chips(D10, banned=["0"]), 9, "The first digit can't be 0 (024 is just 24), so it has 9 options: 1 to 9."),
 ("tens", chips(D10), 10, "The tens digit can be any digit, zero included: 10 options."),
 ("ones", chips(D10), 10, "The ones digit is the same: 10 options.")], "900") +
 [(big("100, 101, …, 999 → 999 − 100 + 1 = 900"), "<p>Check with the range: the three-digit numbers go from 100 to 999. That's 999 − 100 + 1 = 900. Same answer.</p>", "Why the + 1?")])

EV = ["0", "2", "4", "6", "8"]
WS["q2"] = W("q2", walk([
 ("hundreds", chips(EV, banned=["0"]), 4, "Only even digits are allowed. Zero is even, but it can't lead. That leaves 2, 4, 6, 8: 4 options."),
 ("tens", chips(EV), 5, "The tens digit can be any even digit, and zero is fine here: 5 options."),
 ("ones", chips(EV), 5, "Same for the ones digit: 5 options.")], "100"))

WS["q3"] = W("q3", [
 (stack(squares("?????"), chips(["Yellow", "Green", "Blue"])), "<p>Five squares, three colors, <b>exactly one yellow</b>. The yellow rule is the hard part.</p>", "What's the hardest rule to keep track of?"),
 (stack(squares("Y????"), squares("G????")), "<p>Going left to right is a trap: after a yellow square the next one has 2 colors, after a green one it has 3. Unequal branches can't be multiplied.</p>", ""),
 ("".join(squares("".join("Y" if i == k else "?" for i in range(5))) for k in range(5)), "<p>So settle the hard rule first: <b>which square is yellow?</b> 5 places.</p>", ""),
 (slots([("which is yellow", "", 5, "done"), ("other", chips(["G", "B"]), 2, "on"), ("other", chips(["G", "B"]), 2, "on"), ("other", chips(["G", "B"]), 2, "on"), ("other", chips(["G", "B"]), 2, "on")], result="80"),
  "<p>Every other square is now green or blue: 2 options each, no matter where the yellow went. 5 × 2 × 2 × 2 × 2 = <b>80</b>.</p>", "Why can't the other squares be yellow?"),
])

WS["q4"] = W("q4", walk([("1st", chips(list("AMC")), 3, "Any of the 3 letters can go first."),
 ("2nd", "", 2, "One letter is used, so 2 are left."), ("3rd", "", 1, "Only 1 letter is left for the last spot.")], "6") +
 [(row(*[letters(w) for w in ["AMC", "ACM", "MAC", "MCA", "CAM", "CMA"]], gap=".4rem"), "<p>Check by listing, holding the first letter fixed: two words start with A, two with M, two with C.</p>", "")])

WS["q5"] = W("q5", walk([("1st", chips(list("MATH")), 4, "Any of the 4 letters first."), ("2nd", "", 3, "3 letters left."),
 ("3rd", "", 2, "2 left."), ("4th", "", 1, "1 left.")], "24") +
 [(big("4! = 4 × 3! = 4 × 6"), "<p>Another way to see it: put any of the 4 letters first, and the other 3 letters can follow in 3! = 6 orders. 4 × 6 = 24.</p>", "")])

WS["q6"] = W("q6", walk([
 ("hundreds", chips(D10, banned=["0"]), 9, "First digit: 1 to 9, so 9 options."),
 ("tens", chips(D10, used=["3"]), 9, "Second digit: zero is allowed again, but the first digit (say 3) is used up. 10 − 1 = 9."),
 ("ones", chips(D10, used=["3", "0"]), 8, "Third digit: two digits are used up (say 3 and 0). 10 − 2 = 8.")], "648"))

WS["q7"] = W("q7", [
 (stack(letters("HELLO", {2: "blue", 3: "red"}, {2: "1", 3: "2"})), "<p>Paint the two L's different colors, L₁ and L₂. Now all five letters are different: 5! = 120 arrangements.</p>", ""),
 (bundle([letters("HELLO", {2: "blue", 3: "red"}, {2: "1", 3: "2"}), letters("HELLO", {2: "red", 3: "blue"}, {2: "2", 3: "1"})], letters("HELLO")),
  "<p>Wash the paint off: HEL₁L₂O and HEL₂L₁O both become HELLO. Every real word was counted <b>twice</b>, once for each order of the two L's (2! = 2).</p>", "Is every word counted twice, or just this one?"),
 (slots([("all different", "", "5!", "done"), ("orders of the L's", "", "2!", "on")], op="÷", result="60"), "<p>120 ÷ 2 = <b>60</b>.</p>", ""),
])

WS["q8"] = W("q8", [
 (table(["letter", "G", "R", "E", "N"], [["how many", "1", "2", "3", "1"]]), "<p>Tally first: E three times, R twice, G and N once. 7 letters.</p>", ""),
 (letters("GREENER", {1: "blue", 6: "red", 2: "blue", 3: "red", 5: "green"}, {1: "1", 6: "2", 2: "1", 3: "2", 5: "3"}),
  "<p>Paint the repeats so all 7 letters are different: 7! = 5040 arrangements.</p>", ""),
 (big("E's: 3! = 6 orders  ×  R's: 2! = 2 orders  =  12 painted copies"),
  "<p>Each real word now appears once for every order of the painted E's <b>times</b> every order of the painted R's: 6 × 2 = 12 copies. Multiply, because every E-order goes with every R-order.</p>",
  "Why 6 × 2 and not 6 + 2?"),
 (slots([("all different", "", "7!", "done"), ("copies of each word", "", "3! × 2!", "on")], op="÷", result="420"), "<p>5040 ÷ 12 = <b>420</b>.</p>", ""),
])

WS["q9"] = W("q9", [
 (table(["letter", "M", "I", "S", "P"], [["how many", "1", "4", "4", "2"]]), "<p>Tally: I four times, S four times, P twice, M once. 11 letters.</p>", ""),
 (big("11!  arrangements if every letter were painted"), "<p>Paint every repeated letter so all 11 are different: 11! arrangements.</p>", ""),
 (big("copies of each word = 4! × 4! × 2!"), "<p>Each real word appears once for every order of the I's, times every order of the S's, times every order of the P's.</p>", ""),
 (big("11! ÷ (4! × 4! × 2!) = 34,650"), "<p>Divide. The problem asked for factorial form, so 11!/(4!·4!·2!) is a perfect final answer.</p>", ""),
])

WS["q10"] = W("q10", [
 ('<div class="chairs"><div class="chair next">boy</div><div class="chair">girl</div><div class="chair">girl</div><div class="chair">girl</div><div class="chair next">boy</div></div>',
  "<p>The ends are the restricted spots: only boys. Do them first.</p>", ""),
 (slots([("left end", chips(["B1", "B2"]), 2, "on"), ("right end", "the other boy", 1, "on")]), "<p>Left end: either boy (2). Right end: the other boy (1).</p>", ""),
 (slots([("left end", "", 2, "done"), ("right end", "", 1, "done"), ("middle 1", "", 3, "on"), ("middle 2", "", 2, "on"), ("middle 3", "", 1, "on")], result="12"),
  "<p>The girls fill the middle in any order: 3 × 2 × 1. Total 2 × 1 × 3 × 2 × 1 = <b>12</b>.</p>", ""),
])

WS["q11"] = W("q11", walk([("1st", chips(D10, banned=["0"]), 9, "First digit: not zero, 9 options."), ("2nd", "", 9, "Zero is back, one digit used: 9."),
 ("3rd", "", 8, "Two digits used: 8."), ("4th", "", 7, "Three digits used: 7.")], "4536"))

WS["q12"] = W("q12", [
 (pgrid([str(k) for k in range(1, 9)], 2, rowh="home", colh="away", plain=True, sep="v"),
  "<p>Every conference game has a home team and an away team. Make a grid: home down the side, away across the top. A team can't play itself, so the diagonal is crossed out.</p>", ""),
 (big("8 × 8 − 8 = 56 conference games"), "<p>Each remaining box is a different game (team 1 at home to 2 is not the same as 2 at home to 1). No twins: 56 games.</p>", "Why don't we divide by 2 here?"),
 (big(strike("8 teams × 14 games = 112")), "<p>The trap: each team plays 14 conference games, but 8 × 14 counts every game twice, once for each team in it. 112 ÷ 2 = 56, the same as the grid.</p>", ""),
 (big("8 × 4 = 32 non-conference games"), "<p>A non-conference game has only one Middle School Eight team in it, so counting team by team counts it once.</p>", ""),
 (big("56 + 32 = 88"), "<p>Every game is one kind or the other: 88 games.</p>", ""),
])

def kidrow(k):
    return slots([(f"kid {i+1}", "", 3 if i == 0 else 2, "on" if i < k else "") for i in range(10)])
WS["q13"] = W("q13", [
 (table(["this kid gets", "next kid can't get", "next kid can get"], [["1", "3", "1 or 2"], ["2", "2", "1 or 3"], ["3", "1", "2 or 3"]]),
  "<p>Whatever one kid gets, exactly one amount is banned for the next kid (the one that would make 4).</p>", "Check each row: does it always leave 2?"),
 (kidrow(1), "<p>Kid 1 has 3 options.</p>", ""),
 (kidrow(10), "<p>Every later kid has 2 options: different amounts, but always 2. Same idea as the good-words problem.</p>", ""),
 (big("3 × 2⁹ = 1536"), "<p>One 3 and nine 2's: 3 × 2⁹ = <b>1536</b>.</p>", "Why nine 2's and not ten?"),
])

par = [[str(a)] + ["✓" if (a + c) % 2 == 0 else "" for c in range(10)] for a in range(1, 10)]
WS["q14"] = W("q14", [
 (big("3 _ 7  →  middle = (3 + 7) ÷ 2 = 5  →  357"), "<p>Once the first and last digits are chosen, the middle digit is <b>forced</b>: it has to be their average.</p>", ""),
 (big("3 _ 8  →  (3 + 8) ÷ 2 = 5.5  →  no number"), "<p>But sometimes the average isn't a whole number, and then there's no number at all.</p>", "When is the average of two digits a whole number?"),
 (table(["first ↓ last →"] + [str(c) for c in range(10)], par),
  "<p>Make a table: first digit down the side, last digit across. Tick a box when the average is whole, which happens when both are odd or both are even.</p>", ""),
 (big("25 ticks in odd rows + 20 ticks in even rows = 45"), "<p>Count the ticks: 5 odd first digits × 5 odd last digits, plus 4 even first digits (no 0) × 5 even last digits. <b>45</b>.</p>", ""),
])

def plate(k):
    return '<div class="plate">' + "".join(f'<span class="{"L" if i in (k, k+1) else "D"}">{"L" if i in (k, k+1) else "#"}</span>' for i in range(6)) + "</div>"
WS["q15"] = W("q15", [
 ("".join(plate(k) for k in range(5)), "<p>Glue the two letters into one block. The block can start at character 1, 2, 3, 4 or 5: <b>5</b> places.</p>", "Why can't it start at character 6?"),
 (slots([("block place", "", 5, "done"), ("letter", "A–Z", 26, "on"), ("letter", "A–Z", 26, "on")]), "<p>Each letter can be any of 26, repeats allowed.</p>", ""),
 (slots([("block place", "", 5, "done"), ("letter", "", 26, "done"), ("letter", "", 26, "done"), ("digit", "0–9", 10, "on"), ("digit", "0–9", 10, "on"), ("digit", "0–9", 10, "on"), ("digit", "0–9", 10, "on")],
        result="33,800,000"), "<p>Each digit spot can be any of 10 (a plate isn't a number, so 0 is fine first). 5 × 26² × 10⁴ = <b>33,800,000</b>.</p>", ""),
])

WS["q16"] = W("q16", [
 (big("dinners = appetizers × mains × desserts = 2m × m × 3"), "<p>With m main courses there are 2m appetizers and 3 desserts.</p>", ""),
 (table(["mains m", "appetizers", "dinners", "enough for 365?"], [["5", "10", "150", "no"], ["6", "12", "216", "no"], ["7", "14", "294", "no"], ["8", "16", "384", "yes"]], hl_row=3),
  "<p>Try values in order. 2003 isn't a leap year, so we need 365 dinners. 7 mains fall short; 8 is the first that works: <b>8</b>.</p>", "Why check 7 as well as 8?"),
])

def colsplit(d):
    return " ".join(f"{a}+{d-a}" for a in range(d + 1))
WS["q17"] = W("q17", [
 (big("999 + 493: the ones column is 9 + 3 = 12, so it carries"), "<p>A pair is <b>not simple</b> if some column adds to 10 or more. So in a simple pair, each column of m + n must add to exactly the digit of 1492 in that column.</p>", ""),
 (table(["column", "digit of 1492", "ways to split", "count"], [["thousands", "1", colsplit(1), "2"], ["hundreds", "4", colsplit(4), "5"], ["tens", "9", "0+9 … 9+0", "10"], ["ones", "2", colsplit(2), "3"]]),
  "<p>Each column splits on its own. A digit d splits into d + 1 ordered pairs.</p>", "Why is 1+0 different from 0+1 here?"),
 (slots([("thousands", "", 2, "done"), ("hundreds", "", 5, "done"), ("tens", "", 10, "done"), ("ones", "", 3, "done")], result="300"), "<p>The columns are independent decisions: 2 × 5 × 10 × 3 = <b>300</b>.</p>", ""),
])

def cboard(case):
    cells = []
    for i in range(5):
        for j in range(5):
            dark = (i + j) % 2 == 0
            if case == 0: txt = ""
            elif (case == 1 and dark) or (case == 2 and not dark): txt = "1"
            else: txt = "0/2"
            cells.append(f'<span class="{"dk" if dark else "lt"}">{txt}</span>')
    return '<div class="cboard">' + "".join(cells) + "</div>"
WS["q18"] = W("q18", [
 (table(["cell holds", "neighbors must hold"], [["0", "1"], ["1", "0 or 2"], ["2", "1"]]), "<p>Neighbors differ by exactly 1. So a 0 or a 2 is always surrounded by 1s, and a 1 is surrounded by 0s and 2s.</p>", ""),
 (cboard(0), "<p>Color the grid like a checkerboard: 13 dark cells (corners dark) and 12 light. Neighbors always have opposite colors. If one cell is 1, its neighbors are 0s or 2s, <i>their</i> neighbors are 1s, and so on across the grid. So all the 1s sit on one color, and the other color holds only 0s and 2s.</p>", "Why do neighbors always have different colors?"),
 (cboard(1), "<p>Case A: every dark cell is 1. Then each of the 12 light cells is 0 or 2, freely: 2¹² = 4096.</p>", ""),
 (cboard(2), "<p>Case B: every light cell is 1. Then each of the 13 dark cells is 0 or 2: 2¹³ = 8192.</p>", ""),
 (big("4096 + 8192 = 12,288"), "<p>The two cases can't overlap, so add: <b>12,288</b>.</p>", "Why add the cases instead of multiplying?"),
])

WS["q19"] = W("q19", [
 (big("{1, 3, 8} → 138 only"), "<p>Once you know <b>which</b> digits are used, there's only one increasing order. So we're really counting groups of digits.</p>", ""),
 (slots([(str(d), chips(["in", "out"]), 2, "on") for d in range(1, 10)], result="512"), "<p>Each digit 1 to 9 is either in or out: 2 options each, 2⁹ = 512. (0 can't be used: it would have to lead.)</p>", ""),
 (big("512 − 1 = 511"), "<p>One of those choices is 'all out', which makes no number. Remove it: <b>511</b>.</p>", ""),
])

# ---------- challenge ----------
WS["u4"] = W("u4", [
 (stack(big("7 in the tens place: 70, 71, …, 79 → 10"), big("7 in the ones place: 17, 27, …, 97 → 9")), "<p>Make two lists.</p>", ""),
 (big("77 is on both lists!"), "<p>77 got counted twice. Take it away once: 10 + 9 − 1 = <b>18</b>.</p>", "Which number is on both lists?"),
 (slots([("tens: not 0, not 7", "", 8, "on"), ("ones: not 7", "", 9, "on")], result="72"), "<p>Check another way: count the numbers with <b>no</b> 7 and subtract. 8 × 9 = 72 have no 7, and 90 − 72 = 18.</p>", ""),
])
WS["u5"] = W("u5", walk([("first", chips(D10, banned=["0"]), 9, "A palindrome ABA: the first digit can't be 0, so 9 options."),
 ("middle", chips(D10), 10, "The middle digit is free: 10 options."), ("last", "must equal the first", 1, "The last digit is forced to match the first: only 1 option.")], "90"))
WS["u15"] = W("u15", walk([("first", chips(list("01234"), banned=["0"]), 4, "First digit: 1, 2, 3 or 4."),
 ("2nd", "", 4, "Now 0 is allowed, and one digit is used: 4 left."), ("3rd", "", 3, "3 left."), ("4th", "", 2, "2 left."), ("5th", "", 1, "1 left.")], "96") +
 [(big("5! − 4! = 120 − 24 = 96"), "<p>Check: all 120 orders, minus the 24 that start with 0.</p>", "")])
WS["u16"] = W("u16", [
 ('<div class="chairs"><div class="chair full">short</div><div class="chair next"></div><div class="chair next"></div><div class="chair next"></div><div class="chair next"></div><div class="chair full">tall</div></div>',
  "<p>The shortest and tallest have no choice. Only the 4 middle spots are free.</p>", ""),
 (slots([("spot 2", "", 4, "on"), ("spot 3", "", 3, "on"), ("spot 4", "", 2, "on"), ("spot 5", "", 1, "on")], result="24"), "<p>4 × 3 × 2 × 1 = <b>24</b>.</p>", ""),
])
WS["u17"] = W("u17", [
 ('<div class="books"><span class="bk blk">V1 V2</span><span class="bk">P</span><span class="bk">Q</span><span class="bk">R</span></div>', "<p>Glue the two atlas volumes into one block. Now there are 4 things to arrange: the block and 3 books.</p>", ""),
 (big("4! = 24 orders of the 4 things"), "<p>4 × 3 × 2 × 1 = 24.</p>", ""),
 (big("inside the block: V1 V2 or V2 V1 → 2"), "<p>Inside the block the volumes can be in 2 orders.</p>", ""),
 (big("24 × 2 = 48"), "<p><b>48</b>.</p>", "What answer would you get if you forgot the order inside the block?"),
])
WS["u20"] = W("u20", [
 (big("9! = 9 × 8 × <u>7 × 6 × 5 × 4 × 3 × 2 × 1</u> = 9 × 8 × 7!"), "<p>Write 9! out: the underlined tail is exactly 7!.</p>", ""),
 (big("9! ÷ 7! = 9 × 8 = 72"), "<p>The 7! cancels. Only the two extra factors survive: <b>72</b>.</p>", ""),
])
WS["u23"] = W("u23", [
 (big("each person shakes 11 hands → 12 × 11 = 132"), "<p>Count from each person's side: 12 people × 11 handshakes each.</p>", ""),
 (G.G_HANDS, "<p>As a grid: 144 boxes, the diagonal crossed out, and every handshake appears twice (AB and BA).</p>", "Is AB the same handshake as BA?"),
 (big("132 ÷ 2 = 66"), "<p>Divide out the twins: <b>66</b>.</p>", ""),
])
twelve = [str(i) for i in range(1, 13)]
WS["u24"] = W("u24", [
 (dots(twelve, [(0, k) for k in range(2, 11)], [(0, k) for k in range(2, 11)], r=110), "<p>From one corner, diagonals go everywhere except itself and its two neighbors: 12 − 3 = 9.</p>", ""),
 (big("12 × 9 = 108 → each diagonal counted from both ends → 108 ÷ 2 = 54"), "<p>Every corner has 9, but each diagonal has two ends, so it was counted twice: <b>54</b>.</p>", "Why twice?"),
])
WS["u25"] = W("u25", [
 (pgrid(list("LGAWRF"), 1), "<p>Pick the group of 2 one student at a time. Grid: 6 × 6 = 36 boxes.</p>", "How many boxes?"),
 (pgrid(list("LGAWRF"), 2), "<p>Cross out the diagonal (same student twice): 30 left.</p>", ""),
 (pgrid(list("LGAWRF"), 3, twin_hl=(0, 1)), "<p>LG and GL are the same group. Every box has a twin: 30 ÷ 2 = <b>15</b>.</p>", "Are LG and GL different groups?"),
 (G.G_SPLIT, "<p>The group of 4 costs nothing: it's just whoever is left (the bottom line of each box).</p>", ""),
])
WS["u26"] = W("u26", [
 (slots([("1st pick", "", 10, "on"), ("2nd pick", "", 9, "on"), ("3rd pick", "", 8, "on")], result="720"), "<p>Pick the players in order: 720.</p>", ""),
 (bundle([letters(w) for w in ["ABC", "ACB", "BAC", "BCA", "CAB", "CBA"]], "one trio"), "<p>But one trio, say A, B, C, appears in 3! = 6 orders.</p>", ""),
 (big("720 ÷ 6 = 120"), "<p><b>120</b> trios.</p>", ""),
])
WS["u28"] = W("u28", [
 (slots([("red card", "", 26, "on"), ("black card", "", 26, "on")], result="676"), "<p>Choose the red card (26) and the black card (26).</p>", ""),
 (G.G_RB, "<p>Can this hand be built the other way round? No: the red card is always in a row and the black one always in a column. No twins, so don't divide: <b>676</b>.</p>", "Why is this different from handshakes?"),
])
WS["u29"] = W("u29", [
 (row(big("10 plain spades"), big("J♠ Q♠ K♠"), big("9 other face cards")), "<p>Sort the deck into three piles. The middle pile is cards that are <b>both</b> a spade and a face card.</p>", ""),
 (G.G_SF, "<p>Grid: 13 spades × 12 face cards = 156. Three boxes use one card twice (×). And in the J♠ Q♠ K♠ corner, J♠ + Q♠ appears twice (twins).</p>", "Find the twin of the J♠Q♠ box."),
 (big("156 − 3 − 3 = 150"), "<p>Remove the 3 crossed boxes and 3 twins: <b>150</b>.</p>", ""),
 (big("10 × 9 + 3 × 19 + 3 = 90 + 57 + 3 = 150"), "<p>Check with cases: plain spade + plain face, one J♠/Q♠/K♠ + any plain card, or two of J♠/Q♠/K♠.</p>", ""),
])
WS["ub"] = W("ub", [
 (slots([("President", "", 8, "on"), ("Vice", "", 7, "on"), ("Secretary", "", 6, "on"), ("Treasurer", "", 5, "on")], result="1680"), "<p>Different jobs: order matters. 8 × 7 × 6 × 5 = <b>1680</b>.</p>", ""),
 (big("one committee of 4 → 4! = 24 ways to hand out the jobs"), "<p>Every committee can be turned into 24 different slates of officers.</p>", ""),
 (big("1680 ÷ 24 = 70"), "<p>Same job: divide by 4!. <b>70</b> committees. That's why one answer is exactly 24 times the other.</p>", ""),
])

# ---------- lesson guided problems ----------
WS["c1"] = W("c1", walk([("shirt", "", 4, "4 shirts."), ("pants", "", 3, "Every shirt goes with all 3 pants: 4 × 3 = 12 pairs."), ("shoes", "", 2, "Every pair goes with both shoes.")], "24"))
ODD = ["1", "3", "5", "7", "9"]
WS["c2"] = W("c2", walk([(f"{k}", chips(ODD), 5, "Odd digits: 1, 3, 5, 7, 9. None is 0, so even the first slot has all 5.") for k in ["1st", "2nd", "3rd", "4th", "5th"]], "3125"))
WS["c3"] = W("c3", walk([("driver", chips(["Mr", "Mrs"]), 2, "The driver's seat is restricted: a parent. Do it first: 2."), ("seat 2", "", 3, "3 people left."), ("seat 3", "", 2, "2 left."), ("seat 4", "", 1, "1 left.")], "12"))
WS["c4"] = W("c4", walk([("1st", chips(list("ABC")), 3, "3 letters."), ("2nd", "", 2, "2 left."), ("3rd", "", 1, "1 left.")], "6"))
WS["c5"] = W("c5", walk([("1st", chips(D10, banned=["0"]), 9, "Not zero: 9."), ("2nd", "", 9, "Zero back, one used: 9."), ("3rd", "", 8, "Two used: 8."), ("4th", "", 7, "7."), ("5th", "", 6, "6.")], "27,216"))
WS["c6"] = W("c6", [
 (bundle([letters("AABC", {0: "blue", 1: "red"}, {0: "1", 1: "2"}), letters("AABC", {0: "red", 1: "blue"}, {0: "2", 1: "1"})], letters("AABC")), "<p>Paint the A's: each real word appears twice. 4! ÷ 2! = 24 ÷ 2 = 12.</p>", ""),
 (big("A, A, A, B, C: 5! ÷ 3! = 120 ÷ 6 = 20"), "<p>Three A's can be ordered 3! = 6 ways, so divide by 6 (not 3).</p>", ""),
])
WS["c7"] = W("c7", [(big("labeled tubes: fill 15 spots one coin at a time → 15!"), "<p>Order inside each tube matters, so it's just arranging 15 coins.</p>", ""),
 (big("identical tubes: swap whole stacks → 3! = 6 look the same → 15! ÷ 3!"), "<p>Divide by the ways to shuffle the 3 whole stacks. Don't divide by 5! per stack.</p>", "")])
WS["c8"] = W("c8", [(row(*[letters(w) for w in ["AA", "AC", "BA", "BB", "CB", "CC"]], gap=".4rem"), "<p>Two-letter good words: each first letter has exactly 2 partners: 3 × 2 = 6.</p>", ""),
 (slots([("1st", chips(list("ABC")), 3, "done")] + [(f"{k}", "2 allowed", 2, "on") for k in ["2nd", "3rd", "4th", "5th", "6th", "7th"]], result="192"), "<p>Every later letter has 2 options: 3 × 2⁶ = <b>192</b>.</p>", "")])
WS["c9"] = W("c9", [(big("dark blue square + dark green triangle → dark red circle"), "<p>For each feature: same and same → same; different and different → the one that's left. The third card is forced: 1 option.</p>", ""),
 (slots([("1st card", "", 27, "on"), ("2nd card", "", 26, "on"), ("3rd card", "forced", 1, "on")], result="702"), "<p>Ordered draws: 27 × 26 × 1 = 702.</p>", ""),
 (big("702 ÷ 3! = 702 ÷ 6 = 117"), "<p>A set has no order: each set was drawn in 6 orders. <b>117</b>.</p>", "")])
WS["c10"] = W("c10", [(pgrid(list("ABCDE"), 2, rowh="captain", colh="vice", plain=True), "<p>Captain down the side, vice across the top. Diagonal crossed (one person can't do both): 25 − 5 = 20. Different jobs, no twins: <b>20</b>.</p>", ""),
 (pgrid(list("ABCDE"), 3, twin_hl=(0, 1)), "<p>Co-captains share one job, so AB and BA are the same pair: 20 ÷ 2 = <b>10</b>.</p>", "")])
