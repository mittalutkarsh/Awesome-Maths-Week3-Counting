"""Notes page: long-form reading. Every section opens with its governing equation."""
from .lesson import C, eq, frac
from . import grids as G

EXTRA = {
 "product": """<h3>Worked numbers</h3>
<p>A dinner is one of 10 appetizers, 5 mains and 3 desserts: 10 × 5 × 3 = 150 dinners. A three-digit number built left to right
has 9 × 10 × 10 = 900 possibilities; built right to left it's 10 × 10 × 9, the same 900.</p>
<p>Columns can be decisions too. If m + n = 1492 with no carrying, each column of the sum splits on its own: the ones digit 2 is
0 + 2, 1 + 1 or 2 + 0, which is 3 ways. A digit d splits into d + 1 ordered pairs.</p>""",
 "restrict": """<h3>Worked numbers</h3>
<p>Three-digit numbers with only even digits: first place 2, 4, 6, 8 (4 options, zero is even but can't lead), then 0, 2, 4, 6, 8
twice (5 each): 4 × 5 × 5 = 100.</p>
<p>A license plate is not a number, so zero may go first: four digit spots give 10⁴ = 10,000, not 9 × 10³.</p>""",
 "first": """<h3>Worked numbers</h3>
<p>Two boys at the ends of a row, three girls in the middle: seat the boys first (2 ways), then the girls (3! = 6): 12.</p>
<p>Letters that must sit together: glue them into one block and choose the block's position first. Two letters side by side among
six characters can start at positions 1 to 5, so 5 positions.</p>""",
 "perm": """<h3>Worked numbers</h3>
<p>M, A, T, H: 4 × 3 × 2 × 1 = 24. Check: 6 arrangements start with each of the four letters, 4 × 6 = 24.</p>
<p>Useful values: 1! = 1, 2! = 2, 3! = 6, 4! = 24, 5! = 120, 6! = 720, 7! = 5040.</p>""",
 "shrink": """<h3>Worked numbers</h3>
<p>Three-digit numbers with different digits: 9 × 9 × 8 = 648. Four-digit: 9 × 9 × 8 × 7 = 4536. The second factor is 9 both
times: zero comes back in, and one digit is used up.</p>""",
 "overcount": """<h3>Worked numbers</h3>
<p>HELLO: 5!/2! = 120/2 = 60. GREENER: 7!/(3! · 2!) = 5040/12 = 420. MISSISSIPPI: 11!/(4! · 4! · 2!) = 34,650, and the class left it
in factorial form.</p>
<p>Overcounting also shows up without letters. If each of 8 teams plays 14 conference games, 8 × 14 = 112 counts every game twice,
once for each team in it: 56 games.</p>""",
 "groups": """<h3>Worked numbers</h3>
<p>A smaller case you can check by hand: six coins, three stacks of two. Labeled tubes: 6! = 720. Identical tubes: 720/3! = 120.
A computer listing agrees with both.</p>""",
 "samecount": """<h3>Worked numbers</h3>
<p>Ten kids each get 1, 2 or 3 candies, and no two neighbors may total 4. After 1 the next can't be 3; after 2, not 2; after 3,
not 1. Always two choices: 3 × 2⁹ = 1536.</p>""",
 "order": """<h3>Worked numbers</h3>
<p>An increasing number like 1368 is fixed by which digits it uses; the order comes for free. So counting increasing numbers means
counting groups of digits from 1 to 9: each digit in or out, 2⁹, minus the empty group, 511.</p>""",
}

TRAPS = [
 ("Letting zero lead", "q1", "1000", "Counting every digit string 000–999. It's tempting because each place \"has 10 digits\". A number can't start with 0."),
 ("Forgetting zero is even", "q2", "64", "Using 2, 4, 6, 8 in every place. Zero is even, and it's allowed in the middle and last places."),
 ("Letting zero lead, even digits", "q2", "125", "Five even digits in every place, including a leading zero."),
 ("Three colors, then \"× 1\"", "q3", "81", "Giving the first four squares 3 colors each and forcing the last. A later square has 2 or 3 options depending on earlier choices, so there's no single multiplier."),
 ("Yellow in one fixed spot", "q3", "16", "Painting the first square yellow and coloring the rest. It misses every coloring with yellow elsewhere."),
 ("Zero banned in the middle", "q6", "504", "Using 9, 8, 7. Zero can't lead, but it can come second or third, so the second place has 9 options, not 8."),
 ("Dividing by the number of repeats", "q8", "840", "Dividing 5040 by 3 × 2 instead of 3! × 2!. The overcount is the number of orderings of the repeated letters."),
 ("Only one repeat group divided out", "q8", "2520", "Dividing by 2! for the R's and forgetting the E's (or the other way round gives 840)."),
 ("Adding the factorials underneath", "q9", "798336", "Writing 11!/(4! + 4! + 2!). The orderings of the groups combine by the rule of product, so they multiply."),
 ("Counting each game from both sides", "q12", "144", "8 teams × 14 conference games = 112 counts every conference game twice. Non-conference games are counted once, correctly."),
 ("Treating the candies as free", "q13", "59049", "3¹⁰ ignores the neighbor rule. The rule removes exactly one option for every kid after the first."),
 ("Every pair of ends works", "q14", "90", "9 first digits × 10 last digits. When one end is odd and the other even, the average isn't a whole number."),
 ("Forgetting where the letters go", "q15", "6760000", "26² × 10⁴ counts the letters and digits but not the 5 places the letter pair can sit."),
 ("Just short of a year", "q16", "7", "7 mains give 14 × 7 × 3 = 294 dinners, fewer than 365. \"Least\" means the smallest that works, so check the one below too."),
 ("One checkerboard case", "q18", "8192", "Putting the 1s on the light cells only. The 1s could be on the dark cells instead, which gives another 2¹² arrangements."),
]

WORKED = [
 ("q3", "Exactly one yellow square", """<ol>
<li><b>What's hard?</b> "Exactly one yellow." Coloring left to right, the number of options for a later square depends on whether yellow was already used, so there's no single multiplier.</li>
<li><b>Reorder the decisions.</b> Settle the hard rule first: which square is yellow.</li>
<li><b>Count each decision.</b> Yellow square: 5 choices. Each other square: green or blue, 2 choices, whatever came before.</li>
<li><b>Multiply.</b> 5 × 2 × 2 × 2 × 2 = 80.</li>
<li><b>Check.</b> A computer listing of all 3⁵ = 243 colorings finds 80 with one yellow.</li></ol>"""),
 ("q8", "Arranging GREENER", """<ol>
<li><b>Tally.</b> Seven letters: E × 3, R × 2, G, N.</li>
<li><b>Why not letter by letter?</b> After an E there are 4 kinds of letter left; after G only 3. Uneven branches, no product.</li>
<li><b>Pretend.</b> Color the E's and R's so all seven letters are different: 7! = 5040 arrangements.</li>
<li><b>How often is each real word counted?</b> Once for each ordering of the colored E's (3! = 6) times each ordering of the colored R's (2! = 2): 12 times, the same for every word.</li>
<li><b>Divide.</b> 5040 ÷ 12 = 420.</li></ol>"""),
 ("q13", "Candy for ten kids", """<ol>
<li><b>What's banned?</b> Neighbor pairs totaling 4: (1, 3), (3, 1), (2, 2).</li>
<li><b>Build left to right.</b> First kid: 1, 2 or 3.</li>
<li><b>Does the next kid always have the same number of options?</b> After 1: 1 or 2. After 2: 1 or 3. After 3: 2 or 3. Different options, always two.</li>
<li><b>Multiply.</b> 3 × 2⁹ = 1536, since nine kids come after the first.</li>
<li><b>Check.</b> Brute force over all 3¹⁰ = 59,049 ways finds 1536.</li></ol>"""),
 ("q14", "Middle digit is the average", """<ol>
<li><b>What's forced?</b> Once the first and last digits are chosen, the middle digit is their average, if that's a whole number.</li>
<li><b>When is it whole?</b> When the first and last digits are both odd or both even.</li>
<li><b>Count each kind.</b> Both odd: 5 × 5 = 25. Both even, first not zero: 4 × 5 = 20.</li>
<li><b>Add.</b> 25 + 20 = 45. The two kinds never overlap.</li>
<li><b>Check.</b> A scan of 100–999 finds 45.</li></ol>"""),
 ("q18", "The 0, 1, 2 grid", """<ol>
<li><b>Look at neighbors.</b> Next to a 0 or a 2 must be a 1. Next to a 1 can be 0 or 2.</li>
<li><b>Color the grid like a checkerboard.</b> Neighbors are always opposite colors, so one color holds only 1s and the other holds only 0s and 2s.</li>
<li><b>Count cells.</b> With dark corners: 13 dark, 12 light.</li>
<li><b>Two cases.</b> Light all 1s: each of 13 dark cells is 0 or 2, 2¹³ = 8192. Dark all 1s: 2¹² = 4096.</li>
<li><b>Add.</b> 8192 + 4096 = 12,288. Check: a row-by-row computer count agrees, and the 3 × 3 version gives 2⁵ + 2⁴ = 48 by full listing.</li></ol>"""),
]

CHEAT = [
 ("Several independent choices", "Multiply the option counts."),
 ("Building a number", "First place 1–9, later places 0–9. Apply any digit rule place by place."),
 ("One rule is awkward to track", "Decide that thing first, then the rest."),
 ("Things that must sit together", "Glue them into a block; choose the block's position first."),
 ("Arrange n different things", "n!"),
 ("Different digits / no repeats", "Shrinking set: 9, 9, 8, 7, …"),
 ("Arrange with repeated letters", "n! ÷ (product of each repeat count's factorial)."),
 ("Whole groups are interchangeable", "Count with labels, divide by (number of groups)!"),
 ("Asked for a set, built in order", "Divide by the number of orders: k! for k items."),
 ("Next options change but their number doesn't", "The rule of product still works."),
 ("Everyone counted from two sides", "Divide by 2 (each game has two teams)."),
 ("\"Least number that works\"", "Find the first that works and check the one below fails."),
 ("A forced value in the middle", "Pick the free parts; check when the forced part exists."),
]

GLOSS = [
 ("Rule of product", "If a process has steps with c₁, c₂, …, c_k options, and each step's number of options doesn't depend on earlier choices, the process can end c₁ × c₂ × ⋯ × c_k ways."),
 ("Permutation", "An arrangement, or ordering, of a group of things."),
 ("Factorial, n!", "n × (n − 1) × ⋯ × 1, the number of arrangements of n different objects."),
 ("0! and the empty product", "0! = 1. There is exactly one way to arrange nothing. More generally, multiplying no numbers at all gives 1, the same way adding no numbers gives 0."),
 ("Distinct", "Different from one another. \"Distinct digits\" means no digit repeats."),
 ("Identical", "Impossible to tell apart. Swapping identical things doesn't make a new arrangement."),
 ("Overcounting", "Counting some or all things more than once."),
 ("Factor of overcount", "The number of times every object was counted, when it's the same for all of them. Divide by it."),
 ("Leading zero", "A zero in the first place. 024 is the two-digit number 24, not a three-digit number."),
 ("Not necessarily distinct", "Repeats are allowed but not required."),
 ("Ordered pair", "(m, n) with order mattering: (1000, 492) and (492, 1000) are different pairs."),
 ("Set", "A collection with no order. {A, B, C} is the same set as {C, A, B}."),
 ("Exactly one", "One, no more and no fewer."),
 ("Neighbors (in a grid)", "Cells sharing a side. Cells touching only at a corner are not neighbors."),
 ("Between 1000 and 9999", "Usually means inclusive, but check whether the endpoints matter. For four distinct digits they don't: both repeat a digit."),
]

HABITS = """<ul>
<li><b>Say what you're building.</b> The class starts every count by naming the object and the decisions that make it: "a number is a list of digits, so decide each digit."</li>
<li><b>List the options for the first place or two.</b> The teacher writes them out once ("1, 2, …, 9") and only then switches to counts.</li>
<li><b>Check a couple of sample paths.</b> Choose A then C and see what's left; try a second path to make sure nothing behaves differently.</li>
<li><b>Show the restricted decision first.</b> Write "which square is yellow: 5" before anything else.</li>
<li><b>Say why you divide.</b> "Every word is counted 3! × 2! times" is the justification; the division is just arithmetic.</li>
<li><b>Leave big answers in factored form</b> when the problem allows it: 11!/(4!·4!·2!), 3 × 2⁹. Cancel factorials before multiplying: 5!/3! = 5 × 4.</li>
<li><b>Check with a range or a small case.</b> 99,999 − 10,000 + 1 = 90,000 confirmed 9 × 10⁴ in class.</li>
</ul>"""

EQ_SECTION = {
 "traps": eq("right count = " + frac("count with extra distinctions", "times each thing was counted")),
 "worked": eq("N = c<sub>1</sub> × c<sub>2</sub> × ⋯ × c<sub>k</sub>"),
 "cheat": eq(frac("n!", "m<sub>1</sub>! · m<sub>2</sub>! ⋯ m<sub>r</sub>!")),
 "gloss": eq("0! = 1"),
 "habits": eq("9 × 10<sup>4</sup> = 99,999 − 10,000 + 1"),
}

CLASS = {
 "product": "<p><b>Outfits (Example 1.1).</b> Four shirts, three pants, two shoes: 4 × 3 = 12 shirt-and-pants pairs, each with 2 shoe options, 24 outfits.</p>",
 "restrict": "<p><b>Only odd digits (Example 1.3).</b> Every place uses 1, 3, 5, 7, 9. None of them is zero, so the first place isn't special: 5⁵ = 3125.</p>",
 "first": "<p><b>Family seating (Problem 2.1).</b> The driver's seat is restricted: 2 parents. The other three people fill the other seats: 3 × 2 × 1. Total 2 × 3 × 2 × 1 = 12.</p>",
 "perm": "<p><b>A, B, C (Example 1.4).</b> ABC, ACB, BAC, BCA, CAB, CBA: 3 × 2 × 1 = 6.</p>",
 "shrink": "<p><b>Five different digits (Example 1.5).</b> 9 × 9 × 8 × 7 × 6 = 27,216.</p>",
 "overcount": "<p><b>A, A, B, C and A, A, A, B, C (Examples 1.6, 1.7).</b> 4!/2! = 12 and 5!/3! = 5 × 4 = 20. A student in class suggested dividing 120 by 3 for the three A's; the factor is 3! = 6, the orderings of the colored A's.</p>",
 "groups": "<p><b>Coins in tubes (board example).</b> Fifteen distinct coins, three stacks of five. Labeled tubes: 15!. Identical tubes: 15!/3!. There's no division by (5!)³.</p>",
 "samecount": "<p><b>Good words (Problem 2.2).</b> After A: A or C. After B: A or B. After C: B or C. Seven letters: 3 × 2⁶ = 192.</p>",
 "order": "<p><b>Complementary cards (Problem 2.3).</b> Any two different cards force the third, feature by feature. Ordered draws 27 × 26 × 1 = 702; each set is drawn in 3! = 6 orders, so 117 sets.</p>",
}

CLASS["pairs"] = "<p><b>From the unit test.</b> Splitting six students into a group of 2 and a group of 4 has the same answer as just choosing the 2: naming the pair names the four. The grid below works it out.</p>"
EXTRA["pairs"] = """<h3>Worked numbers</h3><p>Handshakes among 12 people: 12 × 11 = 132 boxes off the diagonal, twins everywhere, 66 handshakes. Games between 8 teams playing home and away: 8 × 7 = 56 boxes, no twins, 56 games.</p>"""

GRID_SECTION = eq("pairs = " + frac("n × (n − 1)", "2")) + """
<p>This is the picture to draw whenever a problem picks two things and you're not sure whether to divide. It comes straight from the
group-of-2 problem on the unit test: Ms. Q splits Lizzie, Grogg, Alex, Winnie, Ralph and Fiona into a group of 2 and a group of 4.</p>
<h3>Building the grid</h3>
<ol>
<li><b>Set it up.</b> Write the six students down the side (the first student picked) and again across the top (the second student
picked). Every box is one way to say "first I pick this person, then I pick that person."</li>
<li><b>How many boxes are there?</b> 6 × 6 = 36.</li>
<li><b>Why are the × boxes not allowed?</b> You can't pick Lizzie and then pick Lizzie again. That removes the 6 boxes down the
diagonal, leaving 30.</li>
<li><b>This is the moment that matters.</b> Point at the LG box, then at the GL box, and ask: are those two different groups? They
aren't. It's Lizzie and Grogg either way. Every teal box has a grey twin on the other side of the diagonal, so the 30 boxes are
really 15 groups, each showing up twice. 30 ÷ 2 = 15.</li>
</ol>
""" + G.G_SPLIT + """
<p>If he can answer step 4 himself, he understands the whole idea. That one question, "is this the same thing written backwards?",
is what separates a problem where you divide from one where you multiply and stop.</p>
<p>Two surprises are worth saying out loud. First, the group of 4 costs nothing: if the problem had just said "choose 2 students"
the grid would be exactly the same picture, and the answer still 15. Naming the 2 already names the 4. Second, you can check from
the other side: choosing 4 of the 6 also gives 15, because every group of 4 leaves exactly one pair behind. The two counts list the
same 15 splits from opposite ends.</p>
<h3>Same grid, different answers</h3>
<p>Draw the grid, then ask the three questions. The answers change from problem to problem, and so does what you divide by.</p>
<h3>Home and away games: no twins</h3>
""" + G.G_GAMES + """
<p>Problem 12 counts games between 8 teams who play each other twice, home and away. Team 1 at home to team 2 is a different game
from team 2 at home to team 1, so every box off the diagonal is its own game: 56. The 8 × 14 = 112 trap comes from counting each game
from both teams' sides, which is a different grid.</p>
<h3>Handshakes: twins everywhere</h3>
""" + G.G_HANDS + """
<h3>One red card, one black card: no diagonal, no twins</h3>
""" + G.G_RB + """
<p>When the two picks come from separate piles, the grid is a rectangle. No box picks the same card twice, and no box has a twin,
because a red card can never be in the black column. Dividing by 2 here out of habit gives 338, which is wrong.</p>
<h3>A spade and a face card: twins only in one corner</h3>
""" + G.G_SF + """
<p>This is the hardest one, and the grid makes it easy to see. The two piles overlap in three cards, J♠, Q♠ and K♠. Only there can a
box pick the same card twice (the three × boxes), and only there can two boxes be the same hand (J♠ + Q♠ appears once with J♠ as the
spade, once with Q♠ as the spade). 156 − 3 − 3 = 150. The tempting wrong answers are 156 (no corrections) and 153 (only the × boxes).</p>
"""
