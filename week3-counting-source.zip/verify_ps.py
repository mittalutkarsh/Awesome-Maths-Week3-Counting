from itertools import product, permutations, combinations
from math import factorial as f, gcd
from sympy import factorint
R=[]
def chk(name, brute, arg):
    ok=brute==arg; R.append(ok); print(f"{'OK ' if ok else 'XX '} {name:40s} brute={brute:<12} argument={arg}")
# 1-9 (already verified in lecture pass; re-run for completeness)
chk("1 three-digit", len(range(100,1000)), 9*10*10)
chk("2 three-digit all even", sum(all(int(c)%2==0 for c in str(n)) for n in range(100,1000)), 4*5*5)
chk("3 exactly one yellow", sum(g.count('Y')==1 for g in product('YGB',repeat=5)), 5*2**4)
chk("4 AMC", len(set(permutations('AMC'))), 6)
chk("5 MATH", len(set(permutations('MATH'))), 24)
chk("6 3-digit distinct", sum(len(set(str(n)))==3 for n in range(100,1000)), 9*9*8)
chk("7 HELLO", len(set(permutations('HELLO'))), f(5)//f(2))
chk("8 GREENER", len(set(permutations('GREENER'))), f(7)//(f(3)*f(2)))
n=0
for I in combinations(range(11),4):
    r=[i for i in range(11) if i not in I]
    for S in combinations(r,4): n+=len(list(combinations([i for i in r if i not in S],2)))
chk("9 MISSISSIPPI", n, f(11)//(f(4)**2*f(2)))
# 10 chess: boys b0,b1 girls g0..g2
chk("10 chess photo", sum(1 for p in permutations(['b0','b1','g0','g1','g2']) if p[0][0]=='b' and p[-1][0]=='b'), 2*1*f(3))
chk("11 4 distinct digits 1000-9999", sum(len(set(str(n)))==4 for n in range(1000,10000)), 9*9*8*7)
# 12 games: enumerate game list
games=[(a,b,h) for a in range(8) for b in range(8) if a!=b for h in ('home',)]  # each ordered pair = one game (a hosts b)
nonconf=[(t,k) for t in range(8) for k in range(4)]
chk("12 Middle School Eight games", len(games)+len(nonconf), 8*7*2//2 + 8*4)
# 13 candies
bad={(1,3),(3,1),(2,2)}
b13=sum(1 for s in product((1,2,3),repeat=10) if not any((s[i],s[i+1]) in bad for i in range(9)))
chk("13 candies", b13, 3*2**9)
print("     13 factored:", factorint(b13))
chk("14 middle digit average", sum(1 for n in range(100,1000) if 2*(n//10%10)==n//100+n%10), 5*5+4*5)
# 15 license plates: brute on structure with small alphabets, then argument
def plates(D,L):
    cnt=0
    for pos in combinations(range(6),2):
        if pos[1]-pos[0]!=1: continue
        cnt+=D**4*L**2
    return cnt
chk("15 block positions (scan)", sum(1 for p in combinations(range(6),2) if p[1]-p[0]==1), 5)
# small-alphabet brute: digits {0,1}, letters {x,y}
sm=set()
for s in product('01xy',repeat=6):
    L=[i for i,c in enumerate(s) if c in 'xy']
    if len(L)==2 and L[1]-L[0]==1: sm.add(s)
chk("15 scaled brute (2 digits,2 letters)", len(sm), 5*2**4*2**2)
v15=5*10**4*26**2; print("     15 value:",v15," factored:",factorint(v15))
# 16
m=next(m for m in range(1,100) if 3*m*2*m>=365)
chk("16 least mains (search)", m, 8)
print("     16 check: m=7 ->",6*49,"dinners (<365); m=8 ->",6*64,"(>=365); 2003 not leap")
# 17 simple pairs summing to 1492
def nocarry(a,b):
    while a or b:
        if a%10+b%10>9: return False
        a//=10;b//=10
    return True
chk("17 simple pairs to 1492", sum(1 for a in range(1493) if nocarry(a,1492-a)), 2*5*10*3)
# 18 grid DP over rows (3^5 states)
rows=[r for r in product((0,1,2),repeat=5) if all(abs(r[i]-r[i+1])==1 for i in range(4))]
comp=lambda r,s: all(abs(a-b)==1 for a,b in zip(r,s))
dp={r:1 for r in rows}
for _ in range(4): dp={s:sum(dp[r] for r in rows if comp(r,s)) for s in rows}
chk("18 5x5 grid (row DP)", sum(dp.values()), 2**12+2**13)
# independent 3x3 full brute to confirm the pattern 2^4+2^5
def full(n):
    c=0
    for g in product((0,1,2),repeat=n*n):
        ok=all(abs(g[i*n+j]-g[i*n+j+1])==1 for i in range(n) for j in range(n-1)) and all(abs(g[i*n+j]-g[(i+1)*n+j])==1 for i in range(n-1) for j in range(n))
        c+=ok
    return c
chk("18 pattern on 3x3 (full brute)", full(3), 2**4+2**5)
# Lecture 2.4 increasing digits
chk("L2.4 increasing distinct digits", sum(1 for n in range(1,10**9) if False) or sum(1 for k in range(1,10) for c in combinations(range(1,10),k)), 2**9-1)
# direct brute over all numbers up to 9 digits is 1e9 — instead brute over digit strings 0-9 of length<=10
b24=0
for k in range(1,11):
    for c in combinations(range(10),k):
        if c[0]!=0 or k==1 and False: 
            if c[0]!=0: b24+=1
chk("L2.4 brute incl. zero check", b24, 511)
print("\nALL AGREE:", all(R), f"({len(R)} checks)")
