/* ---------- Answer checker: tolerant of form, specific about errors ---------- */
var Check = (function () {
  var SUP = { '⁰': '0', '¹': '1', '²': '2', '³': '3', '⁴': '4', '⁵': '5', '⁶': '6', '⁷': '7', '⁸': '8', '⁹': '9' };

  function norm(s) {
    s = String(s == null ? '' : s).trim().toLowerCase();
    s = s.replace(/[⁰¹²³⁴⁵⁶⁷⁸⁹]+/g, function (m) {
      return '^' + m.split('').map(function (c) { return SUP[c]; }).join('');
    });
    s = s.replace(/[×·∙⋅∗•]/g, '*').replace(/÷/g, '/').replace(/[−–—]/g, '-');
    s = s.replace(/(\d|\)|!)\s*x\s*(?=[\d(])/g, '$1*');       // 4 x 3 -> 4*3
    s = s.replace(/\*\*/g, '^');
    return s;
  }
  function stripThousands(s) {
    return s.replace(/\d{1,3}(?:,\d{3})+(?![\d,])/g, function (m) { return m.replace(/,/g, ''); });
  }

  /* recursive-descent evaluator: + - * / ^ ! ( ), implicit multiplication binds tighter than * and / */
  function evaluate(src) {
    var s = src.replace(/\s+/g, ' '), i = 0;
    function peek() { while (s[i] === ' ') i++; return s[i]; }
    function num() {
      peek(); var j = i;
      while (i < s.length && /[\d.]/.test(s[i])) i++;
      if (j === i) throw new Error('expected number');
      return parseFloat(s.slice(j, i));
    }
    function fact(n) {
      if (n < 0 || n > 25 || Math.floor(n) !== n) throw new Error('bad factorial');
      var r = 1; for (var k = 2; k <= n; k++) r *= k; return r;
    }
    function primary() {
      var c = peek();
      if (c === '(') { i++; var v = expr(); if (peek() !== ')') throw new Error('missing )'); i++; return v; }
      if (c === '-') { i++; return -primary(); }
      return num();
    }
    function postfix() { var v = primary(); while (peek() === '!') { i++; v = fact(v); } return v; }
    function power() {
      var b = postfix();
      if (peek() === '^') { i++; var e = power(); return Math.pow(b, e); }
      return b;
    }
    function implicit() {
      var v = power();
      while (true) { var c = peek(); if (c !== undefined && /[\d(]/.test(c)) v *= power(); else break; }
      return v;
    }
    function term() {
      var v = implicit();
      while (true) {
        var c = peek();
        if (c === '*') { i++; v *= implicit(); } else if (c === '/') { i++; var d = implicit(); if (d === 0) throw new Error('divide by zero'); v /= d; }
        else break;
      }
      return v;
    }
    function expr() {
      var v = term();
      while (true) { var c = peek(); if (c === '+') { i++; v += term(); } else if (c === '-') { i++; v -= term(); } else break; }
      return v;
    }
    var v = expr();
    if (peek() !== undefined) throw new Error('unexpected ' + s[i]);
    if (!isFinite(v)) throw new Error('not finite');
    return v;
  }

  function parseNumber(raw) {
    var s = stripThousands(norm(raw));
    if (!s) throw new Error('empty');
    if (/,/.test(s)) throw new Error('one number please');
    if (/[^0-9.+\-*/^!() ]/.test(s)) throw new Error('unreadable');
    return evaluate(s);
  }
  function same(a, b) { return Math.abs(a - b) <= 1e-9 * Math.max(1, Math.abs(b)); }
  function isPrime(n) { if (n < 2 || n !== Math.floor(n)) return false; for (var k = 2; k * k <= n; k++) if (n % k === 0) return false; return true; }

  function named(step, v) {
    var e = step.errors || {};
    for (var k in e) if (same(v, Number(k))) return e[k];
    return null;
  }
  function magnitude(v, ans) {
    var rel = Math.abs(v - ans) / Math.max(1, Math.abs(ans));
    if (rel < 0.03) return 'Very close. Recheck the arithmetic.';
    return v > ans ? 'Too big.' : 'Too small.';
  }

  /* ctx.prev = answers of earlier steps (numbers) so we can say "that's step k's answer" */
  function grade(step, raw, ctx) {
    ctx = ctx || {};
    var t = step.type;
    if (String(raw || '').trim() === '') return { parseError: true, msg: 'Type an answer in the box first.' };

    if (t === 'num' || t === 'expr') {
      var v;
      try { v = parseNumber(raw); } catch (err) {
        return { parseError: true, msg: err.message === 'one number please'
          ? 'This step wants a single number.' : "I couldn't read that as a number. Digits, ×, ^ and ! all work." };
      }
      if (same(v, step.ans)) return { ok: true, value: v };
      var m = named(step, v);
      if (!m && ctx.prev) for (var p = 0; p < ctx.prev.length; p++)
        if (typeof ctx.prev[p] === 'number' && same(v, ctx.prev[p]) && !same(v, step.ans)) { m = "That's the answer to step " + (p + 1) + '. This step asks something else.'; break; }
      return { ok: false, value: v, msg: m || magnitude(v, step.ans) };
    }

    if (t === 'factor') {
      var s = norm(raw);
      if (/[+\-/]/.test(s)) return { parseError: true, msg: 'Write it as a product of primes, like 2^3*5.' };
      var parts = s.split('*').map(function (x) { return x.trim(); }).filter(Boolean), val = 1, composite = false;
      try {
        parts.forEach(function (pt) {
          var b = pt.split('^'), base = evaluate(b[0]), ex = b.length > 1 ? evaluate(b[1]) : 1;
          if (!isPrime(base)) composite = true;
          val *= Math.pow(base, ex);
        });
      } catch (err) { return { parseError: true, msg: "I couldn't read that product." }; }
      if (same(val, step.ans) && !composite) return { ok: true, value: val };
      if (same(val, step.ans)) return { ok: false, value: val, msg: 'The product is right, but some pieces are still composite.' };
      return { ok: false, value: val, msg: named(step, val) || magnitude(val, step.ans) };
    }

    if (t === 'nums') {
      var toks = norm(raw).split(/\s*(?:,|;|&|\band\b)\s*|\s+/).filter(Boolean), got = [];
      try { toks.forEach(function (x) { got.push(evaluate(x)); }); } catch (err) {
        return { parseError: true, msg: 'List numbers separated by commas, like 5, 2.' };
      }
      var want = step.ans.slice().sort(function (a, b) { return a - b; });
      var g = got.slice().sort(function (a, b) { return a - b; });
      if (g.length !== want.length) {
        var sg = g.reduce(function (a, b) { return a + b; }, 0), sw = want.reduce(function (a, b) { return a + b; }, 0);
        return { ok: false, value: got, msg: 'You have ' + g.length + (g.length === 1 ? ' value' : ' values') +
          '; the answer has ' + want.length + '.' + (sg === sw ? ' The total is right, though.' : '') };
      }
      var off = 0; for (var k = 0; k < g.length; k++) if (!same(g[k], want[k])) off++;
      if (off === 0) return { ok: true, value: got };
      if (off === 1) return { ok: false, value: got, msg: 'Right number of values, but one is off.' };
      return { ok: false, value: got, msg: 'Right number of values, but ' + off + ' of them are off.' };
    }

    if (t === 'choice') {
      var r = norm(raw).replace(/[()\[\].:]/g, '').trim(), opts = step.options || [], idx = -1;
      if (r === 'y' || r === 'n') for (var o0 = 0; o0 < opts.length; o0++) if (opts[o0].toLowerCase()[0] === r && /^(yes|no)$/i.test(opts[o0])) idx = o0;
      if (idx < 0 && /^[a-z]$/.test(r)) idx = r.charCodeAt(0) - 97;
      for (var o = 0; o < opts.length && idx < 0; o++) if (opts[o].toLowerCase() === r) idx = o;
      if (idx < 0 && (r === 'y' || r === 'n')) for (var o2 = 0; o2 < opts.length; o2++) if (opts[o2].toLowerCase()[0] === r) idx = o2;
      if (idx < 0 || idx >= opts.length) return { parseError: true, msg: 'Pick one of the options: ' + opts.map(function (x, n) { return String.fromCharCode(65 + n) + ') ' + x; }).join('  ') };
      var ansIdx = step.ans.charCodeAt(0) - 65;
      return idx === ansIdx ? { ok: true, value: opts[idx] } : { ok: false, value: opts[idx], msg: 'Not that one.' };
    }

    if (t === 'text') {
      var tx = norm(raw);
      for (var q = 0; q < step.reject.length; q++) if (new RegExp(step.reject[q], 'i').test(tx)) return { ok: false, value: tx, msg: "That's the opposite of what's true here." };
      for (var a = 0; a < step.accept.length; a++) if (new RegExp(step.accept[a], 'i').test(tx)) return { ok: true, value: tx };
      return { ok: false, value: tx, msg: "That doesn't match yet." };
    }
    return { parseError: true, msg: 'Unknown step type.' };
  }

  return { grade: grade, parseNumber: parseNumber, norm: norm, evaluate: evaluate };
})();
if (typeof module !== 'undefined') module.exports = Check;
