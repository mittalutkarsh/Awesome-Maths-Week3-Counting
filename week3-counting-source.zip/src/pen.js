/* ---------- Teaching pen ----------
   Two viewport-sized canvases: #ink-base holds finished strokes and is never touched while a stroke is in
   progress; #ink-live holds only the stroke being drawn, and only new segments are appended each frame.
   Anchoring: data-pen-mode="page" stores points in document coordinates and re-renders the base layer with a
   translate on scroll; "viewport" stores viewport coordinates and swallows scrolling while the pen is on. */
(function () {
  var root = document.documentElement;
  var MODE = root.getAttribute('data-pen-mode') === 'viewport' ? 'viewport' : 'page';
  var DPR = Math.min(2, window.devicePixelRatio || 1);
  var WIDTHS = { fine: 1.6, medium: 3.2, bold: 6.5 };
  function $id(id) { return document.getElementById(id); }

  var base = $id('ink-base'), live = $id('ink-live'), bar = $id('pen-bar'), btn = $id('pen-toggle'), toast = $id('pen-toast');
  var bctx = base.getContext('2d'), lctx = live.getContext('2d');

  var S = { on: false, tool: 'pen', color: '#1b3358', width: 'medium', stylusOnly: false };
  var strokes = [], undoStack = [], redoStack = [];
  var cur = null, pending = false, eraseBefore = null, vw = 0, vh = 0;
  var stats = { framesWhileDrawing: 0, oldStrokesRedrawnWhileDrawing: 0, baseRenders: 0, commits: 0,
                touchIgnored: 0, segmentsDrawn: 0, lastExportBytes: 0 };

  function offset() { return MODE === 'page' ? { x: window.scrollX || 0, y: window.scrollY || 0 } : { x: 0, y: 0 }; }
  function toLocal(e) { var o = offset(); return { x: e.clientX + o.x, y: e.clientY + o.y }; }

  function resize() {
    vw = window.innerWidth; vh = window.innerHeight;
    [base, live].forEach(function (c) {
      c.width = Math.round(vw * DPR); c.height = Math.round(vh * DPR);
      c.style.width = vw + 'px'; c.style.height = vh + 'px';
    });
    renderBase();
  }

  function setupCtx(ctx) {
    var o = offset();
    ctx.setTransform(DPR, 0, 0, DPR, -o.x * DPR, -o.y * DPR);
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
  }

  function bbox(s) {
    if (s.bb) return s.bb;
    var x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    s.pts.forEach(function (p) { if (p.x < x0) x0 = p.x; if (p.y < y0) y0 = p.y; if (p.x > x1) x1 = p.x; if (p.y > y1) y1 = p.y; });
    var pad = (s.w || 3) * 2 + 2;
    return (s.bb = { x0: x0 - pad, y0: y0 - pad, x1: x1 + pad, y1: y1 + pad });
  }
  function visible(s) {
    var b = bbox(s), o = offset();
    return b.x1 >= o.x && b.x0 <= o.x + vw && b.y1 >= o.y && b.y0 <= o.y + vh;
  }

  function mid(a, b) { return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }; }

  /* one smoothed segment k: from mid(k-1,k) to mid(k,k+1), control point k; tapered pen width */
  function segment(ctx, p, k) {
    var a = k === 0 ? p[0] : mid(p[k - 1], p[k]), b = mid(p[k], p[k + 1]);
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.quadraticCurveTo(p[k].x, p[k].y, b.x, b.y);
    ctx.lineWidth = p[k].w; ctx.stroke(); stats.segmentsDrawn++;
  }
  function tail(ctx, p) {
    var n = p.length; if (n < 2) return;
    var a = mid(p[n - 2], p[n - 1]);
    ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(p[n - 1].x, p[n - 1].y); ctx.lineWidth = p[n - 1].w; ctx.stroke();
  }
  function dot(ctx, s) { var p = s.pts[0]; ctx.beginPath(); ctx.arc(p.x, p.y, s.w / 2, 0, Math.PI * 2); ctx.fillStyle = s.color; ctx.fill(); }

  function drawStroke(ctx, s) {
    ctx.save();
    ctx.strokeStyle = s.color;
    var p = s.pts;
    if (s.tool === 'box') {
      ctx.lineWidth = s.w; ctx.strokeRect(Math.min(p[0].x, p[1].x), Math.min(p[0].y, p[1].y), Math.abs(p[1].x - p[0].x), Math.abs(p[1].y - p[0].y));
    } else if (s.tool === 'line' || s.straight) {
      if (s.tool === 'marker') ctx.globalAlpha = 0.35;
      ctx.lineWidth = s.w; ctx.beginPath(); ctx.moveTo(p[0].x, p[0].y); ctx.lineTo(p[p.length - 1].x, p[p.length - 1].y); ctx.stroke();
    } else if (p.length === 1) {
      if (s.tool === 'marker') ctx.globalAlpha = 0.35;
      dot(ctx, s);
    } else if (s.tool === 'marker') {
      /* one path, one stroke(), so overlaps inside the stroke don't darken */
      ctx.globalAlpha = 0.35; ctx.lineWidth = s.w; ctx.beginPath(); ctx.moveTo(p[0].x, p[0].y);
      for (var k = 1; k < p.length - 1; k++) { var m = mid(p[k], p[k + 1]); ctx.quadraticCurveTo(p[k].x, p[k].y, m.x, m.y); }
      ctx.lineTo(p[p.length - 1].x, p[p.length - 1].y); ctx.stroke();
    } else {
      for (var j = 0; j < p.length - 1; j++) segment(ctx, p, j);
      tail(ctx, p);
    }
    ctx.restore();
  }

  function renderBase() {
    stats.baseRenders++;
    bctx.setTransform(1, 0, 0, 1, 0, 0); bctx.clearRect(0, 0, base.width, base.height);
    setupCtx(bctx);
    for (var i = 0; i < strokes.length; i++) if (visible(strokes[i])) {
      drawStroke(bctx, strokes[i]);
      if (cur) stats.oldStrokesRedrawnWhileDrawing++;
    }
  }
  function clearLive() { lctx.setTransform(1, 0, 0, 1, 0, 0); lctx.clearRect(0, 0, live.width, live.height); }

  /* ---- per-frame flush: cost proportional to new points only ---- */
  function schedule() { if (!pending) { pending = true; requestAnimationFrame(flush); } }
  function flush() {
    pending = false;
    if (!cur) return;
    stats.framesWhileDrawing++;
    setupCtx(lctx);
    lctx.strokeStyle = cur.color;
    var p = cur.pts;
    if (cur.tool === 'line' || cur.tool === 'box' || cur.straight) {
      clearLive(); setupCtx(lctx);                 /* preview shape: constant cost */
      var shape = { tool: cur.tool, color: cur.color, w: cur.w, straight: cur.straight, pts: [p[0], p[p.length - 1]] };
      if (cur.tool === 'marker') { lctx.save(); drawStroke(lctx, { tool: 'line', color: cur.color, w: cur.w, pts: shape.pts }); lctx.restore(); }
      else drawStroke(lctx, shape);
      return;
    }
    if (cur.tool === 'marker') lctx.lineWidth = cur.w;
    while (cur.drawn < p.length - 1) {
      var k = cur.drawn;
      if (cur.tool === 'marker') {
        var a = k === 0 ? p[0] : mid(p[k - 1], p[k]), b = mid(p[k], p[k + 1]);
        lctx.beginPath(); lctx.moveTo(a.x, a.y); lctx.quadraticCurveTo(p[k].x, p[k].y, b.x, b.y); lctx.stroke(); stats.segmentsDrawn++;
      } else segment(lctx, p, k);
      cur.drawn++;
    }
  }

  function snapshot() { undoStack.push(strokes.slice()); if (undoStack.length > 200) undoStack.shift(); redoStack.length = 0; }

  function commit() {
    var s = cur; cur = null;
    if (s.tool === 'line' || s.tool === 'box' || s.straight) s.pts = [s.pts[0], s.pts[s.pts.length - 1]];
    delete s.drawn;
    snapshot(); strokes.push(s); stats.commits++;
    setupCtx(bctx); drawStroke(bctx, s);          /* drawn once onto the committed layer */
    clearLive(); live.style.opacity = '';
  }

  /* ---- eraser: removes whole strokes near the pointer ---- */
  function distSeg(p, a, b) {
    var dx = b.x - a.x, dy = b.y - a.y, L = dx * dx + dy * dy, t = L ? ((p.x - a.x) * dx + (p.y - a.y) * dy) / L : 0;
    t = Math.max(0, Math.min(1, t)); var x = a.x + t * dx - p.x, y = a.y + t * dy - p.y; return Math.sqrt(x * x + y * y);
  }
  function hits(s, q, r) {
    var b = bbox(s); if (q.x < b.x0 - r || q.x > b.x1 + r || q.y < b.y0 - r || q.y > b.y1 + r) return false;
    var p = s.pts;
    if (s.tool === 'box') {
      var c = [p[0], { x: p[1].x, y: p[0].y }, p[1], { x: p[0].x, y: p[1].y }];
      for (var i = 0; i < 4; i++) if (distSeg(q, c[i], c[(i + 1) % 4]) < r + s.w / 2) return true;
      return false;
    }
    if (p.length === 1) return Math.hypot(q.x - p[0].x, q.y - p[0].y) < r + s.w / 2;
    for (var j = 0; j < p.length - 1; j++) if (distSeg(q, p[j], p[j + 1]) < r + s.w / 2) return true;
    return false;
  }
  function eraseAt(q) {
    var before = strokes.length;
    strokes = strokes.filter(function (s) { return !hits(s, q, 10); });
    if (strokes.length !== before) renderBase();
  }

  /* ---- pointer handling ---- */
  function onDown(e) {
    if (!S.on) return;
    if (e.pointerType === 'touch' && (S.stylusOnly || MODE === 'page')) { stats.touchIgnored++; return; }
    if (e.button !== undefined && e.button > 0) return;
    e.preventDefault();
    try { live.setPointerCapture(e.pointerId); } catch (err) { /* synthetic events */ }
    var q = toLocal(e);
    if (S.tool === 'eraser') { eraseBefore = strokes.slice(); cur = { tool: 'eraser', pts: [q] }; eraseAt(q); return; }
    var w = WIDTHS[S.width] * (S.tool === 'marker' ? 4 : 1);
    q.w = w; q.t = e.timeStamp || 0;
    cur = { tool: S.tool, color: S.color, w: w, pts: [q], drawn: 0, straight: false };
    if (S.tool === 'marker') live.style.opacity = '0.35';
    schedule();
  }
  function onMove(e) {
    if (!cur) return;
    var evs = (e.getCoalescedEvents && e.getCoalescedEvents()) || [];
    if (!evs.length) evs = [e];
    if (cur.tool === 'eraser') { for (var i = 0; i < evs.length; i++) eraseAt(toLocal(evs[i])); return; }
    if ((cur.tool === 'pen' || cur.tool === 'marker') && e.shiftKey) cur.straight = true;
    for (var j = 0; j < evs.length; j++) {
      var q = toLocal(evs[j]), last = cur.pts[cur.pts.length - 1];
      var d = Math.hypot(q.x - last.x, q.y - last.y); if (d < 0.6) continue;
      q.t = evs[j].timeStamp || last.t + 8;
      if (cur.tool === 'pen') {
        var dt = Math.max(1, q.t - last.t), v = d / dt;
        var target = cur.w * Math.max(0.45, Math.min(1.25, 1.25 - 0.32 * v));
        q.w = last.w * 0.72 + target * 0.28;
      } else q.w = cur.w;
      cur.pts.push(q);
    }
    schedule();
  }
  function onUp() {
    if (!cur) return;
    if (cur.tool === 'eraser') {
      cur = null;
      if (eraseBefore && eraseBefore.length !== strokes.length) { undoStack.push(eraseBefore); redoStack.length = 0; }
      eraseBefore = null; return;
    }
    flush(); commit();
  }

  live.addEventListener('pointerdown', onDown);
  live.addEventListener('pointermove', onMove);
  live.addEventListener('pointerup', onUp);
  live.addEventListener('pointercancel', onUp);
  live.addEventListener('wheel', function (e) { if (S.on && MODE === 'viewport') e.preventDefault(); }, { passive: false });

  var scrollQueued = false;
  window.addEventListener('scroll', function () {
    if (MODE !== 'page' || scrollQueued) return;
    scrollQueued = true;
    requestAnimationFrame(function () { scrollQueued = false; renderBase(); });
  }, { passive: true });
  window.addEventListener('resize', resize);

  /* ---- UI ---- */
  function say(msg) { toast.textContent = msg; toast.classList.add('show'); clearTimeout(say.t); say.t = setTimeout(function () { toast.classList.remove('show'); }, 2200); }
  function setOn(v) {
    S.on = v; root.classList.toggle('pen-on', v);
    btn.setAttribute('aria-pressed', String(v)); bar.hidden = !v;
    live.style.pointerEvents = v ? 'auto' : 'none';
    live.style.touchAction = MODE === 'viewport' ? 'none' : 'pan-x pan-y pinch-zoom';
    if (!v && cur) onUp();
  }
  function undo() { if (!undoStack.length) return; redoStack.push(strokes); strokes = undoStack.pop(); renderBase(); }
  function redo() { if (!redoStack.length) return; undoStack.push(strokes); strokes = redoStack.pop(); renderBase(); }
  function clearAll() { if (!strokes.length) return; snapshot(); strokes = []; renderBase(); say('Cleared. Undo brings it back.'); }

  function exportPNG(done) {
    if (!strokes.length) { say('Nothing to export yet.'); if (done) done(null); return; }
    var x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
    strokes.forEach(function (s) { var b = bbox(s); x0 = Math.min(x0, b.x0); y0 = Math.min(y0, b.y0); x1 = Math.max(x1, b.x1); y1 = Math.max(y1, b.y1); });
    var w = Math.min(4096, Math.ceil(x1 - x0) + 20), h = Math.min(4096, Math.ceil(y1 - y0) + 20);
    var c = document.createElement('canvas'); c.width = w * DPR; c.height = h * DPR;
    var x = c.getContext('2d'); x.setTransform(DPR, 0, 0, DPR, (-x0 + 10) * DPR, (-y0 + 10) * DPR); x.lineCap = 'round'; x.lineJoin = 'round';
    strokes.forEach(function (s) { drawStroke(x, s); });
    try {
      c.toBlob(function (blob) {
        stats.lastExportBytes = blob ? blob.size : 0;
        try {
          var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'ink.png';
          document.body.appendChild(a); a.click(); a.remove();
          setTimeout(function () { URL.revokeObjectURL(a.href); }, 4000);
          say('Exported ink.png (the ink only, not the page).');
        } catch (err) { say('This frame blocks downloads.'); }
        if (done) done(blob);
      }, 'image/png');
    } catch (err) { say('Export is blocked here.'); if (done) done(null); }
  }

  btn.addEventListener('click', function () { setOn(!S.on); });
  bar.addEventListener('click', function (e) {
    var b = e.target.closest('button'); if (!b) return;
    if (b.dataset.tool) { S.tool = b.dataset.tool; mark('[data-tool]', b); }
    if (b.dataset.color) { S.color = b.dataset.color; mark('[data-color]', b); }
    if (b.dataset.width) { S.width = b.dataset.width; mark('[data-width]', b); }
    var act = b.dataset.act;
    if (act === 'undo') undo(); else if (act === 'redo') redo(); else if (act === 'clear') clearAll();
    else if (act === 'export') exportPNG(); else if (act === 'close') setOn(false);
    else if (act === 'stylus') { S.stylusOnly = !S.stylusOnly; b.setAttribute('aria-pressed', String(S.stylusOnly)); say(S.stylusOnly ? 'Stylus only: touches are ignored.' : 'Touch drawing allowed.'); }
  });
  function mark(sel, b) { bar.querySelectorAll(sel).forEach(function (x) { x.setAttribute('aria-pressed', String(x === b)); }); }

  function typing(t) { return t && (t.tagName === 'TEXTAREA' || t.tagName === 'INPUT' || t.tagName === 'SELECT' || t.isContentEditable); }
  document.addEventListener('keydown', function (e) {
    if (typing(e.target)) return;
    var mod = e.ctrlKey || e.metaKey;
    if (!mod && !e.altKey && (e.key === 'p' || e.key === 'P')) { e.preventDefault(); setOn(!S.on); return; }
    if (e.key === 'Escape' && S.on && !document.body.classList.contains('dialog-open')) { setOn(false); return; }
    if (S.on && mod && (e.key === 'z' || e.key === 'Z')) { e.preventDefault(); if (e.shiftKey) redo(); else undo(); return; }
    if (S.on && mod && (e.key === 'y' || e.key === 'Y')) { e.preventDefault(); redo(); }
  });

  resize();
  window.INK = {
    mode: MODE,
    get: function () { return strokes.slice(); },
    set: function (arr) { if (cur) onUp(); strokes = arr ? arr.slice() : []; undoStack = []; redoStack = []; renderBase(); },
    on: function () { setOn(true); }, off: function () { setOn(false); }, isOn: function () { return S.on; },
    undo: undo, redo: redo, clear: clearAll, exportPNG: exportPNG, stats: stats,
    megapixels: function () { return (base.width * base.height + live.width * live.height) / 1e6; },
    resetStats: function () { for (var k in stats) stats[k] = 0; }
  };
})();
