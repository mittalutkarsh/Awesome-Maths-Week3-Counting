/* ---------- step-by-step visual stories ---------- */
(function () {
  function show(st, i) {
    var n = +st.dataset.n; i = Math.max(0, Math.min(n - 1, i)); st.dataset.cur = i;
    st.querySelectorAll('.frame').forEach(function (f, k) { f.classList.toggle('on', k === i); });
    st.querySelectorAll('.sdot').forEach(function (d, k) { d.classList.toggle('on', k === i); d.classList.toggle('seen', k < i); });
    var p = st.querySelector('[data-prev]'), nx = st.querySelector('[data-next]');
    p.disabled = i === 0; nx.disabled = i === n - 1;
    nx.textContent = i === n - 1 ? 'Done' : 'Next step →';
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('.story button'); if (!b) return;
    var st = b.closest('.story'), cur = +st.dataset.cur;
    if (b.hasAttribute('data-next')) show(st, cur + 1);
    else if (b.hasAttribute('data-prev')) show(st, cur - 1);
    else if (b.dataset.go) show(st, +b.dataset.go);
    else if (b.hasAttribute('data-all')) {
      var all = st.classList.toggle('all'); b.setAttribute('aria-pressed', String(all)); b.textContent = all ? 'One step at a time' : 'Show all steps';
    }
  });
  document.addEventListener('keydown', function (e) {
    var st = e.target.closest && e.target.closest('.story'); if (!st) return;
    if (e.key === 'ArrowRight') { e.preventDefault(); show(st, +st.dataset.cur + 1); }
    if (e.key === 'ArrowLeft') { e.preventDefault(); show(st, +st.dataset.cur - 1); }
  });
  window.STORY = { show: show };
})();
