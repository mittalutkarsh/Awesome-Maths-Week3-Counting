/* ---------- Workbench: shared by the lesson and practice pages ---------- */
(function () {
  var D = window.WB_DATA;
  function $id(id) { var el = document.getElementById(id); if (!el) throw new Error('missing #' + id); return el; }
  function $opt(id) { return document.getElementById(id); }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  /* ---- guarded browser APIs (sandboxed about:srcdoc frames throw on these) ---- */
  function sandboxed() { try { return location.protocol === 'about:'; } catch (e) { return true; } }
  function readHash() { if (sandboxed()) return ''; try { return (location.hash || '').replace(/^#/, ''); } catch (e) { return ''; } }
  function writeHash(h) {
    if (sandboxed()) return;
    try { history.replaceState(null, '', '#' + h); } catch (e) { try { location.hash = h; } catch (e2) { /* blocked */ } }
  }

  var PROBS = D.problems, ORDER = PROBS.map(function (p) { return p.id; }), BY = {};
  PROBS.forEach(function (p) { BY[p.id] = p; });
  var ST = {};
  PROBS.forEach(function (p) {
    ST[p.id] = { step: 0, time: 0, ink: [], worked: false, verified: false, armed: false,
      steps: p.steps.map(function () { return { tries: 0, hints: 0, status: 'open', final: false, work: '', answer: '' }; }) };
  });
  var cur = null;

  var el = {
    select: $id('prob-select'), prev: $id('prev-btn'), next: $id('next-btn'), done: $id('done-count'), timer: $id('timer'),
    rail: $id('rail'), railToggle: $id('rail-toggle'), tabs: $id('tabs'), body: $id('problem-body'),
    verified: $id('verified'), worked: $id('worked'), stepsList: $id('steps-list'),
    pills: $id('step-pills'), q: $id('step-q'), tries: $id('tries'), editor: $id('editor'), gutter: $id('gutter'),
    answer: $id('answer'), check: $id('check-btn'), hint: $id('hint-btn'), submit: $id('submit-btn'), workedBtn: $id('worked-btn'),
    console: $id('console'), dlg: $id('hint-dialog'), dlgTitle: $id('hint-title'), dlgText: $id('hint-text'), dlgClose: $id('hint-close'),
    concept: $opt('concept-body')
  };

  function closed(s) { return s.status !== 'open'; }
  function probState(id) {
    var s = ST[id];
    if (s.steps.every(closed)) return 'closed';
    if (s.worked || s.steps.some(function (x) { return x.tries || x.hints || x.work; })) return 'progress';
    return 'untouched';
  }

  /* ---- navigation chrome ---- */
  function buildNav() {
    var html = '', opts = '';
    D.sections.forEach(function (sec) {
      html += '<div class="rail-sec"><h3>' + esc(sec.name) + '</h3><ol>';
      opts += '<optgroup label="' + esc(sec.name) + '">';
      sec.items.forEach(function (id) {
        var p = BY[id];
        html += '<li><a href="#' + id + '" data-go="' + id + '" id="rail-' + id + '"><span class="dot" aria-hidden="true"></span>' +
          '<span class="n">' + esc(p.num) + '</span> ' + esc(p.title) + '</a></li>';
        opts += '<option value="' + id + '">' + esc(p.num) + '. ' + esc(p.title) + '</option>';
      });
      html += '</ol></div>'; opts += '</optgroup>';
    });
    el.rail.innerHTML = html; el.select.innerHTML = opts;
  }
  function refreshNav() {
    var done = 0;
    ORDER.forEach(function (id) {
      var st = probState(id), a = document.getElementById('rail-' + id);
      if (st === 'closed') done++;
      a.setAttribute('data-state', st);
      a.setAttribute('aria-label', BY[id].title + ' (' + { untouched: 'not started', progress: 'in progress', closed: 'finished' }[st] + ')');
      if (id === cur) a.setAttribute('aria-current', 'true'); else a.removeAttribute('aria-current');
    });
    el.done.textContent = done + ' / ' + ORDER.length + ' finished';
    var i = ORDER.indexOf(cur); el.prev.disabled = i <= 0; el.next.disabled = i >= ORDER.length - 1;
  }

  /* ---- console ---- */
  function log(kind, text) {
    var line = document.createElement('div'); line.className = 'log ' + kind;
    var p = BY[cur], s = ST[cur];
    line.innerHTML = '<span class="tag">' + esc(p.num) + '·' + (s.step + 1) + '</span> ' + text;
    el.console.appendChild(line); el.console.scrollTop = el.console.scrollHeight;
  }

  /* ---- rendering ---- */
  function renderProblem() {
    var p = BY[cur];
    el.body.innerHTML = '<h2 class="ptitle"><span class="pnum">' + esc(p.num) + '</span>' + esc(p.title) + '</h2>' +
      (p.source ? '<p class="src">' + esc(p.source) + '</p>' : '') + '<p class="ptext">' + p.text + '</p>' + (p.figure || '');
    if (el.concept && D.concepts) {
      var c = D.concepts[p.concept_id];
      el.concept.innerHTML = c ? '<h2 class="ctitle">' + esc(c[0]) + '</h2>' + c[1] : '';
    }
    renderSolutions();
  }
  function renderSolutions() {
    var p = BY[cur], s = ST[cur];
    el.verified.hidden = !s.verified;
    el.verified.innerHTML = s.verified ? '<h3>Verified answer</h3><p class="big">' + esc(p.answer) + '</p><p>' + esc(p.check) + '</p>' + (p.solstory || p.solfig || '') : '';
    el.worked.hidden = !s.worked;
    el.worked.innerHTML = s.worked ? '<h3>Worked answer</h3><p>' + esc(p.worked) + '</p><p class="check">Check: ' + esc(p.check) + '</p>' + (s.verified ? '' : (p.solstory || p.solfig || '')) : '';
  }
  function statusText(x) {
    if (x.status === 'first') return 'right first try';
    if (x.status === 'tries') return 'right after ' + x.tries + ' tries';
    if (x.status === 'given') return 'answer given';
    return x.tries ? 'in progress, ' + x.tries + (x.tries === 1 ? ' try' : ' tries') : 'not tried';
  }
  function renderSteps() {
    var p = BY[cur], s = ST[cur];
    el.pills.innerHTML = p.steps.map(function (st, i) {
      var x = s.steps[i];
      return '<button type="button" class="pill" data-step="' + i + '" data-status="' + x.status + '"' +
        (i === s.step ? ' aria-current="step"' : '') + ' aria-label="Step ' + (i + 1) + ', ' + statusText(x) + '">' + (i + 1) + '</button>';
    }).join('');
    var st = p.steps[s.step], x = s.steps[s.step];
    el.q.innerHTML = '<span class="sn">Step ' + (s.step + 1) + ' of ' + p.steps.length + '</span>' + esc(st.q) +
      (st.options ? '<span class="opts">' + st.options.map(function (o, n) { return '<span>' + String.fromCharCode(65 + n) + ') ' + esc(o) + '</span>'; }).join('') + '</span>' : '');
    el.answer.placeholder = st.ph;
    el.answer.value = x.answer;
    el.editor.value = x.work;
    gutter();
    var lock = closed(x);
    el.answer.disabled = lock; el.check.disabled = lock;
    el.tries.textContent = lock ? statusText(x) + (x.hints ? ' · hint used' : '')
      : (x.final ? 'Final attempt' : 'Tries ' + x.tries + ' of 3') + (x.hints ? ' · hint used' : '');
    el.stepsList.innerHTML = p.steps.map(function (st2, i) {
      var y = s.steps[i];
      return '<li data-status="' + y.status + '"><b>Step ' + (i + 1) + '</b> ' + esc(st2.q) + '<span class="stat">' + statusText(y) +
        (y.hints ? ', hint used' : '') + '</span></li>';
    }).join('');
    el.workedBtn.textContent = s.armed ? 'Some steps are untried. Click again to show' : 'Show worked answer';
    el.workedBtn.classList.toggle('armed', s.armed);
  }
  function gutter() {
    var n = Math.max(6, el.editor.value.split('\n').length), out = '';
    for (var i = 1; i <= n; i++) out += i + '\n';
    el.gutter.textContent = out; el.gutter.scrollTop = el.editor.scrollTop;
  }
  function renderAll() { renderProblem(); renderSteps(); refreshNav(); }

  function go(id, opts) {
    if (!BY[id]) id = ORDER[0];
    if (cur && window.INK) ST[cur].ink = window.INK.get();          /* park this problem's ink */
    if (cur) saveInputs();
    cur = id;
    if (window.INK) window.INK.set(ST[id].ink);                      /* restore that problem's ink */
    el.select.value = id;
    renderAll(); tick(true);
    if (!(opts && opts.noHash)) writeHash(id);
    document.body.classList.remove('rail-open');
  }
  function saveInputs() { var x = ST[cur].steps[ST[cur].step]; x.work = el.editor.value; if (!closed(x)) x.answer = el.answer.value; }

  /* ---- the grading loop ---- */
  function nextOpen(s, from) {
    for (var i = from + 1; i < s.steps.length; i++) if (!closed(s.steps[i])) return i;
    for (var j = 0; j < s.steps.length; j++) if (!closed(s.steps[j])) return j;
    return -1;
  }
  function checkStep() {
    var p = BY[cur], s = ST[cur], i = s.step, st = p.steps[i], x = s.steps[i];
    saveInputs();
    if (closed(x)) { log('info', 'This step is already closed.'); return; }
    var prev = p.steps.slice(0, i).map(function (q) { return typeof q.ans === 'number' ? q.ans : null; });
    var r = Check.grade(st, el.answer.value, { prev: prev });
    if (r.parseError) { log('warn', esc(r.msg) + ' <span class="dim">(no try used)</span>'); return; }
    x.tries++;
    var shown = esc(el.answer.value.trim());
    if (r.ok) {
      x.status = x.tries === 1 ? 'first' : 'tries';
      log('ok', 'Try ' + x.tries + ': <b>' + shown + '</b>, correct. ' + esc(st.success));
      advance(s, i);
    } else if (!x.final && x.tries < 3) {
      log('bad', 'Try ' + x.tries + ': <b>' + shown + '</b>. ' + esc(r.msg) + ' <span class="nudge">' + esc(st.nudges[x.tries - 1]) + '</span>');
    } else if (!x.final) {
      x.final = true;
      log('bad', 'Try ' + x.tries + ': <b>' + shown + '</b>. ' + esc(r.msg) + ' <span class="nudge">' + esc(st.nudges[2]) + '</span> One final attempt on this step.');
    } else {
      x.status = 'given'; x.answer = '';
      log('given', 'Final attempt: <b>' + shown + '</b>. Here is this step: ' + esc(st.reveal));
      var n = nextOpen(s, i);
      if (n >= 0) log('info', 'On to step ' + (n + 1) + '. That one is yours to work out.');
      advance(s, i);
    }
    renderSteps(); refreshNav();
  }
  function advance(s, i) {
    var n = nextOpen(s, i);
    if (n >= 0) { s.step = n; }
    else log('info', 'Every step is closed. Press Submit question for the summary and the verified answer.');
  }
  function submit() {
    var p = BY[cur], s = ST[cur]; saveInputs();
    var lines = p.steps.map(function (st, i) { var x = s.steps[i]; return 'Step ' + (i + 1) + ': ' + statusText(x) + (x.hints ? ' (hint used)' : ''); });
    var open = s.steps.map(function (x, i) { return closed(x) ? null : i + 1; }).filter(Boolean);
    log('summary', lines.map(esc).join('<br>'));
    if (open.length) log('info', (open.length === 1 ? 'Step ' + open[0] + ' is' : 'Steps ' + open.join(', ') + ' are') + ' still open. Finish them to unlock the verified answer.');
    else { s.verified = true; renderSolutions(); log('ok', 'Verified answer unlocked: ' + esc(p.answer)); showTab('problem'); }
    refreshNav();
  }
  function showWorked() {
    var s = ST[cur];
    var untried = s.steps.some(function (x) { return !closed(x) && x.tries === 0; });
    if (untried && !s.armed) { s.armed = true; renderSteps(); setTimeout(function () { if (s.armed) { s.armed = false; if (ST[cur] === s) renderSteps(); } }, 5000); return; }
    s.armed = false; s.worked = true; renderSolutions(); renderSteps(); refreshNav(); showTab('problem');
    log('info', 'Worked answer shown.');
  }

  /* ---- hint dialog ---- */
  var lastFocus = null;
  function openHint() {
    var p = BY[cur], s = ST[cur], x = s.steps[s.step];
    x.hints++; saveInputs();
    el.dlgTitle.textContent = 'Hint for step ' + (s.step + 1);
    el.dlgText.textContent = p.steps[s.step].hint;
    lastFocus = document.activeElement;
    el.dlg.hidden = false; document.body.classList.add('dialog-open'); el.dlgClose.focus();
    log('info', 'Hint opened. It does not use a try.');
    renderSteps();
  }
  function closeHint() { el.dlg.hidden = true; document.body.classList.remove('dialog-open'); if (lastFocus) try { lastFocus.focus(); } catch (e) {} }

  /* ---- tabs ---- */
  function showTab(name) {
    el.tabs.querySelectorAll('[role=tab]').forEach(function (t) {
      var on = t.dataset.tab === name; t.setAttribute('aria-selected', String(on)); t.tabIndex = on ? 0 : -1;
      document.getElementById('tab-' + t.dataset.tab).hidden = !on;
    });
  }

  /* ---- timer ---- */
  function fmt(t) { var m = Math.floor(t / 60), s = t % 60; return m + ':' + (s < 10 ? '0' : '') + s; }
  function tick(noInc) {
    var s = ST[cur]; if (!s) return;
    if (!noInc && probState(cur) !== 'closed' && !document.hidden) s.time++;
    el.timer.textContent = fmt(s.time);
  }
  setInterval(tick, 1000);

  /* ---- wiring ---- */
  el.select.addEventListener('change', function () { go(el.select.value); });
  el.prev.addEventListener('click', function () { var i = ORDER.indexOf(cur); if (i > 0) go(ORDER[i - 1]); });
  el.next.addEventListener('click', function () { var i = ORDER.indexOf(cur); if (i < ORDER.length - 1) go(ORDER[i + 1]); });
  el.rail.addEventListener('click', function (e) { var a = e.target.closest('[data-go]'); if (a) { e.preventDefault(); go(a.dataset.go); } });
  el.railToggle.addEventListener('click', function () {
    var open = document.body.classList.toggle('rail-open'); el.railToggle.setAttribute('aria-expanded', String(open));
  });
  el.pills.addEventListener('click', function (e) {
    var b = e.target.closest('[data-step]'); if (!b) return; saveInputs(); ST[cur].step = +b.dataset.step; renderSteps();
  });
  el.tabs.addEventListener('click', function (e) { var t = e.target.closest('[role=tab]'); if (t) showTab(t.dataset.tab); });
  el.tabs.addEventListener('keydown', function (e) {
    if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
    var ts = [].slice.call(el.tabs.querySelectorAll('[role=tab]')), i = ts.indexOf(document.activeElement);
    var n = ts[(i + (e.key === 'ArrowRight' ? 1 : ts.length - 1)) % ts.length]; n.focus(); showTab(n.dataset.tab);
  });
  el.check.addEventListener('click', checkStep);
  el.hint.addEventListener('click', openHint);
  el.submit.addEventListener('click', submit);
  el.workedBtn.addEventListener('click', showWorked);
  el.dlgClose.addEventListener('click', closeHint);
  el.dlg.addEventListener('click', function (e) { if (e.target === el.dlg) closeHint(); });
  el.answer.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); checkStep(); } });
  el.editor.addEventListener('keydown', function (e) { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); checkStep(); } });
  el.editor.addEventListener('input', function () { ST[cur].steps[ST[cur].step].work = el.editor.value; gutter(); refreshNav(); });
  el.editor.addEventListener('scroll', function () { el.gutter.scrollTop = el.editor.scrollTop; });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !el.dlg.hidden) { e.preventDefault(); closeHint(); } }, true);
  window.addEventListener('hashchange', function () { var h = readHash(); if (h && BY[h] && h !== cur) go(h, { noHash: true }); });

  buildNav();
  showTab(D.page === 'lesson' ? 'concept' : 'problem');
  var h = readHash();
  go(BY[h] ? h : ORDER[0], { noHash: !BY[h] });

  window.WB = { go: go, state: ST, current: function () { return cur; }, order: ORDER, data: D, showTab: showTab };
})();
