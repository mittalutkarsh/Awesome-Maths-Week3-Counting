/* ---------- pick grid: pointing at a box lights up its twin ---------- */
(function () {
  function pair(el) {
    if (!el || !el.dataset || !el.dataset.tw) return [];
    var tw = document.querySelector('[data-k="' + el.dataset.tw + '"]');
    return tw ? [el, tw] : [el];
  }
  var lit = [];
  function light(el) { lit.forEach(function (x) { x.classList.remove('hl'); }); lit = pair(el); lit.forEach(function (x) { x.classList.add('hl'); }); }
  document.addEventListener('mouseover', function (e) { var c = e.target.closest && e.target.closest('.pc[data-tw]'); if (c) light(c); });
  document.addEventListener('focusin', function (e) { var c = e.target.closest && e.target.closest('.pc[data-tw]'); if (c) light(c); });
  document.addEventListener('click', function (e) { var c = e.target.closest && e.target.closest('.pc[data-tw]'); if (c) light(c); });
})();
